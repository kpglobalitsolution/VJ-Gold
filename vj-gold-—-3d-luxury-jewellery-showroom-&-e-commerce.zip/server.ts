import express from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI } from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const DATA_FILE = path.join(__dirname, "data", "store.json");

app.use(express.json());

// Helper to read and write database
function getStore() {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      return { products: [], goldRates: {}, settings: {}, enquiries: [], appointments: [] };
    }
    const raw = fs.readFileSync(DATA_FILE, "utf-8");
    return JSON.parse(raw);
  } catch (err) {
    console.error("Error reading store:", err);
    return { products: [], goldRates: {}, settings: {}, enquiries: [], appointments: [] };
  }
}

function saveStore(data: any) {
  try {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf-8");
    return true;
  } catch (err) {
    console.error("Error saving store:", err);
    return false;
  }
}

// REST API Endpoints
app.get("/api/products", (req, res) => {
  const store = getStore();
  res.json(store.products || []);
});

app.post("/api/products", (req, res) => {
  const store = getStore();
  const newProduct = {
    ...req.body,
    id: req.body.id || `vjg-${Date.now()}`,
    lastUpdated: new Date().toISOString(),
  };
  store.products = [newProduct, ...(store.products || [])];
  saveStore(store);
  res.status(201).json(newProduct);
});

app.put("/api/products/:id", (req, res) => {
  const store = getStore();
  const index = store.products.findIndex((p: any) => p.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Product not found" });
  }
  store.products[index] = {
    ...store.products[index],
    ...req.body,
    lastUpdated: new Date().toISOString(),
  };
  saveStore(store);
  res.json(store.products[index]);
});

app.delete("/api/products/:id", (req, res) => {
  const store = getStore();
  store.products = store.products.filter((p: any) => p.id !== req.params.id);
  saveStore(store);
  res.json({ success: true });
});

app.get("/api/gold-rates", (req, res) => {
  const store = getStore();
  res.json(store.goldRates || {});
});

app.post("/api/gold-rates", (req, res) => {
  const store = getStore();
  store.goldRates = {
    ...store.goldRates,
    ...req.body,
    updatedAt: new Date().toISOString(),
  };
  saveStore(store);
  res.json(store.goldRates);
});

app.get("/api/settings", (req, res) => {
  const store = getStore();
  res.json(store.settings || {});
});

app.post("/api/settings", (req, res) => {
  const store = getStore();
  store.settings = { ...store.settings, ...req.body };
  saveStore(store);
  res.json(store.settings);
});

app.get("/api/enquiries", (req, res) => {
  const store = getStore();
  res.json(store.enquiries || []);
});

app.post("/api/enquiries", (req, res) => {
  const store = getStore();
  const enquiry = {
    id: `enq-${Date.now()}`,
    ...req.body,
    status: "New",
    createdAt: new Date().toISOString(),
  };
  store.enquiries = [enquiry, ...(store.enquiries || [])];
  saveStore(store);
  res.status(201).json(enquiry);
});

app.patch("/api/enquiries/:id", (req, res) => {
  const store = getStore();
  const index = store.enquiries.findIndex((e: any) => e.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Enquiry not found" });
  }
  store.enquiries[index] = { ...store.enquiries[index], ...req.body };
  saveStore(store);
  res.json(store.enquiries[index]);
});

app.get("/api/appointments", (req, res) => {
  const store = getStore();
  res.json(store.appointments || []);
});

app.post("/api/appointments", (req, res) => {
  const store = getStore();
  const appointment = {
    id: `apt-${Date.now()}`,
    ...req.body,
    status: "Requested",
    createdAt: new Date().toISOString(),
  };
  store.appointments = [appointment, ...(store.appointments || [])];
  saveStore(store);
  res.status(201).json(appointment);
});

app.patch("/api/appointments/:id", (req, res) => {
  const store = getStore();
  const index = store.appointments.findIndex((a: any) => a.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Appointment not found" });
  }
  store.appointments[index] = { ...store.appointments[index], ...req.body };
  saveStore(store);
  res.json(store.appointments[index]);
});

// AI Jewellery Consultant endpoint
app.post("/api/assistant", async (req, res) => {
  const { message, currentProductId } = req.body;
  const store = getStore();
  const products = store.products || [];
  const currentProduct = products.find((p: any) => p.id === currentProductId);

  const productContext = products.map((p: any) => ({
    id: p.id,
    sku: p.sku,
    name: p.name,
    category: p.category,
    price: p.isPriceVerified && p.price ? `₹${p.price.toLocaleString("en-IN")}` : "Contact store for price",
    goldPurity: p.goldPurity,
    grossWeight: `${p.grossWeight}g`,
    availability: p.availability,
    stoneDetails: p.stoneDetails,
  }));

  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey) {
    try {
      const ai = new GoogleGenAI();
      const prompt = `You are the chief luxury jewellery consultant at "VJ Gold".
STRICT RULES:
1. Answer warmly, politely, and professionally in luxury jewellery retail tone.
2. Ground all answers STRICTLY on this verified VJ Gold inventory:
${JSON.stringify(productContext, null, 2)}
3. Current Selected Product: ${currentProduct ? JSON.stringify(currentProduct, null, 2) : "None currently highlighted"}.
4. Daily Gold Rates: 24K: ₹${store.goldRates?.rate24kPerGram}/g, 22K: ₹${store.goldRates?.rate22kPerGram}/g.
5. NEVER invent prices, weights, discounts, or stock that are not in the catalogue. If price is unverified, tell the customer: "Please connect with our team on WhatsApp for the exact quote based on today's gold rate and customization."
6. Offer to connect on WhatsApp (+91 98765 43210) or book a VIP private showroom trial.

Customer message: "${message}"`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });

      return res.json({ reply: response.text });
    } catch (err: any) {
      console.warn("Gemini generation fallback:", err?.message);
    }
  }

  // Graceful deterministic consultant answers when Gemini key is absent or offline
  const query = (message || "").toLowerCase();
  let reply = "Welcome to VJ Gold. I would be pleased to guide you through our fine jewellery collection.";

  if (query.includes("price") || query.includes("cost") || query.includes("rate")) {
    if (currentProduct) {
      if (currentProduct.isPriceVerified && currentProduct.price) {
        reply = `The listed price for "${currentProduct.name}" is ₹${currentProduct.price.toLocaleString("en-IN")}. As gold rates fluctuate daily, we invite you to confirm the exact invoice quotation with our jewellery specialists on WhatsApp or schedule a boutique trial.`;
      } else {
        reply = `The pricing for "${currentProduct.name}" depends on today's bullion rate and customization. Please tap the WhatsApp button to receive an instant verified quotation from our store manager.`;
      }
    } else {
      reply = `Our current bullion rates are ₹${store.goldRates?.rate24kPerGram}/g for 24K and ₹${store.goldRates?.rate22kPerGram}/g for 22K BIS Hallmarked gold. Which piece would you like an exact estimate for?`;
    }
  } else if (query.includes("necklace") || query.includes("choker")) {
    reply = "Our collection features our flagship 'Imperial Emerald & Pavé Diamond Choker Set' crafted in rose gold with natural oval emerald, and the 'Amour Lattice Mint Enamel Gold Collar Set'. Would you like me to highlight them in the 3D showroom?";
  } else if (query.includes("purity") || query.includes("hallmark") || query.includes("gold")) {
    reply = "Every piece at VJ Gold is 100% BIS Hallmarked (916 for 22K and 750 for 18K), accompanied by diamond certification for precious gemstones. Purity and weights are strictly verifiable.";
  } else if (query.includes("appointment") || query.includes("visit") || query.includes("store")) {
    reply = "You are warmly welcome to visit our luxury flagship boutique in Mumbai. You can click 'Book Showroom Visit' to reserve a dedicated consultation suite with one of our senior gemologists.";
  } else if (query.includes("bangle") || query.includes("chain") || query.includes("ring")) {
    reply = "We offer handcrafted royal kadas, diamond halo cocktail rings, and classic solid rope chains. You can filter by category in our catalogue or ask our showroom camera to navigate to that display vitrine.";
  } else {
    reply = `I am here to assist you with our handcrafted jewellery pieces, purity details, appointments, and WhatsApp inquiries. How can I help you discover the perfect piece today?`;
  }

  res.json({ reply });
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`VJ Gold server active on http://0.0.0.0:${PORT}`);
  });
}

startServer();
