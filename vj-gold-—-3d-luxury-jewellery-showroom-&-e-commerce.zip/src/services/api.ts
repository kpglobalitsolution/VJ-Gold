import { Product, GoldRates, StoreSettings, Enquiry, Appointment } from '../types';

export const api = {
  async getProducts(): Promise<Product[]> {
    try {
      const res = await fetch('/api/products');
      if (!res.ok) throw new Error('Failed to fetch products');
      const data = await res.json();
      localStorage.setItem('vjg_cached_products', JSON.stringify(data));
      return data;
    } catch (err) {
      console.warn('Using cached products:', err);
      const cached = localStorage.getItem('vjg_cached_products');
      return cached ? JSON.parse(cached) : [];
    }
  },

  async createProduct(product: Partial<Product>): Promise<Product> {
    const res = await fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    });
    if (!res.ok) throw new Error('Failed to create product');
    return res.json();
  },

  async updateProduct(id: string, product: Partial<Product>): Promise<Product> {
    const res = await fetch(`/api/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    });
    if (!res.ok) throw new Error('Failed to update product');
    return res.json();
  },

  async deleteProduct(id: string): Promise<boolean> {
    const res = await fetch(`/api/products/${id}`, { method: 'DELETE' });
    return res.ok;
  },

  async getGoldRates(): Promise<GoldRates> {
    try {
      const res = await fetch('/api/gold-rates');
      if (!res.ok) throw new Error('Failed to fetch rates');
      const data = await res.json();
      localStorage.setItem('vjg_cached_rates', JSON.stringify(data));
      return data;
    } catch (err) {
      const cached = localStorage.getItem('vjg_cached_rates');
      return cached ? JSON.parse(cached) : {
        rate24kPerGram: 7480,
        rate22kPerGram: 6855,
        rate18kPerGram: 5610,
        silverRatePerGram: 94,
        currency: 'INR',
        symbol: '₹',
        updatedAt: new Date().toISOString(),
        rateSource: 'VJ Gold Bullion Desk',
        isManual: true,
      };
    }
  },

  async updateGoldRates(rates: Partial<GoldRates>): Promise<GoldRates> {
    const res = await fetch('/api/gold-rates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(rates),
    });
    if (!res.ok) throw new Error('Failed to update rates');
    return res.json();
  },

  async getSettings(): Promise<StoreSettings> {
    try {
      const res = await fetch('/api/settings');
      if (!res.ok) throw new Error('Failed to fetch settings');
      const data = await res.json();
      localStorage.setItem('vjg_cached_settings', JSON.stringify(data));
      return data;
    } catch (err) {
      const cached = localStorage.getItem('vjg_cached_settings');
      return cached ? JSON.parse(cached) : {
        storeName: 'VJ Gold',
        tagline: 'Fine Jewellery & Bespoke Bullion',
        phone: '+91 98765 43210',
        whatsappNumber: '919876543210',
        email: 'enquiry@vjgold.in',
        address: 'VJ Gold Flagship Boutique, Gold Souk Arcade, MG Road, Mumbai 400001',
        businessHours: 'Mon – Sat: 10:30 AM – 8:30 PM | Sun: 11:00 AM – 7:00 PM',
        instagram: 'https://www.instagram.com/vj._.gold/',
        website: 'https://www.vjgold.in/',
        gstPercentage: 3,
        hallmarkNotice: '100% BIS Hallmarked 916 & 750 Gold Guaranteed',
      };
    }
  },

  async updateSettings(settings: Partial<StoreSettings>): Promise<StoreSettings> {
    const res = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    });
    if (!res.ok) throw new Error('Failed to update settings');
    return res.json();
  },

  async getEnquiries(): Promise<Enquiry[]> {
    try {
      const res = await fetch('/api/enquiries');
      if (!res.ok) throw new Error('Failed to fetch enquiries');
      return res.json();
    } catch {
      return [];
    }
  },

  async submitEnquiry(enquiry: Omit<Enquiry, 'id' | 'createdAt' | 'status'>): Promise<Enquiry> {
    const res = await fetch('/api/enquiries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(enquiry),
    });
    if (!res.ok) throw new Error('Failed to submit enquiry');
    return res.json();
  },

  async updateEnquiryStatus(id: string, status: Enquiry['status'], notes?: string): Promise<Enquiry> {
    const res = await fetch(`/api/enquiries/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, notes }),
    });
    if (!res.ok) throw new Error('Failed to update enquiry');
    return res.json();
  },

  async getAppointments(): Promise<Appointment[]> {
    try {
      const res = await fetch('/api/appointments');
      if (!res.ok) throw new Error('Failed to fetch appointments');
      return res.json();
    } catch {
      return [];
    }
  },

  async bookAppointment(appointment: Omit<Appointment, 'id' | 'createdAt' | 'status'>): Promise<Appointment> {
    const res = await fetch('/api/appointments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(appointment),
    });
    if (!res.ok) throw new Error('Failed to book appointment');
    return res.json();
  },

  async updateAppointmentStatus(id: string, status: Appointment['status'], notes?: string): Promise<Appointment> {
    const res = await fetch(`/api/appointments/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, notes }),
    });
    if (!res.ok) throw new Error('Failed to update appointment');
    return res.json();
  },

  async askConsultant(message: string, currentProductId?: string): Promise<string> {
    try {
      const res = await fetch('/api/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message, currentProductId }),
      });
      const data = await res.json();
      return data.reply;
    } catch {
      return "Welcome to VJ Gold. Please feel free to enquire with our jewellery specialists directly on WhatsApp for verified pricing and showroom appointments.";
    }
  },
};

export function buildWhatsAppLink(phone: string, text: string): string {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
}

export function formatINR(val: number | null | undefined): string {
  if (val === null || val === undefined || isNaN(val)) return 'Price on Request';
  return `₹${Math.round(val).toLocaleString('en-IN')}`;
}
