export interface Product {
  id: string;
  sku: string;
  name: string;
  slug: string;
  category: string;
  description: string;
  primaryImage: string;
  additionalImages: string[];
  goldPurity: string;
  grossWeight: number;
  netGoldWeight: number;
  stoneWeight: number;
  stoneDetails: string;
  makingChargesPerGram: number;
  isPriceVerified: boolean;
  price: number | null;
  availability: string;
  isFeatured: boolean;
  isNewArrival: boolean;
  showIn3DShowroom: boolean;
  showroomZone: 'necklaces' | 'bangles' | 'rings' | 'chains' | 'pendants' | 'reception';
  lastUpdated: string;
  adminNotes?: string;
}

export interface GoldRates {
  rate24kPerGram: number;
  rate22kPerGram: number;
  rate18kPerGram: number;
  silverRatePerGram: number;
  currency: string;
  symbol: string;
  updatedAt: string;
  rateSource: string;
  isManual: boolean;
}

export interface StoreSettings {
  storeName: string;
  tagline: string;
  phone: string;
  whatsappNumber: string;
  email: string;
  address: string;
  businessHours: string;
  instagram: string;
  website: string;
  gstPercentage: number;
  hallmarkNotice: string;
}

export interface Enquiry {
  id: string;
  customerName: string;
  phone: string;
  email?: string;
  productId?: string;
  productName?: string;
  enquiryType: string;
  message: string;
  status: 'New' | 'Contacted' | 'Follow-up' | 'Quotation Requested' | 'Converted' | 'Closed';
  notes?: string;
  createdAt: string;
}

export interface Appointment {
  id: string;
  customerName: string;
  phone: string;
  email?: string;
  preferredDate: string;
  preferredTimeSlot: string;
  categoryOfInterest: string;
  productId?: string;
  guestCount: number;
  message?: string;
  status: 'Requested' | 'Confirmed' | 'Completed' | 'Cancelled';
  notes?: string;
  createdAt: string;
}
