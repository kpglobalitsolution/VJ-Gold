import React from 'react';
import { Sparkles, Calendar, Info, Gift, TrendingUp } from 'lucide-react';
import { GoldRates } from '../types';

interface GoldRateTickerProps {
  rates: GoldRates;
  onOpenEstimator?: () => void;
  onOpenGiftVoucher?: () => void;
  onOpenTrend?: () => void;
}

export const GoldRateTicker: React.FC<GoldRateTickerProps> = ({
  rates,
  onOpenEstimator,
  onOpenGiftVoucher,
  onOpenTrend,
}) => {
  const updatedDate = new Date(rates.updatedAt).toLocaleDateString('en-IN', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  return (
    <div className="bg-[#101114] border-y border-[#23242A] py-3 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Source info */}
        <div className="flex items-center gap-2.5 text-xs text-[#9CA3AF]">
          <span className="font-semibold uppercase tracking-wider text-[#E6C687] flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
            Official Bullion Rates
          </span>
          <span className="text-[#4B5563]">|</span>
          <span className="flex items-center gap-1 text-[11px] text-[#A1A1AA]">
            <Calendar className="w-3 h-3 text-[#71717A]" />
            {updatedDate}
          </span>
        </div>

        {/* Rate figures */}
        <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-7 text-xs">
          <div className="flex items-baseline gap-2">
            <span className="text-[#9CA3AF] text-[11px]">24K (999) /g:</span>
            <span className="font-mono tabular-nums font-semibold text-[#F3F4F6] text-sm">
              ₹{rates.rate24kPerGram.toLocaleString('en-IN')}
            </span>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-[#9CA3AF] text-[11px]">22K (916) /g:</span>
            <span className="font-mono tabular-nums font-semibold text-[#E6C687] text-sm">
              ₹{rates.rate22kPerGram.toLocaleString('en-IN')}
            </span>
          </div>

          <div className="flex items-baseline gap-2">
            <span className="text-[#9CA3AF] text-[11px]">18K (750) /g:</span>
            <span className="font-mono tabular-nums font-semibold text-[#D1D5DB] text-sm">
              ₹{rates.rate18kPerGram.toLocaleString('en-IN')}
            </span>
          </div>

          <div className="hidden sm:flex items-baseline gap-2">
            <span className="text-[#9CA3AF] text-[11px]">Silver /g:</span>
            <span className="font-mono tabular-nums font-semibold text-[#9CA3AF] text-sm">
              ₹{rates.silverRatePerGram.toLocaleString('en-IN')}
            </span>
          </div>

          <div className="flex items-center gap-3 pl-2 sm:border-l border-[#282933]">
            {onOpenTrend && (
              <button
                onClick={onOpenTrend}
                className="text-[11px] font-medium text-[#E6C687] hover:text-[#FFF8E7] flex items-center gap-1 transition-colors"
                title="View 30-Day Historical Trend"
              >
                <TrendingUp className="w-3 h-3" />
                <span>30D Trend</span>
              </button>
            )}

            {onOpenEstimator && (
              <button
                onClick={onOpenEstimator}
                className="text-[11px] font-medium text-[#D1D5DB] hover:text-[#FFF8E7] flex items-center gap-1 transition-colors"
              >
                <Info className="w-3 h-3" />
                <span>Estimator</span>
              </button>
            )}

            {onOpenGiftVoucher && (
              <button
                onClick={onOpenGiftVoucher}
                className="text-[11px] font-medium text-[#E6C687] hover:text-white flex items-center gap-1 transition-colors"
                title="Create Digital Gift Voucher"
              >
                <Gift className="w-3 h-3 text-[#D4AF37]" />
                <span className="hidden sm:inline">Gift Voucher</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
