import React from 'react';
import { Product } from '../types';
import { formatINR, buildWhatsAppLink } from '../services/api';
import {
  X,
  Scale,
  Sparkles,
  MessageCircle,
  Eye,
  Trash2,
  CheckCircle2,
  ShieldCheck,
  RotateCw,
  Plus,
} from 'lucide-react';

interface ProductCompareModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onRemove: (productId: string) => void;
  onClear: () => void;
  onSelectProduct: (product: Product) => void;
  onInspect3D: (product: Product) => void;
  whatsappNumber: string;
}

export const ProductCompareModal: React.FC<ProductCompareModalProps> = ({
  isOpen,
  onClose,
  products,
  onRemove,
  onClear,
  onSelectProduct,
  onInspect3D,
  whatsappNumber,
}) => {
  if (!isOpen) return null;

  const maxSlots = 3;
  const emptySlotsCount = Math.max(0, maxSlots - products.length);

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="max-w-5xl w-full bg-[#101115] border border-[#D4AF37]/50 rounded-sm shadow-2xl p-5 sm:p-7 relative my-auto max-h-[94vh] flex flex-col space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#212228] pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#E6C687]">
              <Scale className="w-4 h-4 text-[#D4AF37]" />
              <span>Atelier Spec Comparison</span>
            </div>
            <h2 className="font-serif text-2xl font-bold text-[#F3F4F6]">
              Side-by-Side Jewellery Comparison
            </h2>
            <p className="text-xs text-[#9CA3AF]">
              Comparing weight, metal purity, making charges, and valuation across selected boutique creations.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {products.length > 0 && (
              <button
                onClick={onClear}
                className="text-xs text-[#9CA3AF] hover:text-red-400 transition-colors flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="text-[#9CA3AF] hover:text-white p-1"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Empty state if no items */}
        {products.length === 0 ? (
          <div className="py-16 text-center space-y-4">
            <Scale className="w-12 h-12 text-[#4B5563] mx-auto" />
            <h3 className="font-serif text-lg font-bold text-[#F3F4F6]">
              No Pieces Selected for Comparison
            </h3>
            <p className="text-xs text-[#9CA3AF] max-w-sm mx-auto">
              Browse our catalogue and click the 'Compare' badge on any piece to evaluate weights, purity, and pricing side-by-side.
            </p>
            <button
              onClick={onClose}
              className="px-6 py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors"
            >
              Back to Catalogue
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto pb-2">
            <div className="min-w-[700px] space-y-4">
              {/* Product Card Headers Grid */}
              <div className="grid grid-cols-4 gap-4 items-start">
                {/* Metric Label Column */}
                <div className="pt-8">
                  <span className="text-[10px] uppercase tracking-widest text-[#71717A] font-semibold block">
                    Product Details ({products.length}/3)
                  </span>
                </div>

                {/* Product Columns */}
                {products.map((p) => (
                  <div
                    key={p.id}
                    className="bg-[#14151B] border border-[#2B2D38] hover:border-[#D4AF37]/50 rounded-sm p-4 relative group space-y-3"
                  >
                    <button
                      onClick={() => onRemove(p.id)}
                      className="absolute top-2 right-2 p-1 text-[#71717A] hover:text-red-400 rounded-sm z-10"
                      title="Remove from comparison"
                    >
                      <X className="w-4 h-4" />
                    </button>

                    <div
                      onClick={() => {
                        onSelectProduct(p);
                        onClose();
                      }}
                      className="aspect-square bg-[#08090C] rounded-sm overflow-hidden cursor-pointer"
                    >
                      <img
                        src={p.primaryImage}
                        alt={p.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>

                    <div className="space-y-1">
                      <div className="text-[10px] uppercase tracking-wider text-[#A1A1AA]">{p.category}</div>
                      <h4
                        onClick={() => {
                          onSelectProduct(p);
                          onClose();
                        }}
                        className="font-serif font-bold text-sm text-[#F3F4F6] hover:text-[#E6C687] cursor-pointer line-clamp-2"
                      >
                        {p.name}
                      </h4>
                      <div className="text-[11px] font-mono text-[#71717A]">SKU: {p.sku}</div>
                    </div>

                    {/* Quick Action buttons */}
                    <div className="grid grid-cols-2 gap-1.5 pt-1">
                      <button
                        onClick={() => {
                          onSelectProduct(p);
                          onClose();
                        }}
                        className="py-1.5 text-[11px] font-medium text-[#D1D5DB] hover:text-white bg-[#1A1C24] hover:bg-[#252834] border border-[#2B2D38] rounded-sm text-center flex items-center justify-center gap-1"
                      >
                        <Eye className="w-3 h-3" />
                        <span>Specs</span>
                      </button>

                      <button
                        onClick={() => {
                          onInspect3D(p);
                          onClose();
                        }}
                        className="py-1.5 text-[11px] font-medium text-[#E6C687] hover:text-[#0B0C0E] bg-[#1A1812] hover:bg-[#D4AF37] border border-[#D4AF37]/40 rounded-sm text-center flex items-center justify-center gap-1 transition-colors"
                      >
                        <RotateCw className="w-3 h-3" />
                        <span>3D Orbit</span>
                      </button>
                    </div>
                  </div>
                ))}

                {/* Empty slots placeholders */}
                {Array.from({ length: emptySlotsCount }).map((_, idx) => (
                  <div
                    key={`empty-${idx}`}
                    onClick={onClose}
                    className="border-2 border-dashed border-[#22242E] hover:border-[#D4AF37]/50 rounded-sm p-6 flex flex-col items-center justify-center text-center space-y-2 cursor-pointer transition-colors min-h-[260px]"
                  >
                    <div className="w-10 h-10 rounded-full bg-[#161720] flex items-center justify-center text-[#71717A]">
                      <Plus className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-medium text-[#D1D5DB]">Add Piece to Compare</span>
                    <span className="text-[10px] text-[#71717A]">
                      Select another item from catalogue (slot {products.length + idx + 1} of 3)
                    </span>
                  </div>
                ))}
              </div>

              {/* Comparison Data Table */}
              <div className="divide-y divide-[#1D1E26] border-t border-b border-[#212228] text-xs">
                {/* 1. Indicative Price Row */}
                <div className="grid grid-cols-4 gap-4 py-3 items-center bg-[#13141A]/50">
                  <div className="font-semibold text-[#D1D5DB] flex items-center gap-1.5">
                    <span>Indicative Price</span>
                  </div>
                  {products.map((p) => (
                    <div key={p.id} className="font-mono tabular-nums font-bold text-base text-[#E6C687]">
                      {formatINR(p.price)}
                    </div>
                  ))}
                  {Array.from({ length: emptySlotsCount }).map((_, i) => (
                    <div key={i} className="text-[#4B5563] text-xs">—</div>
                  ))}
                </div>

                {/* 2. Gold Purity Row */}
                <div className="grid grid-cols-4 gap-4 py-3 items-center">
                  <div className="font-semibold text-[#D1D5DB] flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Gold Purity & Hallmark</span>
                  </div>
                  {products.map((p) => (
                    <div key={p.id} className="space-y-0.5">
                      <span className="font-semibold text-[#F3F4F6] block">{p.goldPurity}</span>
                      <span className="text-[10px] text-[#10B981] flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>BIS Certified</span>
                      </span>
                    </div>
                  ))}
                  {Array.from({ length: emptySlotsCount }).map((_, i) => (
                    <div key={i} className="text-[#4B5563] text-xs">—</div>
                  ))}
                </div>

                {/* 3. Gross Weight Row */}
                <div className="grid grid-cols-4 gap-4 py-3 items-center">
                  <div className="font-semibold text-[#D1D5DB] flex items-center gap-1.5">
                    <Scale className="w-3.5 h-3.5 text-[#D4AF37]" />
                    <span>Gross Total Weight</span>
                  </div>
                  {products.map((p) => (
                    <div key={p.id} className="font-mono tabular-nums font-bold text-[#F3F4F6]">
                      {p.grossWeight} grams
                    </div>
                  ))}
                  {Array.from({ length: emptySlotsCount }).map((_, i) => (
                    <div key={i} className="text-[#4B5563] text-xs">—</div>
                  ))}
                </div>

                {/* 4. Net Gold Content Row */}
                <div className="grid grid-cols-4 gap-4 py-3 items-center">
                  <div className="font-semibold text-[#D1D5DB]">
                    <span>Net Gold Weight</span>
                  </div>
                  {products.map((p) => (
                    <div key={p.id} className="font-mono tabular-nums font-semibold text-[#E6C687]">
                      {p.netGoldWeight} grams
                    </div>
                  ))}
                  {Array.from({ length: emptySlotsCount }).map((_, i) => (
                    <div key={i} className="text-[#4B5563] text-xs">—</div>
                  ))}
                </div>

                {/* 5. Precious Stones Row */}
                <div className="grid grid-cols-4 gap-4 py-3 items-center">
                  <div className="font-semibold text-[#D1D5DB]">
                    <span>Gemstones & Diamonds</span>
                  </div>
                  {products.map((p) => (
                    <div key={p.id} className="text-[11px] text-[#D1D5DB] leading-snug">
                      {p.stoneDetails}
                    </div>
                  ))}
                  {Array.from({ length: emptySlotsCount }).map((_, i) => (
                    <div key={i} className="text-[#4B5563] text-xs">—</div>
                  ))}
                </div>

                {/* 6. Making Charges Row */}
                <div className="grid grid-cols-4 gap-4 py-3 items-center">
                  <div className="font-semibold text-[#D1D5DB]">
                    <span>Making Charges (Indicative)</span>
                  </div>
                  {products.map((p) => (
                    <div key={p.id} className="font-mono tabular-nums text-xs text-[#D1D5DB]">
                      ₹{p.makingChargesPerGram} / gram
                    </div>
                  ))}
                  {Array.from({ length: emptySlotsCount }).map((_, i) => (
                    <div key={i} className="text-[#4B5563] text-xs">—</div>
                  ))}
                </div>

                {/* 7. Showroom Availability Row */}
                <div className="grid grid-cols-4 gap-4 py-3 items-center">
                  <div className="font-semibold text-[#D1D5DB]">
                    <span>Availability</span>
                  </div>
                  {products.map((p) => (
                    <div key={p.id} className="text-xs font-medium text-[#10B981]">
                      {p.availability}
                    </div>
                  ))}
                  {Array.from({ length: emptySlotsCount }).map((_, i) => (
                    <div key={i} className="text-[#4B5563] text-xs">—</div>
                  ))}
                </div>

                {/* 8. WhatsApp Inquiry Row */}
                <div className="grid grid-cols-4 gap-4 py-3 items-center">
                  <div className="font-semibold text-[#D1D5DB]">
                    <span>WhatsApp Inquiry</span>
                  </div>
                  {products.map((p) => (
                    <div key={p.id}>
                      <a
                        href={buildWhatsAppLink(
                          whatsappNumber,
                          `Hello VJ Gold, I am comparing items in your catalogue. Please provide verified quotation & details for: ${p.name} (SKU: ${p.sku}) at ${formatINR(p.price)}.`
                        )}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#25D366] hover:bg-[#20bd5a] text-[#0B0C0E] font-semibold text-[11px] rounded-sm transition-colors"
                      >
                        <MessageCircle className="w-3.5 h-3.5" />
                        <span>Enquire</span>
                      </a>
                    </div>
                  ))}
                  {Array.from({ length: emptySlotsCount }).map((_, i) => (
                    <div key={i} />
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#9CA3AF]">
          <span className="text-[11px]">
            * Actual jewellery weights and making charges are hallmarked and measured with certified digital scales upon boutique invoice.
          </span>
          <button
            onClick={onClose}
            className="px-6 py-2 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors"
          >
            Done Comparing
          </button>
        </div>
      </div>
    </div>
  );
};
