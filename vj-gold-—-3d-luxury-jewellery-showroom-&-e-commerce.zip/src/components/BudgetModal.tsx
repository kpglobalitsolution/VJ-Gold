import React, { useState } from 'react';
import { Product } from '../types';
import { formatINR, buildWhatsAppLink } from '../services/api';
import { X, DollarSign, Sparkles, ArrowRight, MessageCircle } from 'lucide-react';

interface BudgetModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onSelectProduct: (product: Product) => void;
  whatsappNumber: string;
}

export const BudgetModal: React.FC<BudgetModalProps> = ({
  isOpen,
  onClose,
  products,
  onSelectProduct,
  whatsappNumber,
}) => {
  if (!isOpen) return null;

  const [selectedRange, setSelectedRange] = useState<string>('any');

  const budgetBrackets = [
    { id: 'under-100k', label: 'Under ₹1,00,000', min: 0, max: 100000 },
    { id: '100k-250k', label: '₹1,00,000 – ₹2,50,000', min: 100000, max: 250000 },
    { id: '250k-400k', label: '₹2,50,000 – ₹4,00,000', min: 250000, max: 400000 },
    { id: 'above-400k', label: '₹4,00,000+ (High Bridal)', min: 400000, max: 99999999 },
    { id: 'any', label: 'All Budgets', min: 0, max: 99999999 },
  ];

  const currentBracket = budgetBrackets.find((b) => b.id === selectedRange) || budgetBrackets[4];

  const matchingProducts = products.filter((p) => {
    if (selectedRange === 'any') return true;
    if (!p.price) return true; // Products on request are included
    return p.price >= currentBracket.min && p.price <= currentBracket.max;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-[#101115] border border-[#D4AF37]/50 rounded-sm shadow-2xl p-6 relative max-h-[90vh] flex flex-col space-y-4">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9CA3AF] hover:text-white p-1"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="space-y-1 pb-3 border-b border-[#212228]">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-[#E6C687]">
            Personalized Jewellery Guidance
          </span>
          <h2 className="font-serif text-2xl font-bold text-[#F3F4F6]">
            Select Your Target Budget
          </h2>
          <p className="text-xs text-[#9CA3AF]">
            Our sales consultant will filter our verified atelier collection to present the most exquisite pieces within your comfortable investment range.
          </p>
        </div>

        {/* Range Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {budgetBrackets.map((bracket) => (
            <button
              key={bracket.id}
              onClick={() => setSelectedRange(bracket.id)}
              className={`p-3 rounded-sm border text-xs text-left transition-all ${
                selectedRange === bracket.id
                  ? 'bg-[#E6C687] text-[#0B0C0E] border-[#D4AF37] font-semibold shadow-md'
                  : 'bg-[#15161D] text-[#D1D5DB] border-[#25262F] hover:bg-[#1C1E26]'
              }`}
            >
              {bracket.label}
            </button>
          ))}
        </div>

        {/* Results */}
        <div className="flex-1 overflow-y-auto space-y-3 pt-2">
          <div className="text-xs text-[#9CA3AF] flex items-center justify-between">
            <span>Found {matchingProducts.length} piece(s) matching your preference</span>
            <span className="text-[#E6C687] text-[11px]">100% BIS Hallmarked</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {matchingProducts.map((p) => (
              <div
                key={p.id}
                onClick={() => {
                  onSelectProduct(p);
                  onClose();
                }}
                className="bg-[#15161D] border border-[#25262F] hover:border-[#D4AF37] p-3 rounded-sm cursor-pointer transition-all flex gap-3 group"
              >
                <img
                  src={p.primaryImage}
                  alt={p.name}
                  className="w-16 h-16 object-cover rounded-sm border border-[#2B2D38] group-hover:scale-105 transition-transform"
                />
                <div className="flex-1 min-w-0">
                  <div className="text-[10px] text-[#A1A1AA] uppercase">{p.category}</div>
                  <h4 className="font-serif text-xs font-bold text-[#F3F4F6] truncate group-hover:text-[#E6C687]">
                    {p.name}
                  </h4>
                  <div className="text-[10px] text-[#9CA3AF] mt-0.5">
                    {p.goldPurity} · {p.grossWeight}g
                  </div>
                  <div className="font-mono tabular-nums text-xs font-semibold text-[#E6C687] mt-1">
                    {formatINR(p.price)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Custom inquiry */}
        <div className="pt-3 border-t border-[#212228] flex flex-col sm:flex-row items-center justify-between gap-3">
          <span className="text-[11px] text-[#9CA3AF]">
            Looking for a bespoke customized weight or design?
          </span>
          <a
            href={buildWhatsAppLink(
              whatsappNumber,
              `Hello VJ Gold, I have a specific budget in mind (${currentBracket.label}) and would like custom recommendations.`
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-[#25D366] bg-[#25D366]/10 border border-[#25D366]/30 rounded-sm hover:bg-[#25D366]/20 transition-colors whitespace-nowrap"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Discuss on WhatsApp</span>
          </a>
        </div>
      </div>
    </div>
  );
};
