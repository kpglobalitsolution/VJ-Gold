import React, { useState } from 'react';
import { Product } from '../types';
import { api, buildWhatsAppLink } from '../services/api';
import { Sparkles, Send, Volume2, VolumeX, X, MessageCircle } from 'lucide-react';

interface ConsultantModalProps {
  product?: Product | null;
  isOpen: boolean;
  onClose: () => void;
  whatsappNumber: string;
}

interface Message {
  sender: 'consultant' | 'customer';
  text: string;
  time: string;
}

export const ConsultantModal: React.FC<ConsultantModalProps> = ({
  product,
  isOpen,
  onClose,
  whatsappNumber,
}) => {
  if (!isOpen) return null;

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [speechEnabled, setSpeechEnabled] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: 'consultant',
      text: product
        ? `Namaste and welcome to VJ Gold. I see you are exploring "${product.name}" (SKU: ${product.sku}). How may I assist you with purity, weight, pricing, or styling details?`
        : `Namaste and welcome to VJ Gold. I am your fine jewellery consultant. Feel free to ask about our chokers, necklaces, daily bullion rates, hallmark certification, or bespoke custom creations.`,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const speakText = (text: string) => {
    if (!speechEnabled || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 0.95;
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
  };

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || input;
    if (!textToSend.trim() || loading) return;

    const userMsg: Message = {
      sender: 'customer',
      text: textToSend,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!queryText) setInput('');
    setLoading(true);

    try {
      const reply = await api.askConsultant(textToSend, product?.id);
      const consultantMsg: Message = {
        sender: 'consultant',
        text: reply,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, consultantMsg]);
      speakText(reply);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'consultant',
          text: 'Thank you for your enquiry. For immediate live assistance, please tap the WhatsApp button below to speak directly with our senior jewellery team.',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const sampleQuestions = product
    ? [
        `What is the gold purity and certification?`,
        `What are the making charges on this piece?`,
        `Is this set available for showroom trial?`,
        `Can I customize this with emerald or ruby stones?`,
      ]
    : [
        `Show me the Imperial Emerald Choker Set`,
        `What are today's 22K and 24K gold rates?`,
        `How do I book a private bridal consultation?`,
        `Tell me about VJ Gold's hallmark guarantee`,
      ];

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="max-w-xl w-full bg-[#101115] border border-[#D4AF37]/50 rounded-sm shadow-2xl flex flex-col h-[600px] overflow-hidden">
        {/* Header */}
        <div className="p-4 bg-[#14151B] border-b border-[#282932] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-sm bg-gradient-to-br from-[#E6C687] to-[#D4AF37] p-0.5 flex items-center justify-center">
              <div className="w-full h-full bg-[#101115] flex items-center justify-center font-serif text-[#E6C687] font-bold text-sm">
                VJ
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-serif font-bold text-sm text-[#F3F4F6]">
                  VJ Gold Virtual Consultant
                </h3>
                <span className="text-[10px] text-[#A1A1AA] uppercase tracking-wider">
                  Verified Catalogue
                </span>
              </div>
              <div className="text-[11px] text-[#9CA3AF]">
                {product ? `Focusing on: ${product.name}` : 'Consulting on all collections & gold rates'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                const next = !speechEnabled;
                setSpeechEnabled(next);
                if (!next && 'speechSynthesis' in window) window.speechSynthesis.cancel();
              }}
              className={`p-1.5 rounded-sm border transition-colors ${
                speechEnabled
                  ? 'text-[#E6C687] border-[#D4AF37] bg-[#E6C687]/10'
                  : 'text-[#9CA3AF] border-[#2A2B32] hover:text-white'
              }`}
              title={speechEnabled ? 'Mute Speech' : 'Enable Voice Synthesis'}
            >
              {speechEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-[#9CA3AF] hover:text-white border border-transparent hover:border-[#2A2B32] rounded-sm"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Message Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 scrollbar-thin">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex flex-col ${
                m.sender === 'customer' ? 'items-end' : 'items-start'
              }`}
            >
              <div
                className={`max-w-[85%] rounded-sm p-3 text-xs leading-relaxed ${
                  m.sender === 'customer'
                    ? 'bg-[#E6C687] text-[#0B0C0E] font-medium'
                    : 'bg-[#181920] border border-[#2B2D38] text-[#E5E7EB]'
                }`}
              >
                {m.text}
              </div>
              <span className="text-[9px] text-[#6B7280] mt-1 px-1">{m.time}</span>
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2 text-xs text-[#E6C687] italic p-2">
              <Sparkles className="w-3.5 h-3.5 animate-spin" />
              <span>Consultant is retrieving verified details...</span>
            </div>
          )}
        </div>

        {/* Quick Sample Questions */}
        <div className="p-2.5 bg-[#14151B] border-t border-[#23242B] overflow-x-auto flex gap-1.5 scrollbar-none">
          {sampleQuestions.map((q, i) => (
            <button
              key={i}
              onClick={() => handleSend(q)}
              disabled={loading}
              className="text-[11px] whitespace-nowrap shrink-0 px-2.5 py-1 text-[#D1D5DB] hover:text-[#FFF8E7] bg-[#1A1C24] hover:bg-[#252834] border border-[#2B2D38] rounded-sm transition-colors"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Input & WhatsApp Action Bar */}
        <div className="p-3 bg-[#101115] border-t border-[#23242B] space-y-2">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about weight, pricing, purity, or customization..."
              className="flex-1 bg-[#181920] border border-[#2B2D38] rounded-sm px-3 py-2 text-xs text-[#F3F4F6] placeholder-[#6B7280] focus:outline-none focus:border-[#D4AF37]"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="px-4 py-2 bg-[#D4AF37] hover:bg-[#E5C158] disabled:opacity-50 text-[#0B0C0E] text-xs font-semibold rounded-sm transition-colors flex items-center justify-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Ask</span>
            </button>
          </form>

          <div className="flex items-center justify-between text-[11px] text-[#9CA3AF] pt-1">
            <span>Answers grounded strictly in verified VJ Gold catalogue</span>
            <a
              href={buildWhatsAppLink(
                whatsappNumber,
                product
                  ? `Hello VJ Gold, I was discussing ${product.name} (SKU: ${product.sku}) with your virtual consultant. I would like to speak with a human jeweller for official quotation.`
                  : `Hello VJ Gold, I would like to speak with a human jeweller on WhatsApp.`
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[#25D366] hover:underline flex items-center gap-1 font-medium"
            >
              <MessageCircle className="w-3 h-3" />
              <span>Switch to WhatsApp Consultant</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
