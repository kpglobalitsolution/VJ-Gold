import React from 'react';
import { Phone, Mail, MapPin, Clock, ShieldCheck, Instagram, ExternalLink } from 'lucide-react';
import { StoreSettings } from '../types';

interface FooterProps {
  settings: StoreSettings;
  onNavigate: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ settings, onNavigate }) => {
  return (
    <footer className="bg-[#08090B] text-[#9CA3AF] border-t border-[#1F2025]">
      {/* Hallmark & Trust Strip */}
      <div className="border-b border-[#1A1B20] py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3 text-[#E6C687]">
            <ShieldCheck className="w-5 h-5 shrink-0" />
            <span className="font-medium tracking-wide">
              {settings.hallmarkNotice || '100% BIS Hallmarked 916 & 750 Gold Guaranteed'}
            </span>
          </div>
          <div className="flex items-center gap-6 text-[#9CA3AF]">
            <span>100% Certified Natural Diamonds</span>
            <span>·</span>
            <span>Transparent Weight Accounting</span>
            <span>·</span>
            <span>Lifetime Buyback & Exchange</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="font-serif text-2xl font-bold tracking-[0.2em] text-[#F3F4F6]">
                VJ GOLD
              </span>
            </div>
            <p className="text-xs leading-relaxed text-[#9CA3AF]">
              Bespoke luxury gold, emerald, and diamond jewellery. Every design reflects timeless Indian heritage sculpted with contemporary haute joaillerie precision.
            </p>
            <div className="pt-2 flex items-center gap-3">
              <a
                href={settings.instagram || 'https://www.instagram.com/vj._.gold/'}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-[#E6C687] bg-[#16171B] border border-[#2B2D34] rounded-sm hover:border-[#D4AF37] transition-colors"
              >
                <Instagram className="w-3.5 h-3.5" />
                <span>@vj._.gold</span>
                <ExternalLink className="w-3 h-3 opacity-60" />
              </a>
            </div>
          </div>

          {/* Quick Navigation */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-widest text-[#E6C687] mb-4">
              Explore Showroom
            </h3>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('showroom')}
                  className="hover:text-white transition-colors"
                >
                  Enter 3D Digital Showroom
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('shop')}
                  className="hover:text-white transition-colors"
                >
                  Imperial Necklace Sets
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('rates')}
                  className="hover:text-white transition-colors"
                >
                  Daily Gold & Bullion Rates
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('about')}
                  className="hover:text-white transition-colors"
                >
                  Craftsmanship & Hallmarking
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-white transition-colors"
                >
                  Book Private Consultation
                </button>
              </li>
            </ul>
          </div>

          {/* Contact Details */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-widest text-[#E6C687] mb-4">
              Flagship Boutique
            </h3>
            <ul className="space-y-3 text-xs leading-relaxed">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>{settings.address}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>{settings.phone}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#D4AF37] shrink-0" />
                <span>{settings.email}</span>
              </li>
              <li className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <span>{settings.businessHours}</span>
              </li>
            </ul>
          </div>

          {/* Verified Guarantee */}
          <div className="bg-[#121316] border border-[#212228] p-5 rounded-sm space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#F3F4F6]">
              Verified Store Inquiry
            </h4>
            <p className="text-xs text-[#9CA3AF] leading-relaxed">
              Gold and bullion rates change daily. Our store consultants provide exact quotations based on current weights, making charges, and BIS gold rates.
            </p>
            <button
              onClick={() => onNavigate('contact')}
              className="w-full py-2 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors text-center"
            >
              Contact Boutique Desk
            </button>
          </div>
        </div>

        {/* Bottom strip */}
        <div className="mt-12 pt-8 border-t border-[#1A1B20] flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-[#6B7280]">
          <div>
            © {new Date().getFullYear()} VJ Gold. All rights reserved. Fine Jewellery & Bullion.
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => onNavigate('admin')}
              className="text-[#9CA3AF] hover:text-[#E6C687] transition-colors"
            >
              Staff Admin Portal
            </button>
            <span>·</span>
            <span>Privacy Policy</span>
            <span>·</span>
            <span>Terms of Service</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
