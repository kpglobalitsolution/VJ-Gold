import React, { useEffect, useRef, useState } from 'react';
import { Product } from '../types';
import { buildWhatsAppLink } from '../services/api';
import {
  X,
  Camera,
  RefreshCw,
  Download,
  MessageCircle,
  Move,
  Maximize2,
  Minimize2,
  Sliders,
  Sparkles,
  Upload,
  AlertCircle,
  Check,
  RotateCcw,
} from 'lucide-react';

interface VirtualTryOnModalProps {
  isOpen: boolean;
  onClose: () => void;
  product: Product;
  whatsappNumber: string;
}

export const VirtualTryOnModal: React.FC<VirtualTryOnModalProps> = ({
  isOpen,
  onClose,
  product,
  whatsappNumber,
}) => {
  if (!isOpen) return null;

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');

  // Overlay Transform Controls
  const [scale, setScale] = useState<number>(1.0);
  const [offsetY, setOffsetY] = useState<number>(35); // percentage from top (near neck)
  const [offsetX, setOffsetX] = useState<number>(0); // percentage offset from center
  const [opacity, setOpacity] = useState<number>(0.95);
  const [capturedSnapshot, setCapturedSnapshot] = useState<string | null>(null);

  // Fallback portrait background if camera unavailable
  const [customPhoto, setCustomPhoto] = useState<string | null>(null);

  // Start Camera
  const startCamera = async (mode: 'user' | 'environment') => {
    setCameraError(null);
    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }

      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera access is not supported by your browser.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: mode,
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setCameraActive(true);
    } catch (err: any) {
      console.warn('Camera failed:', err);
      setCameraError(
        err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError'
          ? 'Camera permission was denied. You can upload a photo or use our luxury mannequin silhouettes below.'
          : 'Unable to start camera stream. You can upload a portrait or try on pre-set neckline models.'
      );
      setCameraActive(false);
    }
  };

  useEffect(() => {
    startCamera(facingMode);
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, [facingMode]);

  // Flip Camera
  const handleToggleFacingMode = () => {
    setFacingMode((prev) => (prev === 'user' ? 'environment' : 'user'));
  };

  // Handle Photo Upload as fallback
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setCustomPhoto(event.target.result as string);
          setCameraActive(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Take Snapshot
  const handleTakeSnapshot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = 800;
    const height = 800;
    canvas.width = width;
    canvas.height = height;

    // Draw background video or custom photo
    if (cameraActive && videoRef.current) {
      // Draw video centered and cropped
      const video = videoRef.current;
      const vRatio = video.videoWidth / video.videoHeight;
      const cRatio = width / height;
      let sWidth = video.videoWidth;
      let sHeight = video.videoHeight;
      let sx = 0;
      let sy = 0;

      if (vRatio > cRatio) {
        sWidth = video.videoHeight * cRatio;
        sx = (video.videoWidth - sWidth) / 2;
      } else {
        sHeight = video.videoWidth / cRatio;
        sy = (video.videoHeight - sHeight) / 2;
      }

      ctx.save();
      // If user facing, mirror the canvas draw
      if (facingMode === 'user') {
        ctx.translate(width, 0);
        ctx.scale(-1, 1);
      }
      ctx.drawImage(video, sx, sy, sWidth, sHeight, 0, 0, width, height);
      ctx.restore();
    } else if (customPhoto) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.src = customPhoto;
      ctx.drawImage(img, 0, 0, width, height);
    } else {
      // Dark studio backdrop fallback
      ctx.fillStyle = '#101115';
      ctx.fillRect(0, 0, width, height);
    }

    // Draw Jewellery Overlay on top
    const jewelImg = new Image();
    jewelImg.crossOrigin = 'anonymous';
    jewelImg.src = product.primaryImage;
    jewelImg.onload = () => {
      ctx.save();
      ctx.globalAlpha = opacity;

      const baseJewelSize = width * 0.55 * scale;
      const posX = (width - baseJewelSize) / 2 + (offsetX * width) / 100;
      const posY = (offsetY * height) / 100;

      ctx.drawImage(jewelImg, posX, posY, baseJewelSize, baseJewelSize);

      // Watermark & Brand Seal
      ctx.globalAlpha = 1.0;
      ctx.fillStyle = '#E6C687';
      ctx.font = 'bold 20px serif';
      ctx.fillText('VJ GOLD · VIRTUAL TRY-ON', 30, height - 40);
      ctx.font = '14px sans-serif';
      ctx.fillStyle = '#D1D5DB';
      ctx.fillText(`${product.name} (SKU: ${product.sku})`, 30, height - 18);

      ctx.restore();
      const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
      setCapturedSnapshot(dataUrl);
    };
  };

  const handleDownloadSnapshot = () => {
    if (!capturedSnapshot) return;
    const a = document.createElement('a');
    a.href = capturedSnapshot;
    a.download = `VJ_Gold_TryOn_${product.sku}.jpg`;
    a.click();
  };

  const resetPosition = () => {
    setScale(1.0);
    setOffsetY(35);
    setOffsetX(0);
    setOpacity(0.95);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="max-w-4xl w-full bg-[#101115] border border-[#D4AF37]/50 rounded-sm shadow-2xl p-5 sm:p-6 relative my-auto max-h-[94vh] flex flex-col space-y-4">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9CA3AF] hover:text-white p-1 z-30"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#212228] pb-3 pr-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#E6C687]">
              <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
              <span>Augmented Fine Jewellery Studio</span>
            </div>
            <h2 className="font-serif text-xl sm:text-2xl font-bold text-[#F3F4F6] mt-0.5">
              Virtual Try-On: {product.name}
            </h2>
            <div className="text-xs text-[#9CA3AF]">
              {product.goldPurity} · Gross Weight {product.grossWeight}g · SKU: {product.sku}
            </div>
          </div>
        </div>

        {/* Main Stage Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          {/* Visual Mirror Viewport (7 cols) */}
          <div className="lg:col-span-7 relative aspect-[4/5] bg-[#0A0B0E] border border-[#262731] rounded-sm overflow-hidden flex items-center justify-center shadow-2xl">
            {/* Live Camera Video */}
            <video
              ref={videoRef}
              playsInline
              muted
              className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-300 ${
                cameraActive && !capturedSnapshot ? 'opacity-100' : 'opacity-0 pointer-events-none'
              } ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
            />

            {/* Custom Uploaded Photo or Default Mannequin Silhouette Background */}
            {(!cameraActive || customPhoto) && !capturedSnapshot && (
              <div className="absolute inset-0 w-full h-full flex flex-col items-center justify-center p-6 text-center bg-gradient-to-b from-[#14151D] via-[#0D0E12] to-[#0A0B0E]">
                {customPhoto ? (
                  <img
                    src={customPhoto}
                    alt="Custom portrait"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="space-y-4 max-w-sm">
                    <div className="w-20 h-20 mx-auto rounded-full bg-[#181922] border border-[#2D2F3C] flex items-center justify-center text-[#E6C687]">
                      <Camera className="w-8 h-8 opacity-70" />
                    </div>

                    <div className="space-y-1">
                      <h4 className="font-serif text-lg font-bold text-[#F3F4F6]">
                        Camera Preview Inactive
                      </h4>
                      <p className="text-xs text-[#9CA3AF] leading-relaxed">
                        {cameraError || 'Activate your camera to try this necklace live, or upload a portrait.'}
                      </p>
                    </div>

                    <div className="flex flex-col gap-2 pt-2">
                      <button
                        onClick={() => startCamera(facingMode)}
                        className="px-4 py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors flex items-center justify-center gap-1.5"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>Retry Camera Access</span>
                      </button>

                      <label className="px-4 py-2 text-xs font-medium text-[#D1D5DB] bg-[#1A1C24] hover:bg-[#222530] border border-[#2B2D38] rounded-sm cursor-pointer transition-colors flex items-center justify-center gap-1.5">
                        <Upload className="w-3.5 h-3.5 text-[#E6C687]" />
                        <span>Upload Portrait Photo</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleFileUpload}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Captured Snapshot Display */}
            {capturedSnapshot && (
              <div className="absolute inset-0 w-full h-full z-20 bg-black">
                <img
                  src={capturedSnapshot}
                  alt="Captured try-on"
                  className="w-full h-full object-contain"
                />
                <button
                  onClick={() => setCapturedSnapshot(null)}
                  className="absolute top-3 left-3 bg-[#121316]/90 border border-[#2B2D38] px-3 py-1.5 rounded-sm text-xs text-[#E6C687] hover:text-white"
                >
                  ← Return to Live Mirror
                </button>
              </div>
            )}

            {/* Live Jewellery Visual Overlay (when not in snapshot view) */}
            {!capturedSnapshot && (
              <div
                className="absolute z-10 pointer-events-none transition-transform duration-75 select-none"
                style={{
                  top: `${offsetY}%`,
                  left: `calc(50% + ${offsetX}%)`,
                  transform: `translate(-50%, -50%) scale(${scale})`,
                  opacity: opacity,
                  width: '58%',
                }}
              >
                <img
                  src={product.primaryImage}
                  alt={product.name}
                  className="w-full h-auto drop-shadow-[0_12px_24px_rgba(0,0,0,0.85)]"
                />
              </div>
            )}

            {/* Top Mirror Overlay Indicators */}
            <div className="absolute top-3 right-3 z-10 flex items-center gap-2">
              {cameraActive && !capturedSnapshot && (
                <button
                  onClick={handleToggleFacingMode}
                  className="p-2 bg-[#121316]/85 border border-[#2B2D38] text-[#D1D5DB] hover:text-white rounded-sm text-xs backdrop-blur-md"
                  title="Switch Front/Rear Camera"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Hidden canvas for capturing merged snapshot */}
            <canvas ref={canvasRef} className="hidden" />
          </div>

          {/* Interactive Controls & Fine-Tuning Column (5 cols) */}
          <div className="lg:col-span-5 bg-[#14151B] border border-[#24252D] rounded-sm p-5 flex flex-col justify-between space-y-5">
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-[#212228]">
                <span className="text-xs font-semibold uppercase tracking-wider text-[#E6C687] flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5" />
                  <span>Neckline & Position Fit</span>
                </span>
                <button
                  onClick={resetPosition}
                  className="text-[11px] text-[#A1A1AA] hover:text-white flex items-center gap-1"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset</span>
                </button>
              </div>

              {/* Position Nudge Controls */}
              <div className="space-y-2 text-xs">
                <span className="text-[#9CA3AF] text-[11px] block">Nudge Placement:</span>
                <div className="grid grid-cols-3 gap-1.5 max-w-[200px] mx-auto text-center">
                  <div />
                  <button
                    onClick={() => setOffsetY((prev) => Math.max(10, prev - 4))}
                    className="p-2 bg-[#1A1C24] hover:bg-[#252834] text-[#F3F4F6] border border-[#2B2D38] rounded-sm text-xs font-bold"
                    title="Nudge Upward"
                  >
                    ▲
                  </button>
                  <div />
                  <button
                    onClick={() => setOffsetX((prev) => Math.max(-30, prev - 3))}
                    className="p-2 bg-[#1A1C24] hover:bg-[#252834] text-[#F3F4F6] border border-[#2B2D38] rounded-sm text-xs font-bold"
                    title="Nudge Left"
                  >
                    ◀
                  </button>
                  <div className="flex items-center justify-center text-[10px] text-[#71717A]">
                    <Move className="w-3.5 h-3.5" />
                  </div>
                  <button
                    onClick={() => setOffsetX((prev) => Math.min(30, prev + 3))}
                    className="p-2 bg-[#1A1C24] hover:bg-[#252834] text-[#F3F4F6] border border-[#2B2D38] rounded-sm text-xs font-bold"
                    title="Nudge Right"
                  >
                    ▶
                  </button>
                  <div />
                  <button
                    onClick={() => setOffsetY((prev) => Math.min(80, prev + 4))}
                    className="p-2 bg-[#1A1C24] hover:bg-[#252834] text-[#F3F4F6] border border-[#2B2D38] rounded-sm text-xs font-bold"
                    title="Nudge Downward"
                  >
                    ▼
                  </button>
                  <div />
                </div>
              </div>

              {/* Sliders: Scale & Opacity */}
              <div className="space-y-3 pt-2 text-xs">
                <div>
                  <div className="flex justify-between text-[#9CA3AF] mb-1">
                    <span>Jewellery Proportions (Scale):</span>
                    <span className="font-mono tabular-nums text-[#E6C687] font-semibold">{Math.round(scale * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.6}
                    max={1.6}
                    step={0.05}
                    value={scale}
                    onChange={(e) => setScale(parseFloat(e.target.value))}
                    className="w-full accent-[#D4AF37] cursor-pointer"
                  />
                </div>

                <div>
                  <div className="flex justify-between text-[#9CA3AF] mb-1">
                    <span>Luminance & Opacity:</span>
                    <span className="font-mono tabular-nums text-[#D1D5DB]">{Math.round(opacity * 100)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.4}
                    max={1.0}
                    step={0.05}
                    value={opacity}
                    onChange={(e) => setOpacity(parseFloat(e.target.value))}
                    className="w-full accent-[#D4AF37] cursor-pointer"
                  />
                </div>
              </div>

              {/* Guidance Tips */}
              <div className="p-3 bg-[#111216] border border-[#212228] rounded-sm text-[11px] text-[#9CA3AF] space-y-1">
                <span className="text-[#E6C687] font-semibold block">Stylist Guidance:</span>
                <p>
                  Align your collar bones with the choker curve for realistic scale. Take a snapshot to share with family or the VJ Gold boutique master.
                </p>
              </div>
            </div>

            {/* Actions: Snapshot Capture / Download / WhatsApp */}
            <div className="space-y-2 pt-2 border-t border-[#212228]">
              {!capturedSnapshot ? (
                <button
                  onClick={handleTakeSnapshot}
                  className="w-full py-3 text-xs font-bold uppercase tracking-wider text-[#0B0C0E] bg-gradient-to-r from-[#E6C687] to-[#D4AF37] hover:from-[#F0D8A8] hover:to-[#E5C158] rounded-sm transition-all flex items-center justify-center gap-2 shadow-md"
                >
                  <Camera className="w-4 h-4" />
                  <span>Capture Try-On Snapshot</span>
                </button>
              ) : (
                <div className="space-y-2">
                  <button
                    onClick={handleDownloadSnapshot}
                    className="w-full py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Snapshot</span>
                  </button>

                  <a
                    href={buildWhatsAppLink(
                      whatsappNumber,
                      `Hello VJ Gold, I just tried on the ${product.name} (SKU: ${product.sku}) in your Virtual Try-On mirror. I would like to consult your stylist on sizing and price.`
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#25D366] hover:bg-[#20bd5a] rounded-sm transition-colors flex items-center justify-center gap-1.5"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                    <span>Share Try-On with Stylist on WhatsApp</span>
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
