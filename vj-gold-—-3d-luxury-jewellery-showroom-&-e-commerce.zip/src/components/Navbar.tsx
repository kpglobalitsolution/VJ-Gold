import React, { useState } from 'react';
import { Menu, X, MessageCircle, Calendar, Heart, Compass, Crown, Gift } from 'lucide-react';
import { buildWhatsAppLink } from '../services/api';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  onOpenAppointment: () => void;
  onOpenEnquiryBasket: () => void;
  onOpenLoyaltyRewards: () => void;
  onOpenGiftVoucher: () => void;
  basketCount: number;
  whatsappNumber: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  onOpenAppointment,
  onOpenEnquiryBasket,
  onOpenLoyaltyRewards,
  onOpenGiftVoucher,
  basketCount,
  whatsappNumber,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'showroom', label: '3D Showroom' },
    { id: 'shop', label: 'Catalogue' },
    { id: 'rates', label: 'Gold Rates' },
    { id: 'about', label: 'Heritage' },
    { id: 'contact', label: 'Contact' },
    { id: 'admin', label: 'Store Admin' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#0B0C0E]/95 backdrop-blur-md border-b border-[#2A2B30]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-6">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <a
          href="#showroom"
          onClick={(e) => {
            e.preventDefault();
            setCurrentTab('showroom');
          }}
          className="group flex items-center gap-3 whitespace-nowrap shrink-0 text-left"
        >
          <div className="w-9 h-9 rounded-sm bg-gradient-to-br from-[#E6C687] via-[#D4AF37] to-[#996515] p-0.5 shadow-sm flex items-center justify-center">
            <div className="w-full h-full bg-[#0B0C0E] flex items-center justify-center font-serif text-[#E6C687] font-semibold text-lg tracking-wider">
              VJ
            </div>
          </div>
          <div className="flex flex-col">
            <span className="font-serif text-xl sm:text-2xl font-bold tracking-[0.2em] text-[#F3F4F6] group-hover:text-[#E6C687] transition-colors">
              VJ GOLD
            </span>
            <span className="text-[10px] tracking-[0.3em] uppercase text-[#A1A1AA]">
              3D Digital Showroom
            </span>
          </div>
        </a>

        {/* Zone 2: Navigation Links (Single-line text links) */}
        <nav className="hidden xl:flex items-center gap-6 text-sm font-medium tracking-wide">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => setCurrentTab(link.id)}
              className={`transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                currentTab === link.id
                  ? 'text-[#E6C687] border-[#D4AF37]'
                  : 'text-[#D1D5DB] hover:text-[#F3F4F6] border-transparent'
              }`}
            >
              {link.label}
            </button>
          ))}
        </nav>

        {/* Zone 3: Actions - Loyalty, Gift Voucher, Basket, Book Visit */}
        <div className="hidden sm:flex items-center gap-2.5 shrink-0">
          <button
            onClick={onOpenLoyaltyRewards}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#E6C687] bg-[#1A1812] hover:bg-[#252219] border border-[#D4AF37]/40 rounded-sm transition-colors whitespace-nowrap"
            title="View Loyalty Rewards & Patron Standing"
          >
            <Crown className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>Patron Rewards</span>
          </button>

          <button
            onClick={onOpenGiftVoucher}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#D1D5DB] hover:text-white bg-[#14151B] hover:bg-[#1E1F27] border border-[#2B2D38] rounded-sm transition-colors whitespace-nowrap"
            title="Create Digital Gift Voucher"
          >
            <Gift className="w-3.5 h-3.5 text-[#E6C687]" />
            <span>Gift Voucher</span>
          </button>

          <button
            onClick={onOpenEnquiryBasket}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-[#F3F4F6] bg-[#16171E] hover:bg-[#20222A] border border-[#2B2D38] rounded-sm transition-colors whitespace-nowrap"
            title="Open Consultation Basket"
          >
            <Heart className={`w-3.5 h-3.5 ${basketCount > 0 ? 'text-rose-400 fill-rose-400' : 'text-[#9CA3AF]'}`} />
            <span>Basket ({basketCount})</span>
          </button>

          <button
            onClick={onOpenAppointment}
            className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-[#0B0C0E] bg-gradient-to-r from-[#E6C687] to-[#D4AF37] hover:from-[#F0D8A8] hover:to-[#E5C158] rounded-sm transition-all shadow-sm whitespace-nowrap shrink-0"
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Book Visit</span>
          </button>
        </div>

        {/* Mobile Menu Button */}
        <div className="xl:hidden flex items-center gap-2">
          <button
            onClick={onOpenLoyaltyRewards}
            className="p-2 text-[#E6C687] hover:text-white"
            title="Loyalty Rewards"
            aria-label="Loyalty Rewards"
          >
            <Crown className="w-5 h-5 text-[#D4AF37]" />
          </button>

          <button
            onClick={onOpenEnquiryBasket}
            className="p-2 text-[#D1D5DB] hover:text-white relative"
            aria-label="Enquiry Basket"
          >
            <Heart className="w-5 h-5 text-rose-400" />
            {basketCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-rose-500 text-[9px] text-white flex items-center justify-center font-bold">
                {basketCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#D1D5DB] hover:text-white"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-[#121316] border-b border-[#2A2B30] px-4 pt-3 pb-6 space-y-2">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => {
                setCurrentTab(link.id);
                setMobileMenuOpen(false);
              }}
              className={`block w-full text-left px-3 py-2.5 text-sm font-medium rounded-sm ${
                currentTab === link.id
                  ? 'text-[#E6C687] bg-[#1E1F24]'
                  : 'text-[#D1D5DB] hover:bg-[#1A1B20]'
              }`}
            >
              {link.label}
            </button>
          ))}
          <div className="pt-3 border-t border-[#2A2B30] flex flex-col gap-2">
            <button
              onClick={() => {
                onOpenLoyaltyRewards();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#E6C687] bg-[#1A1812] border border-[#D4AF37]/50 rounded-sm"
            >
              <Crown className="w-4 h-4 text-[#D4AF37]" />
              <span>Patron Loyalty Rewards & Tiers</span>
            </button>

            <button
              onClick={() => {
                onOpenGiftVoucher();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#D1D5DB] bg-[#14151B] border border-[#2B2D38] rounded-sm"
            >
              <Gift className="w-4 h-4 text-[#E6C687]" />
              <span>Generate Digital Gift Voucher (QR)</span>
            </button>

            <button
              onClick={() => {
                onOpenAppointment();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] rounded-sm"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Showroom Visit</span>
            </button>

            <a
              href={buildWhatsAppLink(
                whatsappNumber,
                'Hello VJ Gold, I would like to speak directly with the shop owner.'
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-medium text-[#25D366] bg-[#25D366]/10 border border-[#25D366]/30 rounded-sm"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp Shop Owner</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
