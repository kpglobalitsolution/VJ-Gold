import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Product } from '../types';
import { RotateCw, ZoomIn, ZoomOut, Sparkles, MessageCircle, ArrowLeft, ShieldCheck } from 'lucide-react';
import { buildWhatsAppLink, formatINR } from '../services/api';

interface ShowroomInspectorProps {
  product: Product;
  onBack: () => void;
  whatsappNumber: string;
  onOpenConsultant: (product: Product) => void;
}

export const ShowroomInspector: React.FC<ShowroomInspectorProps> = ({
  product,
  onBack,
  whatsappNumber,
  onOpenConsultant,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [autoRotate, setAutoRotate] = useState(true);
  const [zoomLevel, setZoomLevel] = useState(1);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0b0d);

    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 0.6, 2.8);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    renderer.shadowMap.enabled = true;
    container.appendChild(renderer.domElement);

    // Procedural RoomEnvironment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Studio 3-point lighting
    const keyLight = new THREE.DirectionalLight(0xfff5e6, 3.5);
    keyLight.position.set(3, 4, 3);
    keyLight.castShadow = true;
    scene.add(keyLight);

    const fillLight = new THREE.DirectionalLight(0xdce7ff, 2.0);
    fillLight.position.set(-3, 2, 2);
    scene.add(fillLight);

    const rimLight = new THREE.SpotLight(0xffe2b3, 4.0, 10, Math.PI / 4, 0.2);
    rimLight.position.set(0, 4, -3);
    scene.add(rimLight);

    // Ground contact shadow disc
    const contactGeo = new THREE.CircleGeometry(1.2, 32);
    const contactMat = new THREE.MeshBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.45,
    });
    const contactDisc = new THREE.Mesh(contactGeo, contactMat);
    contactDisc.rotation.x = -Math.PI / 2;
    contactDisc.position.y = -0.65;
    scene.add(contactDisc);

    // Main Jewellery Object Group
    const jewelGroup = new THREE.Group();
    scene.add(jewelGroup);

    // High-fidelity Materials
    const goldMat = new THREE.MeshPhysicalMaterial({
      color: 0xe6c687,
      metalness: 0.95,
      roughness: 0.12,
      clearcoat: 0.4,
    });

    const roseGoldMat = new THREE.MeshPhysicalMaterial({
      color: 0xdf9d7d,
      metalness: 0.95,
      roughness: 0.14,
      clearcoat: 0.4,
    });

    const emeraldMat = new THREE.MeshPhysicalMaterial({
      color: 0x0fa868,
      metalness: 0.1,
      roughness: 0.04,
      transmission: 0.92,
      ior: 1.58,
      thickness: 1.0,
    });

    const diamondMat = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      metalness: 0.0,
      roughness: 0.02,
      transmission: 0.97,
      ior: 2.42,
      thickness: 0.6,
    });

    const velvetMat = new THREE.MeshStandardMaterial({
      color: 0x0d0e12,
      roughness: 0.95,
    });

    // Build specific procedural 3D model according to product
    if (product.id === 'vjg-nc-001') {
      // Imperial Emerald Choker Set
      const bust = new THREE.Mesh(
        new THREE.CylinderGeometry(0.35, 0.55, 0.7, 32),
        velvetMat
      );
      bust.position.y = -0.3;
      jewelGroup.add(bust);

      // Choker Collar Arch
      const collar = new THREE.Mesh(
        new THREE.TorusGeometry(0.44, 0.024, 16, 48, Math.PI * 1.35),
        roseGoldMat
      );
      collar.position.set(0, 0.1, 0.05);
      collar.rotation.x = Math.PI / 2.3;
      collar.rotation.z = Math.PI * 0.825;
      jewelGroup.add(collar);

      // Multi-strand chains
      for (let s = 1; s <= 4; s++) {
        const chain = new THREE.Mesh(
          new THREE.TorusGeometry(0.44 + s * 0.03, 0.007, 8, 32, Math.PI * 0.8),
          roseGoldMat
        );
        chain.position.set(0, 0.1 - s * 0.025, 0.06);
        chain.rotation.x = Math.PI / 2.2;
        chain.rotation.z = Math.PI * 0.6;
        jewelGroup.add(chain);
      }

      // Centerpiece Medallion Oval Ring
      const medallion = new THREE.Mesh(
        new THREE.TorusGeometry(0.12, 0.018, 16, 32),
        roseGoldMat
      );
      medallion.position.set(0, -0.15, 0.42);
      medallion.scale.set(1.4, 0.8, 1);
      jewelGroup.add(medallion);

      // Center Natural Oval Emerald Gem
      const emerald = new THREE.Mesh(
        new THREE.SphereGeometry(0.08, 24, 24),
        emeraldMat
      );
      emerald.position.set(0, -0.15, 0.43);
      emerald.scale.set(1.3, 0.9, 0.4);
      jewelGroup.add(emerald);

      // Diamond halo ring around emerald
      const halo = new THREE.Mesh(
        new THREE.TorusGeometry(0.1, 0.012, 12, 32),
        diamondMat
      );
      halo.position.set(0, -0.15, 0.43);
      halo.scale.set(1.4, 0.9, 1);
      jewelGroup.add(halo);

      // Dangling teardrop tassels
      for (let i = -3; i <= 3; i++) {
        const tassel = new THREE.Mesh(
          new THREE.ConeGeometry(0.02, 0.08, 12),
          roseGoldMat
        );
        tassel.position.set(i * 0.045, -0.28 - Math.abs(i) * 0.015, 0.42);
        tassel.rotation.x = Math.PI;
        jewelGroup.add(tassel);

        const tipDiamond = new THREE.Mesh(
          new THREE.OctahedronGeometry(0.012),
          diamondMat
        );
        tipDiamond.position.set(i * 0.045, -0.33 - Math.abs(i) * 0.015, 0.42);
        jewelGroup.add(tipDiamond);
      }
    } else if (product.id === 'vjg-nc-002') {
      // Amour Lattice Mint Enamel Choker Set
      const bust = new THREE.Mesh(
        new THREE.CylinderGeometry(0.35, 0.55, 0.7, 32),
        velvetMat
      );
      bust.position.y = -0.3;
      jewelGroup.add(bust);

      // Quilted lattice band
      const collar = new THREE.Mesh(
        new THREE.TorusGeometry(0.44, 0.03, 16, 48, Math.PI * 1.35),
        goldMat
      );
      collar.position.set(0, 0.1, 0.05);
      collar.rotation.x = Math.PI / 2.3;
      collar.rotation.z = Math.PI * 0.825;
      jewelGroup.add(collar);

      // Mint green enamel heart medallion
      const heartMedallion = new THREE.Mesh(
        new THREE.CylinderGeometry(0.1, 0.1, 0.03, 24),
        new THREE.MeshPhysicalMaterial({
          color: 0x98e4c7,
          roughness: 0.1,
          metalness: 0.1,
          clearcoat: 0.8,
        })
      );
      heartMedallion.position.set(0, -0.15, 0.43);
      heartMedallion.rotation.x = Math.PI / 2;
      jewelGroup.add(heartMedallion);

      // Solitaire diamond center in heart
      const diamondHeart = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.03),
        diamondMat
      );
      diamondHeart.position.set(0, -0.15, 0.45);
      jewelGroup.add(diamondHeart);

      // Dual ribbon tails with diamond terminals
      for (let r = -1; r <= 1; r += 2) {
        const tail = new THREE.Mesh(
          new THREE.BoxGeometry(0.04, 0.22, 0.015),
          goldMat
        );
        tail.position.set(r * 0.04, -0.3, 0.42);
        tail.rotation.z = r * 0.15;
        jewelGroup.add(tail);

        const tip = new THREE.Mesh(
          new THREE.BoxGeometry(0.044, 0.04, 0.02),
          diamondMat
        );
        tip.position.set(r * 0.055, -0.42, 0.42);
        jewelGroup.add(tip);
      }
    } else {
      // General high-luxury rotating jewellery piece
      const pedestal = new THREE.Mesh(
        new THREE.CylinderGeometry(0.4, 0.45, 0.2, 32),
        velvetMat
      );
      pedestal.position.y = -0.5;
      jewelGroup.add(pedestal);

      const torus = new THREE.Mesh(
        new THREE.TorusGeometry(0.32, 0.045, 24, 48),
        goldMat
      );
      torus.position.y = -0.1;
      torus.rotation.x = Math.PI / 3;
      jewelGroup.add(torus);

      const gem = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.1),
        diamondMat
      );
      gem.position.set(0, 0.15, 0.18);
      jewelGroup.add(gem);
    }

    // Pointer Drag to Rotate
    let isDragging = false;
    let prevMouseX = 0;
    let prevMouseY = 0;

    const onPointerDown = (e: MouseEvent) => {
      isDragging = true;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onPointerMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - prevMouseX;
      const deltaY = e.clientY - prevMouseY;
      jewelGroup.rotation.y += deltaX * 0.008;
      jewelGroup.rotation.x += deltaY * 0.008;
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const onPointerUp = () => {
      isDragging = false;
    };

    renderer.domElement.addEventListener('mousedown', onPointerDown);
    window.addEventListener('mousemove', onPointerMove);
    window.addEventListener('mouseup', onPointerUp);

    // Animation Loop
    let animationId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animationId = requestAnimationFrame(animate);
      const delta = clock.getDelta();

      if (autoRotate && !isDragging) {
        jewelGroup.rotation.y += delta * 0.4;
      }

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('mousedown', onPointerDown);
      window.removeEventListener('mousemove', onPointerMove);
      window.removeEventListener('mouseup', onPointerUp);
      renderer.dispose();
      if (container && renderer.domElement) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [product, autoRotate]);

  return (
    <div className="bg-[#0B0C0E] border-t border-[#23242A] py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Navigation Bar */}
        <div className="flex items-center justify-between">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-xs font-medium text-[#E6C687] hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Showroom / Catalogue</span>
          </button>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setAutoRotate(!autoRotate)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-sm border transition-colors ${
                autoRotate
                  ? 'bg-[#E6C687]/10 text-[#E6C687] border-[#D4AF37]/40'
                  : 'bg-[#141519] text-[#9CA3AF] border-[#2B2D34]'
              }`}
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>{autoRotate ? 'Auto Orbit Active' : 'Auto Orbit Paused'}</span>
            </button>
          </div>
        </div>

        {/* 3D Orbit Canvas & Details Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* 3D WebGL Viewport (7 cols) */}
          <div className="lg:col-span-7 relative h-[520px] bg-gradient-to-b from-[#101115] to-[#08090B] border border-[#2B2D34] rounded-sm overflow-hidden shadow-2xl flex flex-col justify-between">
            <div className="p-4 z-10 flex items-center justify-between text-xs text-[#9CA3AF]">
              <span className="flex items-center gap-1.5 text-[#E6C687] font-semibold uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5" />
                3D Photorealistic Inspection Pedestal
              </span>
              <span className="text-[11px] text-[#A1A1AA]">
                Drag with mouse or finger to freely rotate 360°
              </span>
            </div>

            <div ref={mountRef} className="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing" />

            {/* Bottom Floating Hint */}
            <div className="p-4 z-10 flex items-center justify-between text-[11px] text-[#A1A1AA] bg-gradient-to-t from-[#0B0C0E]/90 to-transparent">
              <span>PBR Gold Refraction & Micro-Reflections</span>
              <span>BIS Hallmarked Masterpiece</span>
            </div>
          </div>

          {/* Product Specifications & Fast Inquiry (5 cols) */}
          <div className="lg:col-span-5 bg-[#121316] border border-[#282931] rounded-sm p-6 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider text-[#E6C687]">
                  {product.category}
                </span>
                <span className="text-xs text-[#9CA3AF] font-mono">SKU: {product.sku}</span>
              </div>

              <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#F3F4F6]">
                {product.name}
              </h2>

              <p className="text-xs text-[#9CA3AF] leading-relaxed">
                {product.description}
              </p>

              {/* Price Row */}
              <div className="pt-2 pb-3 border-y border-[#23242A] flex items-baseline justify-between">
                <div>
                  <span className="text-[10px] text-[#9CA3AF] uppercase tracking-wider">
                    Showroom Estimate
                  </span>
                  <div className="font-serif text-2xl font-bold text-[#E6C687] font-mono tabular-nums">
                    {formatINR(product.price)}
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-[#9CA3AF] uppercase tracking-wider">
                    Availability
                  </span>
                  <div className="text-xs font-semibold text-[#10B981]">
                    {product.availability}
                  </div>
                </div>
              </div>

              {/* Verified Specs Table */}
              <div className="space-y-2 text-xs">
                <h4 className="text-[11px] font-semibold uppercase tracking-wider text-[#D1D5DB]">
                  Verified Craftsmanship Specifications
                </h4>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-[#18191E] p-2.5 rounded-sm border border-[#25262D]">
                    <span className="text-[#9CA3AF] text-[10px] uppercase">Gold Purity:</span>
                    <div className="font-medium text-[#F3F4F6]">{product.goldPurity}</div>
                  </div>
                  <div className="bg-[#18191E] p-2.5 rounded-sm border border-[#25262D]">
                    <span className="text-[#9CA3AF] text-[10px] uppercase">Gross Weight:</span>
                    <div className="font-mono tabular-nums font-medium text-[#F3F4F6]">
                      {product.grossWeight} grams
                    </div>
                  </div>
                  <div className="bg-[#18191E] p-2.5 rounded-sm border border-[#25262D]">
                    <span className="text-[#9CA3AF] text-[10px] uppercase">Net Gold Weight:</span>
                    <div className="font-mono tabular-nums font-medium text-[#F3F4F6]">
                      {product.netGoldWeight} grams
                    </div>
                  </div>
                  <div className="bg-[#18191E] p-2.5 rounded-sm border border-[#25262D]">
                    <span className="text-[#9CA3AF] text-[10px] uppercase">Stone Details:</span>
                    <div className="font-medium text-[#F3F4F6] text-[11px] truncate" title={product.stoneDetails}>
                      {product.stoneDetails}
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 text-[11px] text-[#E6C687] bg-[#1A1812] p-2.5 rounded-sm border border-[#D4AF37]/30">
                <ShieldCheck className="w-4 h-4 shrink-0" />
                <span>BIS Hallmarked & Certified Natural Gemstones</span>
              </div>
            </div>

            {/* CTAs */}
            <div className="space-y-2 pt-2 border-t border-[#23242A]">
              <a
                href={buildWhatsAppLink(
                  whatsappNumber,
                  `Hello VJ Gold, I am inspecting ${product.name} (SKU: ${product.sku}). Please share the verified quotation, current gold rate, making charges and showroom availability.`
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 text-xs font-bold uppercase tracking-wider text-[#0B0C0E] bg-gradient-to-r from-[#25D366] to-[#128C7E] hover:opacity-95 rounded-sm transition-all flex items-center justify-center gap-2 shadow-lg"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Enquire on WhatsApp with Product ID</span>
              </a>

              <button
                onClick={() => onOpenConsultant(product)}
                className="w-full py-2.5 text-xs font-semibold text-[#E6C687] hover:text-[#FFF8E7] bg-[#18191E] hover:bg-[#22242B] border border-[#2B2D34] rounded-sm transition-colors text-center"
              >
                Discuss Specifications with Virtual Consultant
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
