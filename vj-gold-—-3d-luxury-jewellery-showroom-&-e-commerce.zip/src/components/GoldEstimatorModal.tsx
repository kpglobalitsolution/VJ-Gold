import React, { useState } from 'react';
import { GoldRates } from '../types';
import { Calculator, ShieldAlert, X, ArrowRight } from 'lucide-react';
import { formatINR } from '../services/api';

interface GoldEstimatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  rates: GoldRates;
  onOpenConsultant: () => void;
}

export const GoldEstimatorModal: React.FC<GoldEstimatorModalProps> = ({
  isOpen,
  onClose,
  rates,
  onOpenConsultant,
}) => {
  if (!isOpen) return null;

  const [weight, setWeight] = useState<number>(30);
  const [purity, setPurity] = useState<'24k' | '22k' | '18k'>('22k');
  const [makingChargePerGram, setMakingChargePerGram] = useState<number>(650);

  const ratePerGram =
    purity === '24k'
      ? rates.rate24kPerGram
      : purity === '22k'
      ? rates.rate22kPerGram
      : rates.rate18kPerGram;

  const goldValue = weight * ratePerGram;
  const makingCharges = weight * makingChargePerGram;
  const subtotal = goldValue + makingCharges;
  const gst = subtotal * 0.03; // 3% GST standard in India
  const totalEstimate = subtotal + gst;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="max-w-lg w-full bg-[#101115] border border-[#D4AF37]/50 rounded-sm shadow-2xl p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9CA3AF] hover:text-white p-1"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#E6C687]">
            <Calculator className="w-4 h-4 text-[#D4AF37]" />
            <span>Transparent Gold Jewellery Estimator</span>
          </div>

          <h2 className="font-serif text-2xl font-bold text-[#F3F4F6]">
            Estimate Jewellery Value
          </h2>

          <p className="text-xs text-[#9CA3AF] leading-relaxed">
            Calculate the breakdown of pure metal value, handcrafted making charges, and applicable GST using today's official VJ Gold bullion desk rates.
          </p>

          {/* Inputs */}
          <div className="space-y-3 pt-2 text-xs">
            <div>
              <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                Gold Purity
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPurity('24k')}
                  className={`py-2 px-3 rounded-sm border text-xs font-medium transition-colors ${
                    purity === '24k'
                      ? 'bg-[#E6C687] text-[#0B0C0E] border-[#D4AF37] font-semibold'
                      : 'bg-[#16171E] text-[#D1D5DB] border-[#2B2D38]'
                  }`}
                >
                  24K (999) · ₹{rates.rate24kPerGram}/g
                </button>
                <button
                  type="button"
                  onClick={() => setPurity('22k')}
                  className={`py-2 px-3 rounded-sm border text-xs font-medium transition-colors ${
                    purity === '22k'
                      ? 'bg-[#E6C687] text-[#0B0C0E] border-[#D4AF37] font-semibold'
                      : 'bg-[#16171E] text-[#D1D5DB] border-[#2B2D38]'
                  }`}
                >
                  22K (916) · ₹{rates.rate22kPerGram}/g
                </button>
                <button
                  type="button"
                  onClick={() => setPurity('18k')}
                  className={`py-2 px-3 rounded-sm border text-xs font-medium transition-colors ${
                    purity === '18k'
                      ? 'bg-[#E6C687] text-[#0B0C0E] border-[#D4AF37] font-semibold'
                      : 'bg-[#16171E] text-[#D1D5DB] border-[#2B2D38]'
                  }`}
                >
                  18K (750) · ₹{rates.rate18kPerGram}/g
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Estimated Weight (Grams)
                </label>
                <input
                  type="number"
                  min={1}
                  max={1000}
                  step={0.1}
                  value={weight}
                  onChange={(e) => setWeight(Math.max(0.1, parseFloat(e.target.value) || 0))}
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] font-mono tabular-nums focus:border-[#D4AF37] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Making Charges (₹ / Gram)
                </label>
                <input
                  type="number"
                  min={300}
                  max={2500}
                  step={50}
                  value={makingChargePerGram}
                  onChange={(e) => setMakingChargePerGram(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] font-mono tabular-nums focus:border-[#D4AF37] focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Itemized Breakdown Table */}
          <div className="bg-[#15161D] border border-[#262731] p-4 rounded-sm space-y-2 text-xs">
            <div className="flex justify-between text-[#9CA3AF]">
              <span>Gold Metal Value ({weight}g @ ₹{ratePerGram}/g):</span>
              <span className="font-mono tabular-nums text-[#F3F4F6]">{formatINR(goldValue)}</span>
            </div>
            <div className="flex justify-between text-[#9CA3AF]">
              <span>Handcrafted Making Charges ({weight}g @ ₹{makingChargePerGram}/g):</span>
              <span className="font-mono tabular-nums text-[#F3F4F6]">{formatINR(makingCharges)}</span>
            </div>
            <div className="flex justify-between text-[#9CA3AF] border-t border-[#23242B] pt-2">
              <span>Subtotal:</span>
              <span className="font-mono tabular-nums text-[#D1D5DB]">{formatINR(subtotal)}</span>
            </div>
            <div className="flex justify-between text-[#9CA3AF]">
              <span>Applicable GST (3%):</span>
              <span className="font-mono tabular-nums text-[#D1D5DB]">{formatINR(gst)}</span>
            </div>
            <div className="flex justify-between border-t border-[#2A2B35] pt-2 text-sm font-bold text-[#E6C687]">
              <span>Estimated Payable Amount:</span>
              <span className="font-mono tabular-nums text-base">{formatINR(totalEstimate)}</span>
            </div>
          </div>

          {/* Strict Disclaimer */}
          <div className="flex items-start gap-2 p-3 bg-[#1A1812] border border-[#D4AF37]/30 rounded-sm text-[11px] text-[#A1A1AA] leading-relaxed">
            <ShieldAlert className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
            <span>
              <strong>Important:</strong> Indicative estimate only. Actual gemstone weight, diamond certification grades, wastage, and daily bullion spot rates will be verified on the official invoice by VJ Gold.
            </span>
          </div>

          <div className="flex gap-2 pt-2">
            <button
              onClick={() => {
                onClose();
                onOpenConsultant();
              }}
              className="w-full py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors flex items-center justify-center gap-1.5"
            >
              <span>Discuss Exact Quotation with Consultant</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
