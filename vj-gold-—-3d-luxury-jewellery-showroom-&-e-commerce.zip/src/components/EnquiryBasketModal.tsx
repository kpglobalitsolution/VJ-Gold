import React, { useState } from 'react';
import { Product } from '../types';
import { buildWhatsAppLink, formatINR } from '../services/api';
import { X, Heart, Trash2, MessageCircle, Calendar, ShieldCheck, ArrowRight, Crown, Sparkles } from 'lucide-react';

interface EnquiryBasketModalProps {
  isOpen: boolean;
  onClose: () => void;
  basket: Product[];
  onRemove: (id: string) => void;
  onClear: () => void;
  onSelectProduct: (product: Product) => void;
  onOpenAppointment: () => void;
  onOpenLoyaltyRewards?: () => void;
  whatsappNumber: string;
}

export const EnquiryBasketModal: React.FC<EnquiryBasketModalProps> = ({
  isOpen,
  onClose,
  basket,
  onRemove,
  onClear,
  onSelectProduct,
  onOpenAppointment,
  onOpenLoyaltyRewards,
  whatsappNumber,
}) => {
  if (!isOpen) return null;

  const totalGrossWeight = basket.reduce((acc, p) => acc + (p.grossWeight || 0), 0);
  const totalNetGoldWeight = basket.reduce((acc, p) => acc + (p.netGoldWeight || 0), 0);
  const totalVerifiedPrice = basket.reduce((acc, p) => acc + (p.price || 0), 0);

  const whatsappMessage = `Hello VJ Gold, I have selected ${basket.length} piece(s) from your 3D digital showroom for boutique enquiry:

${basket
  .map(
    (p, idx) =>
      `${idx + 1}. ${p.name} (SKU: ${p.sku}) - ${p.goldPurity}, ${p.grossWeight}g ${
        p.price ? `- ${formatINR(p.price)}` : ''
      }`
  )
  .join('\n')}

Combined Gross Weight: ${totalGrossWeight.toFixed(1)}g
Please share the confirmed quotation, today's gold rate valuation, and arrange an in-store trial for these designs.`;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="max-w-xl w-full bg-[#101115] border border-[#D4AF37]/50 rounded-sm shadow-2xl p-6 relative max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9CA3AF] hover:text-white p-1"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="space-y-1 pb-4 border-b border-[#212228]">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-[#E6C687]">
            Showroom Consultation Basket
          </span>
          <h2 className="font-serif text-2xl font-bold text-[#F3F4F6]">
            Selected Jewellery ({basket.length})
          </h2>
          <p className="text-xs text-[#9CA3AF]">
            Pieces you have earmarked during your showroom walk for discussion with our jewellers.
          </p>
        </div>

        {basket.length === 0 ? (
          <div className="text-center py-12 space-y-4">
            <Heart className="w-12 h-12 text-[#4B5563] mx-auto" />
            <h3 className="font-serif text-lg font-bold text-[#F3F4F6]">
              Your Enquiry Basket is Empty
            </h3>
            <p className="text-xs text-[#9CA3AF] max-w-sm mx-auto leading-relaxed">
              As you walk through the 3D showroom and inspect display counters, click the heart icon to save pieces to this consultation list.
            </p>
            <button
              onClick={onClose}
              className="px-6 py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] rounded-sm"
            >
              Continue Exploring Showroom
            </button>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto py-4 space-y-3 divide-y divide-[#1D1E25]">
            {basket.map((p) => (
              <div key={p.id} className="pt-3 first:pt-0 flex items-center justify-between gap-3">
                <div
                  onClick={() => {
                    onSelectProduct(p);
                    onClose();
                  }}
                  className="flex items-center gap-3 cursor-pointer group flex-1"
                >
                  <img
                    src={p.primaryImage}
                    alt={p.name}
                    className="w-12 h-12 object-cover rounded-sm border border-[#2B2D38] group-hover:border-[#D4AF37]"
                  />
                  <div>
                    <h4 className="font-serif text-sm font-bold text-[#F3F4F6] group-hover:text-[#E6C687] line-clamp-1">
                      {p.name}
                    </h4>
                    <div className="text-[11px] text-[#A1A1AA]">
                      {p.goldPurity} · {p.grossWeight}g gross
                    </div>
                    <div className="font-mono tabular-nums text-xs font-semibold text-[#E6C687]">
                      {formatINR(p.price)}
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => onRemove(p.id)}
                  className="p-2 text-[#71717A] hover:text-red-400 transition-colors"
                  title="Remove piece"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}

        {basket.length > 0 && (
          <div className="pt-4 border-t border-[#212228] space-y-4">
            <div className="bg-[#16171E] border border-[#262731] p-3 rounded-sm text-xs space-y-1">
              <div className="flex justify-between text-[#9CA3AF]">
                <span>Total Gross Weight:</span>
                <span className="font-mono tabular-nums text-[#F3F4F6] font-semibold">
                  {totalGrossWeight.toFixed(1)} grams
                </span>
              </div>
              <div className="flex justify-between text-[#9CA3AF]">
                <span>Total Net Gold Weight:</span>
                <span className="font-mono tabular-nums text-[#E6C687] font-semibold">
                  {totalNetGoldWeight.toFixed(1)} grams
                </span>
              </div>
              {totalVerifiedPrice > 0 && (
                <div className="flex justify-between text-[#9CA3AF] border-t border-[#212228] pt-1">
                  <span>Indicative Combined Price:</span>
                  <span className="font-mono tabular-nums font-bold text-[#E6C687] text-sm">
                    {formatINR(totalVerifiedPrice)}
                  </span>
                </div>
              )}
            </div>

            {/* Loyalty Tier Progress Teaser */}
            {onOpenLoyaltyRewards && (
              <div
                onClick={() => {
                  onClose();
                  onOpenLoyaltyRewards();
                }}
                className="bg-gradient-to-r from-[#1A1812] via-[#221F17] to-[#1A1812] border border-[#D4AF37]/50 p-3 rounded-sm cursor-pointer hover:border-[#D4AF37] transition-all flex items-center justify-between gap-3 text-xs group"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-[#D4AF37]/20 flex items-center justify-center shrink-0">
                    <Crown className="w-4 h-4 text-[#D4AF37]" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase tracking-wider text-[#A1A1AA] block">
                      Estimated Patron Tier
                    </span>
                    <span className="font-serif font-bold text-sm text-[#F3F4F6] group-hover:text-[#E6C687]">
                      {totalVerifiedPrice >= 500000
                        ? 'Platinum Imperial Club'
                        : totalVerifiedPrice >= 200000
                        ? 'Gold Sovereign Tier'
                        : 'Silver Heritage Connoisseur'}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-[#E6C687] font-semibold flex items-center gap-1 group-hover:underline">
                    <span>View Tier Rewards & Waivers</span>
                    <ArrowRight className="w-3 h-3" />
                  </span>
                  <span className="text-[9px] text-[#71717A] block">
                    {totalVerifiedPrice >= 500000
                      ? 'Maximum 25% making charge waiver'
                      : totalVerifiedPrice >= 200000
                      ? `${formatINR(500000 - totalVerifiedPrice)} to Platinum`
                      : `${formatINR(200000 - totalVerifiedPrice)} to Gold`}
                  </span>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <a
                href={buildWhatsAppLink(whatsappNumber, whatsappMessage)}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 text-xs font-bold uppercase tracking-wider text-[#0B0C0E] bg-[#25D366] hover:bg-[#20bd5a] rounded-sm transition-all flex items-center justify-center gap-2 shadow-lg"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Send Enquiry to Shop Owner on WhatsApp</span>
              </a>

              <div className="flex gap-2">
                <button
                  onClick={() => {
                    onClose();
                    onOpenAppointment();
                  }}
                  className="flex-1 py-2 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors flex items-center justify-center gap-1.5"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Book Trial for These Pieces</span>
                </button>

                <button
                  onClick={onClear}
                  className="px-3 py-2 text-xs text-[#9CA3AF] hover:text-red-400 bg-[#16171E] border border-[#262731] rounded-sm"
                >
                  Clear All
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
