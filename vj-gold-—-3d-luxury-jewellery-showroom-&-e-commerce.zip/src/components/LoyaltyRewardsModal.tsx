import React, { useState } from 'react';
import { formatINR, buildWhatsAppLink } from '../services/api';
import {
  X,
  Crown,
  Award,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  ChevronRight,
  MessageCircle,
  Gem,
  Gift,
} from 'lucide-react';

interface LoyaltyRewardsModalProps {
  isOpen: boolean;
  onClose: () => void;
  basketTotal: number;
  whatsappNumber: string;
}

interface Tier {
  id: 'silver' | 'gold' | 'platinum';
  name: string;
  tagline: string;
  minSpend: number;
  maxSpend: number;
  badgeColor: string;
  benefits: string[];
}

const TIERS: Tier[] = [
  {
    id: 'silver',
    name: 'Silver Heritage',
    tagline: 'Entry privilege for discerning connoisseurs',
    minSpend: 0,
    maxSpend: 199999,
    badgeColor: '#A1A1AA',
    benefits: [
      'Lifetime BIS 916 Hallmark Purity Verification',
      'Complimentary Ultrasonic Gold Cleaning in Boutique',
      'Daily Bullion Rate WhatsApp Broadcast Alerts',
      'Invitation to Private Digital Showcase Previews',
    ],
  },
  {
    id: 'gold',
    name: 'Gold Sovereign',
    tagline: 'Elevated prestige with making charge waivers',
    minSpend: 200000,
    maxSpend: 499999,
    badgeColor: '#E6C687',
    benefits: [
      '15% Flat Waiver on All Handcrafted Making Charges',
      'Priority VIP Suite Booking for Bridal Trials',
      'Dedicated Senior Gemologist Consultation on WhatsApp',
      'Free Annual Diamond & Precious Stone Setting Inspection',
      'Complimentary Custom Ring Sizing and Polish',
    ],
  },
  {
    id: 'platinum',
    name: 'Platinum Imperial Club',
    tagline: 'The pinnacle of fine Indian haute joaillerie',
    minSpend: 500000,
    maxSpend: Infinity,
    badgeColor: '#E5E7EB',
    benefits: [
      '25% Flat Waiver on All Making Charges',
      'Private Home Trousseau Consultations with Security Escort',
      'Annual 24K (999) 1-Gram Gold Bullion Gift Coin on Anniversary',
      'Bespoke Artisan Commission Access with Chief Goldsmith',
      'Guaranteed Same-Day Gold Exchange at Live Spot Bullion Rate',
      'Exclusive Invitations to Rare Colombian Emerald Auctions',
    ],
  },
];

export const LoyaltyRewardsModal: React.FC<LoyaltyRewardsModalProps> = ({
  isOpen,
  onClose,
  basketTotal,
  whatsappNumber,
}) => {
  if (!isOpen) return null;

  // Let user view their tier based on current basket, or simulate their expected cumulative spend
  const [customSpend, setCustomSpend] = useState<number>(basketTotal || 0);

  // Determine current tier based on spend
  const currentTierIndex = TIERS.findIndex(
    (tier) => customSpend >= tier.minSpend && customSpend <= tier.maxSpend
  );
  const currentTier = TIERS[currentTierIndex] || TIERS[0];
  const nextTier = currentTierIndex < TIERS.length - 1 ? TIERS[currentTierIndex + 1] : null;

  // Calculate progress toward next tier
  let progressPercent = 100;
  let amountNeededForNext = 0;

  if (nextTier) {
    const tierRange = nextTier.minSpend - currentTier.minSpend;
    const progressIntoTier = customSpend - currentTier.minSpend;
    progressPercent = Math.min(100, Math.max(0, (progressIntoTier / tierRange) * 100));
    amountNeededForNext = Math.max(0, nextTier.minSpend - customSpend);
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="max-w-3xl w-full bg-[#101115] border border-[#D4AF37]/50 rounded-sm shadow-2xl p-6 sm:p-8 relative my-auto max-h-[92vh] flex flex-col space-y-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9CA3AF] hover:text-white p-1"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="space-y-1 pb-4 border-b border-[#212228]">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#E6C687]">
            <Crown className="w-4 h-4 text-[#D4AF37]" />
            <span>VJ Gold Patrons Guild</span>
          </div>
          <h2 className="font-serif text-2xl sm:text-3xl font-bold text-[#F3F4F6]">
            Loyalty Rewards & Patron Tiers
          </h2>
          <p className="text-xs text-[#9CA3AF] leading-relaxed max-w-xl">
            Our esteemed clientele enjoy progressive privileges, making charge waivers, private bridal suites, and annual bullion gifts based on their cumulative jewelry acquisition.
          </p>
        </div>

        {/* Current Tier Status Card */}
        <div className="bg-gradient-to-r from-[#161720] via-[#1B1D26] to-[#161720] border border-[#2D2F3C] p-5 sm:p-6 rounded-sm relative overflow-hidden space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <span className="text-[10px] text-[#A1A1AA] uppercase tracking-widest font-semibold block">
                Estimated Membership Standing
              </span>
              <div className="flex items-center gap-2.5">
                <Crown
                  className="w-6 h-6"
                  style={{ color: currentTier.badgeColor }}
                />
                <h3 className="font-serif text-2xl font-bold text-[#F3F4F6]">
                  {currentTier.name}
                </h3>
              </div>
              <p className="text-xs text-[#9CA3AF]">{currentTier.tagline}</p>
            </div>

            <div className="text-left sm:text-right bg-[#101115] sm:bg-transparent p-3 sm:p-0 rounded-sm border sm:border-0 border-[#2A2B35]">
              <span className="text-[10px] text-[#71717A] uppercase tracking-wider block">
                Consultation Spend Basis
              </span>
              <div className="font-mono text-xl sm:text-2xl font-bold text-[#E6C687] tabular-nums">
                {formatINR(customSpend)}
              </div>
              <span className="text-[10px] text-[#A1A1AA]">
                {basketTotal > 0 && customSpend === basketTotal
                  ? 'Based on your current enquiry basket'
                  : 'Simulated cumulative value'}
              </span>
            </div>
          </div>

          {/* Progress Bar towards next tier */}
          {nextTier ? (
            <div className="space-y-2 pt-2 border-t border-[#262833]">
              <div className="flex justify-between text-xs">
                <span className="text-[#D1D5DB] flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#D4AF37]" />
                  <span>Next: <strong className="text-[#F3F4F6]">{nextTier.name}</strong> (from {formatINR(nextTier.minSpend)})</span>
                </span>
                <span className="font-mono tabular-nums text-[#E6C687] font-semibold">
                  {formatINR(amountNeededForNext)} more needed
                </span>
              </div>

              {/* Progress Track */}
              <div className="w-full h-2.5 bg-[#0C0D10] border border-[#2B2D38] rounded-full overflow-hidden p-0.5">
                <div
                  className="h-full bg-gradient-to-r from-[#D4AF37] to-[#F3E5AB] rounded-full transition-all duration-500 shadow-sm"
                  style={{ width: `${Math.max(6, progressPercent)}%` }}
                />
              </div>

              <p className="text-[11px] text-[#9CA3AF] italic">
                Add pieces to your consultation basket or confirm past boutique acquisitions to elevate your tier.
              </p>
            </div>
          ) : (
            <div className="p-3 bg-emerald-950/20 border border-emerald-800/40 rounded-sm flex items-center gap-2 text-xs text-emerald-300">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-[#10B981]" />
              <span>You have attained our highest imperial standing with maximum making charge waivers and private atelier privileges.</span>
            </div>
          )}

          {/* Interactive spend calculator slider */}
          <div className="pt-2 flex flex-wrap items-center gap-2 text-xs">
            <span className="text-[#71717A] text-[11px]">Quick Spend Simulation:</span>
            <button
              onClick={() => setCustomSpend(basketTotal || 50000)}
              className="px-2.5 py-1 text-[11px] bg-[#121318] hover:bg-[#20222D] text-[#D1D5DB] border border-[#2B2D38] rounded-sm"
            >
              Current Basket ({formatINR(basketTotal)})
            </button>
            <button
              onClick={() => setCustomSpend(250000)}
              className="px-2.5 py-1 text-[11px] bg-[#121318] hover:bg-[#20222D] text-[#D1D5DB] border border-[#2B2D38] rounded-sm"
            >
              ₹2.5 Lakh (Gold)
            </button>
            <button
              onClick={() => setCustomSpend(550000)}
              className="px-2.5 py-1 text-[11px] bg-[#121318] hover:bg-[#20222D] text-[#D1D5DB] border border-[#2B2D38] rounded-sm"
            >
              ₹5.5 Lakh (Platinum)
            </button>
          </div>
        </div>

        {/* Tier Comparison Grid */}
        <div className="space-y-3">
          <h4 className="text-xs font-semibold uppercase tracking-wider text-[#D1D5DB]">
            Patron Tiers & Guaranteed Privileges
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 text-xs">
            {TIERS.map((tier) => {
              const isCurrent = tier.id === currentTier.id;
              return (
                <div
                  key={tier.id}
                  className={`p-4 rounded-sm border transition-all flex flex-col justify-between space-y-3 ${
                    isCurrent
                      ? 'bg-[#181922] border-[#D4AF37] shadow-lg ring-1 ring-[#D4AF37]/50'
                      : 'bg-[#121317] border-[#22232B] opacity-80'
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span
                        className="font-serif font-bold text-sm"
                        style={{ color: tier.badgeColor }}
                      >
                        {tier.name}
                      </span>
                      {isCurrent && (
                        <span className="text-[9px] bg-[#D4AF37] text-[#0B0C0E] font-bold px-1.5 py-0.5 rounded-sm uppercase tracking-wider">
                          Active Tier
                        </span>
                      )}
                    </div>

                    <div className="font-mono tabular-nums text-[11px] text-[#A1A1AA]">
                      {tier.maxSpend === Infinity
                        ? `${formatINR(tier.minSpend)}+`
                        : `${formatINR(tier.minSpend)} – ${formatINR(tier.maxSpend)}`}
                    </div>

                    <ul className="space-y-1.5 text-[11px] text-[#9CA3AF] pt-1">
                      {tier.benefits.map((b, i) => (
                        <li key={i} className="flex items-start gap-1.5 leading-snug">
                          <CheckCircle2 className="w-3 h-3 text-[#D4AF37] shrink-0 mt-0.5" />
                          <span>{b}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* WhatsApp & Concierge CTA */}
        <div className="pt-2 border-t border-[#212228] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <span className="text-[#9CA3AF] text-[11px]">
            Have past invoices with VJ Gold? Our concierge will link your history.
          </span>

          <a
            href={buildWhatsAppLink(
              whatsappNumber,
              `Hello VJ Gold Concierge, I would like to verify my Patron Tier standing (${currentTier.name}) and discuss my making charge waiver benefits.`
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#25D366] hover:bg-[#20bd5a] rounded-sm transition-colors whitespace-nowrap shadow-md"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Claim Tier Privileges on WhatsApp</span>
          </a>
        </div>
      </div>
    </div>
  );
};
