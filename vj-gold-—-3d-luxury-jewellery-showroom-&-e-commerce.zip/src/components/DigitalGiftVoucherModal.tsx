import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { formatINR, buildWhatsAppLink } from '../services/api';
import {
  X,
  Gift,
  QrCode,
  Sparkles,
  Download,
  MessageCircle,
  Copy,
  Check,
  Calendar,
  ShieldCheck,
  Heart,
  Share2,
} from 'lucide-react';

interface DigitalGiftVoucherModalProps {
  isOpen: boolean;
  onClose: () => void;
  whatsappNumber: string;
}

export const DigitalGiftVoucherModal: React.FC<DigitalGiftVoucherModalProps> = ({
  isOpen,
  onClose,
  whatsappNumber,
}) => {
  if (!isOpen) return null;

  const [amount, setAmount] = useState<number>(25000);
  const [recipientName, setRecipientName] = useState('');
  const [recipientPhone, setRecipientPhone] = useState('');
  const [senderName, setSenderName] = useState('');
  const [occasion, setOccasion] = useState('Wedding & Bridal Trousseau');
  const [message, setMessage] = useState('Wishing you a lifetime of happiness, brilliance, and timeless elegance.');

  // Generated state
  const [voucherGenerated, setVoucherGenerated] = useState(false);
  const [voucherCode, setVoucherCode] = useState('');
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [copiedCode, setCopiedCode] = useState(false);

  const cardRef = useRef<HTMLDivElement | null>(null);

  const presetAmounts = [10000, 25000, 50000, 100000, 250000];

  const handleGenerateVoucher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipientName.trim() || !senderName.trim()) {
      alert('Please enter both recipient and sender names.');
      return;
    }

    // Unique Voucher Code: VJG-VOUCH-[RANDOM]-[DENOM]
    const randomHex = Math.random().toString(36).substring(2, 7).toUpperCase();
    const code = `VJG-VOUCH-${randomHex}-${amount / 1000}K`;
    setVoucherCode(code);

    // Generate scannable QR Code URL
    const redemptionPayload = `https://www.vjgold.in/redeem?code=${code}&amt=${amount}&to=${encodeURIComponent(recipientName)}&from=${encodeURIComponent(senderName)}`;
    try {
      const url = await QRCode.toDataURL(redemptionPayload, {
        width: 320,
        margin: 1,
        color: {
          dark: '#0B0C0E',
          light: '#F5E6BE',
        },
      });
      setQrDataUrl(url);
      setVoucherGenerated(true);
    } catch (err) {
      console.warn('QR Code generation failed:', err);
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(voucherCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2500);
  };

  // Pre-formatted WhatsApp gift message
  const recipientWhatsAppMessage = `✨ Dear ${recipientName},
You have received a luxury Digital Jewellery Gift Voucher from ${senderName}!

🏆 Value: ${formatINR(amount)}
📜 Voucher Code: ${voucherCode}
🎉 Occasion: ${occasion}
💌 Message: "${message}"

Redeemable towards 18K/22K BIS Hallmarked Fine Jewellery at VJ Gold Luxury Flagship Boutique (Mumbai).
Scan the digital QR code upon arrival or present this voucher code. Valid for 1 Year.`;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="max-w-2xl w-full bg-[#101115] border border-[#D4AF37]/50 rounded-sm shadow-2xl p-5 sm:p-7 relative my-auto max-h-[94vh] flex flex-col space-y-5">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9CA3AF] hover:text-white p-1 z-30"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="space-y-1 pb-3 border-b border-[#212228]">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#E6C687]">
            <Gift className="w-4 h-4 text-[#D4AF37]" />
            <span>VJ Gold Digital Gifting Atelier</span>
          </div>
          <h2 className="font-serif text-2xl font-bold text-[#F3F4F6]">
            {voucherGenerated ? 'Your Digital Gift Voucher' : 'Create a Digital Gift Voucher'}
          </h2>
          <p className="text-xs text-[#9CA3AF]">
            Generate an official bullion & fine jewelry certificate with unique QR code for friends and family.
          </p>
        </div>

        {!voucherGenerated ? (
          /* Step 1: Voucher Creator Form */
          <form onSubmit={handleGenerateVoucher} className="space-y-4 text-xs">
            {/* Amount Selection */}
            <div>
              <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1.5">
                Select Voucher Value (₹ INR)
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                {presetAmounts.map((amt) => (
                  <button
                    type="button"
                    key={amt}
                    onClick={() => setAmount(amt)}
                    className={`py-2 px-1 text-center rounded-sm border font-mono tabular-nums transition-colors text-xs ${
                      amount === amt
                        ? 'bg-[#E6C687] text-[#0B0C0E] border-[#D4AF37] font-bold shadow-md'
                        : 'bg-[#15161D] text-[#D1D5DB] border-[#25262F] hover:bg-[#1E2029]'
                    }`}
                  >
                    {formatINR(amt)}
                  </button>
                ))}
              </div>

              {/* Custom Amount Field */}
              <div className="mt-2.5">
                <input
                  type="number"
                  min={1000}
                  max={5000000}
                  step={500}
                  value={amount}
                  onChange={(e) => setAmount(Math.max(1000, parseInt(e.target.value) || 1000))}
                  placeholder="Or enter custom denomination"
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] font-mono tabular-nums text-xs focus:border-[#D4AF37] focus:outline-none"
                />
              </div>
            </div>

            {/* Names & Occasion */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Recipient Name *
                </label>
                <input
                  type="text"
                  required
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  placeholder="e.g. Meera Singhania"
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Recipient WhatsApp / Phone
                </label>
                <input
                  type="tel"
                  value={recipientPhone}
                  onChange={(e) => setRecipientPhone(e.target.value)}
                  placeholder="+91 98200 00000"
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Sender (Your Name) *
                </label>
                <input
                  type="text"
                  required
                  value={senderName}
                  onChange={(e) => setSenderName(e.target.value)}
                  placeholder="e.g. Rajesh & Sunita"
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Celebration Occasion
                </label>
                <select
                  value={occasion}
                  onChange={(e) => setOccasion(e.target.value)}
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                >
                  <option value="Wedding & Bridal Trousseau">Wedding & Bridal Trousseau</option>
                  <option value="Anniversary Milestone">Anniversary Milestone</option>
                  <option value="Dhanteras & Diwali Auspicious Gifting">Dhanteras & Diwali Auspicious Gifting</option>
                  <option value="Birthday Blessing">Birthday Blessing</option>
                  <option value="Corporate / Festive Token">Corporate / Festive Token</option>
                </select>
              </div>
            </div>

            {/* Personal Message */}
            <div>
              <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                Personal Inscription Message
              </label>
              <textarea
                rows={2}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Write a heartfelt greeting to accompany the voucher..."
                className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm p-2.5 text-xs text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            {/* Submission CTA */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 text-xs font-bold uppercase tracking-widest text-[#0B0C0E] bg-gradient-to-r from-[#E6C687] to-[#D4AF37] hover:from-[#F0D8A8] hover:to-[#E5C158] rounded-sm transition-all shadow-md flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>Generate Official Digital Gift Voucher & QR</span>
              </button>
            </div>
          </form>
        ) : (
          /* Step 2: Generated Luxury Certificate Card */
          <div className="space-y-5">
            {/* Certificate Card Viewport */}
            <div
              ref={cardRef}
              className="bg-gradient-to-br from-[#121319] via-[#161722] to-[#121319] border-2 border-[#D4AF37] p-6 rounded-sm shadow-2xl relative overflow-hidden text-center space-y-4"
            >
              {/* Gold Filigree Corner Accents */}
              <div className="absolute top-2 left-2 text-[#D4AF37] text-xs opacity-60">❖</div>
              <div className="absolute top-2 right-2 text-[#D4AF37] text-xs opacity-60">❖</div>
              <div className="absolute bottom-2 left-2 text-[#D4AF37] text-xs opacity-60">❖</div>
              <div className="absolute bottom-2 right-2 text-[#D4AF37] text-xs opacity-60">❖</div>

              {/* Brand Lockup */}
              <div className="space-y-1">
                <span className="text-[10px] uppercase tracking-[0.3em] text-[#D4AF37] font-semibold block">
                  Official Atelier Certificate
                </span>
                <h3 className="font-serif text-2xl font-bold tracking-[0.2em] text-[#F3F4F6]">
                  VJ GOLD
                </h3>
                <span className="text-[10px] text-[#A1A1AA] uppercase tracking-widest block">
                  Fine Jewellery & Bullion
                </span>
              </div>

              {/* Denomination Banner */}
              <div className="py-2 border-y border-[#D4AF37]/40 max-w-sm mx-auto">
                <span className="text-[10px] text-[#A1A1AA] uppercase block">Gift Voucher Value</span>
                <div className="font-serif text-3xl sm:text-4xl font-bold text-[#E6C687] font-mono tabular-nums">
                  {formatINR(amount)}
                </div>
              </div>

              {/* Recipient Details & Message */}
              <div className="space-y-1 text-xs">
                <p className="text-[#D1D5DB]">
                  Presented with warm compliments to <strong className="text-[#FFF8E7] font-serif text-sm">{recipientName}</strong>
                </p>
                <p className="text-[#9CA3AF] text-[11px]">
                  From: <strong className="text-[#F3F4F6]">{senderName}</strong> · On the occasion of: <span className="text-[#E6C687]">{occasion}</span>
                </p>
                <p className="text-xs text-[#A1A1AA] italic max-w-md mx-auto pt-1">
                  "{message}"
                </p>
              </div>

              {/* QR Code and Voucher Code Box */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
                {qrDataUrl && (
                  <div className="p-2 bg-[#F5E6BE] rounded-sm shadow-md">
                    <img
                      src={qrDataUrl}
                      alt="Voucher QR Code"
                      className="w-24 h-24 sm:w-28 sm:h-28"
                    />
                  </div>
                )}

                <div className="text-left space-y-1 bg-[#101115] border border-[#2B2D38] p-3 rounded-sm">
                  <span className="text-[10px] uppercase text-[#71717A] tracking-wider block">
                    Voucher Unique ID:
                  </span>
                  <div className="font-mono text-sm font-bold text-[#E6C687] tracking-wider">
                    {voucherCode}
                  </div>
                  <button
                    onClick={handleCopyCode}
                    className="text-[11px] text-[#D1D5DB] hover:text-[#FFF8E7] flex items-center gap-1 transition-colors"
                  >
                    {copiedCode ? <Check className="w-3 h-3 text-[#10B981]" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedCode ? 'Copied to Clipboard' : 'Copy Voucher Code'}</span>
                  </button>
                  <span className="text-[9px] text-[#71717A] block pt-1">
                    Valid for 1 Year across all VJ Gold boutiques
                  </span>
                </div>
              </div>

              {/* Authentication Seal */}
              <div className="pt-2 flex items-center justify-center gap-2 text-[10px] text-[#A1A1AA] uppercase tracking-wider">
                <ShieldCheck className="w-3.5 h-3.5 text-[#D4AF37]" />
                <span>100% BIS Hallmarked 916 & 750 Gold Redeemable</span>
              </div>
            </div>

            {/* Sharing Actions */}
            <div className="space-y-2 pt-1 text-xs">
              <a
                href={buildWhatsAppLink(
                  recipientPhone || whatsappNumber,
                  recipientWhatsAppMessage
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 text-xs font-bold uppercase tracking-wider text-[#0B0C0E] bg-[#25D366] hover:bg-[#20bd5a] rounded-sm transition-all flex items-center justify-center gap-2 shadow-lg"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Send Voucher to {recipientName} via WhatsApp</span>
              </a>

              <div className="flex gap-2">
                <button
                  onClick={() => setVoucherGenerated(false)}
                  className="flex-1 py-2 text-xs text-[#D1D5DB] hover:text-white bg-[#15161D] border border-[#25262F] rounded-sm transition-colors text-center"
                >
                  Create Another Voucher
                </button>

                <button
                  onClick={onClose}
                  className="px-6 py-2 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
