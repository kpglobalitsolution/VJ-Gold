import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Product, GoldRates } from '../types';
import { CounterInspectionModal } from './CounterInspectionModal';
import { BudgetModal } from './BudgetModal';
import {
  Compass,
  Eye,
  Volume2,
  VolumeX,
  ChevronDown,
  ChevronUp,
  MessageCircle,
  Calendar,
  Sparkles,
  ArrowRight,
  RotateCcw,
  Footprints,
  LogOut,
  HelpCircle,
  MapPin,
  Heart,
  DollarSign,
} from 'lucide-react';
import { buildWhatsAppLink } from '../services/api';

interface Showroom3DProps {
  products: Product[];
  rates: GoldRates;
  onBrowseOnline: () => void;
  onOpenAppointment: () => void;
  onOpenEnquiryBasket: () => void;
  basketCount: number;
  onInspect3DOrbit: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  onOpenVirtualTryOn?: (product: Product) => void;
  wishlistIds: string[];
  whatsappNumber: string;
}

type Stage = 'exterior' | 'entering' | 'greeting' | 'exploring' | 'counter_inspect' | 'exiting';

interface CounterZone {
  id: string;
  name: string;
  position: [number, number, number];
  productId: string;
  category: string;
}

const COUNTERS: CounterZone[] = [
  {
    id: 'counter-necklaces-1',
    name: 'Imperial Emerald Choker Counter',
    position: [-3.8, 0, -2.0],
    productId: 'vjg-nc-001',
    category: 'Necklaces & Chokers',
  },
  {
    id: 'counter-necklaces-2',
    name: 'Amour Lattice Enamel Collar Counter',
    position: [-3.8, 0, 0.5],
    productId: 'vjg-nc-002',
    category: 'Necklaces & Chokers',
  },
  {
    id: 'counter-bangles',
    name: 'Mayura 22K Royal Kadas Counter',
    position: [3.8, 0, -2.0],
    productId: 'vjg-bg-003',
    category: 'Bangles & Bracelets',
  },
  {
    id: 'counter-rings',
    name: 'Solitaire Cocktail Rings Counter',
    position: [-3.5, 0, 3.2],
    productId: 'vjg-rg-004',
    category: 'Rings & Earrings',
  },
  {
    id: 'counter-chains',
    name: 'Solid 22K Rope Chains Counter',
    position: [3.5, 0, 3.2],
    productId: 'vjg-ch-005',
    category: 'Gold Chains',
  },
  {
    id: 'counter-reception',
    name: 'Senior Gemologist Reception Desk',
    position: [0, 0, 2.2],
    productId: 'vjg-nc-001',
    category: 'Reception & Consultation',
  },
];

export const Showroom3D: React.FC<Showroom3DProps> = ({
  products,
  rates,
  onBrowseOnline,
  onOpenAppointment,
  onOpenEnquiryBasket,
  basketCount,
  onInspect3DOrbit,
  onToggleWishlist,
  onOpenVirtualTryOn,
  wishlistIds,
  whatsappNumber,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [stage, setStage] = useState<Stage>('exterior');
  const [audioEnabled, setAudioEnabled] = useState(false);
  const [activeCounter, setActiveCounter] = useState<CounterZone | null>(null);
  const [inspectedProduct, setInspectedProduct] = useState<Product | null>(null);
  const [budgetModalOpen, setBudgetModalOpen] = useState(false);
  const [salespersonDialogueOpen, setSalespersonDialogueOpen] = useState(false);
  const [dialogueText, setDialogueText] = useState('Welcome to VJ Gold! How may I assist your jewellery discovery today?');
  const [walkingHintVisible, setWalkingHintVisible] = useState(false);
  const [controlsCollapsed, setControlsCollapsed] = useState(false);

  // Customer Player coordinates in 3D scene
  const playerPosRef = useRef(new THREE.Vector3(0, 1.65, 14.5));
  const playerLookRef = useRef(new THREE.Vector3(0, 1.65, 0));
  const keysPressedRef = useRef<{ [key: string]: boolean }>({});
  const doorProgressRef = useRef(0); // 0 = closed, 1 = fully open

  // Procedural Web Audio Ambient Chime
  const audioCtxRef = useRef<AudioContext | null>(null);
  const chimeIntervalRef = useRef<any>(null);

  const toggleAudio = () => {
    if (!audioEnabled) {
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new AudioCtx();
        audioCtxRef.current = ctx;

        const playChime = () => {
          if (!audioCtxRef.current || audioCtxRef.current.state !== 'running') return;
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          const freqs = [528, 660, 792, 1056];
          const freq = freqs[Math.floor(Math.random() * freqs.length)];
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, ctx.currentTime);
          gain.gain.setValueAtTime(0.001, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.035, ctx.currentTime + 0.3);
          gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 4.5);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 4.5);
        };

        playChime();
        chimeIntervalRef.current = setInterval(playChime, 7000);
        setAudioEnabled(true);
      } catch (e) {
        console.warn('Audio blocked:', e);
      }
    } else {
      if (chimeIntervalRef.current) clearInterval(chimeIntervalRef.current);
      if (audioCtxRef.current) audioCtxRef.current.close();
      setAudioEnabled(false);
    }
  };

  useEffect(() => {
    return () => {
      if (chimeIntervalRef.current) clearInterval(chimeIntervalRef.current);
      if (audioCtxRef.current) audioCtxRef.current.close();
    };
  }, []);

  // Keyboard navigation listeners
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      keysPressedRef.current[e.key.toLowerCase()] = true;
    };
    const onKeyUp = (e: KeyboardEvent) => {
      keysPressedRef.current[e.key.toLowerCase()] = false;
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, []);

  // Three.js Core Engine
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const width = container.clientWidth;
    const height = container.clientHeight;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0b0e);
    scene.fog = new THREE.FogExp2(0x0a0b0e, 0.03);

    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 100);
    camera.position.set(0, 1.65, 14.5);
    camera.lookAt(0, 1.65, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    container.appendChild(renderer.domElement);

    // Procedural RoomEnvironment for realistic gold gleam
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xfff3e0, 0.45);
    scene.add(ambientLight);

    const centerChandelier = new THREE.SpotLight(0xffecd2, 6, 25, Math.PI / 4, 0.4, 1);
    centerChandelier.position.set(0, 6, 2);
    centerChandelier.castShadow = true;
    centerChandelier.shadow.bias = -0.0005;
    scene.add(centerChandelier);

    const receptionSpot = new THREE.SpotLight(0xffd59e, 4, 12, Math.PI / 5, 0.3);
    receptionSpot.position.set(0, 4.5, 2.5);
    scene.add(receptionSpot);

    // Showroom Architecture
    // Polished Travertine Floor
    const floorCanvas = document.createElement('canvas');
    floorCanvas.width = 512;
    floorCanvas.height = 512;
    const fctx = floorCanvas.getContext('2d')!;
    fctx.fillStyle = '#111215';
    fctx.fillRect(0, 0, 512, 512);
    fctx.strokeStyle = '#2d2719';
    fctx.lineWidth = 3;
    fctx.strokeRect(0, 0, 512, 512);
    fctx.strokeStyle = '#1d1912';
    fctx.lineWidth = 1;
    fctx.beginPath();
    fctx.moveTo(256, 0);
    fctx.lineTo(256, 512);
    fctx.moveTo(0, 256);
    fctx.lineTo(512, 256);
    fctx.stroke();

    const floorTexture = new THREE.CanvasTexture(floorCanvas);
    floorTexture.wrapS = THREE.RepeatWrapping;
    floorTexture.wrapT = THREE.RepeatWrapping;
    floorTexture.repeat.set(8, 8);
    floorTexture.colorSpace = THREE.SRGBColorSpace;

    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(30, 40),
      new THREE.MeshStandardMaterial({
        map: floorTexture,
        roughness: 0.16,
        metalness: 0.25,
      })
    );
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    scene.add(floor);

    // Ceiling
    const ceiling = new THREE.Mesh(
      new THREE.PlaneGeometry(30, 40),
      new THREE.MeshStandardMaterial({ color: 0x0e0f13, roughness: 0.8 })
    );
    ceiling.position.y = 5.2;
    ceiling.rotation.x = Math.PI / 2;
    scene.add(ceiling);

    // Front Glass Wall with Entrance Double Doors
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transmission: 0.94,
      transparent: true,
      roughness: 0.05,
      ior: 1.52,
      thickness: 0.1,
      depthWrite: false,
    });

    const brassFrameMat = new THREE.MeshPhysicalMaterial({
      color: 0xd4af37,
      roughness: 0.15,
      metalness: 0.95,
      clearcoat: 0.5,
    });

    // Front facade left & right fixed glass panels
    const leftGlass = new THREE.Mesh(new THREE.BoxGeometry(4.5, 4.8, 0.08), glassMat);
    leftGlass.position.set(-3.75, 2.4, 7.8);
    scene.add(leftGlass);

    const rightGlass = new THREE.Mesh(new THREE.BoxGeometry(4.5, 4.8, 0.08), glassMat);
    rightGlass.position.set(3.75, 2.4, 7.8);
    scene.add(rightGlass);

    // Sliding Double Doors
    const leftDoor = new THREE.Mesh(new THREE.BoxGeometry(1.4, 3.8, 0.06), glassMat);
    leftDoor.position.set(-0.75, 1.9, 7.8);
    scene.add(leftDoor);

    const rightDoor = new THREE.Mesh(new THREE.BoxGeometry(1.4, 3.8, 0.06), glassMat);
    rightDoor.position.set(0.75, 1.9, 7.8);
    scene.add(rightDoor);

    // Brass handles on doors
    const handleL = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.8, 16), brassFrameMat);
    handleL.position.set(0.55, 0, 0.05);
    leftDoor.add(handleL);

    const handleR = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.8, 16), brassFrameMat);
    handleR.position.set(-0.55, 0, 0.05);
    rightDoor.add(handleR);

    // VJ GOLD Grand Signage above entrance
    const signGroup = new THREE.Group();
    signGroup.position.set(0, 4.4, 7.85);

    const signBoard = new THREE.Mesh(
      new THREE.BoxGeometry(5.2, 0.9, 0.1),
      new THREE.MeshStandardMaterial({ color: 0x090a0d, roughness: 0.2, metalness: 0.8 })
    );
    signGroup.add(signBoard);

    const signTrim = new THREE.Mesh(new THREE.BoxGeometry(5.26, 0.96, 0.08), brassFrameMat);
    signGroup.add(signTrim);
    scene.add(signGroup);

    // Back & Side Walls
    const wallMat = new THREE.MeshStandardMaterial({ color: 0x141519, roughness: 0.65 });
    const backWall = new THREE.Mesh(new THREE.PlaneGeometry(30, 6), wallMat);
    backWall.position.set(0, 2.6, -14);
    scene.add(backWall);

    const leftWall = new THREE.Mesh(new THREE.PlaneGeometry(30, 6), wallMat);
    leftWall.position.set(-8, 2.6, -2);
    leftWall.rotation.y = Math.PI / 2;
    scene.add(leftWall);

    const rightWall = new THREE.Mesh(new THREE.PlaneGeometry(30, 6), wallMat);
    rightWall.position.set(8, 2.6, -2);
    rightWall.rotation.y = -Math.PI / 2;
    scene.add(rightWall);

    // Reception Counter Desk
    const counterDesk = new THREE.Mesh(
      new THREE.BoxGeometry(3.6, 1.05, 1.2),
      new THREE.MeshPhysicalMaterial({ color: 0x1b1c22, roughness: 0.2, metalness: 0.4, clearcoat: 0.3 })
    );
    counterDesk.position.set(0, 0.525, 2.2);
    counterDesk.castShadow = true;
    counterDesk.receiveShadow = true;
    scene.add(counterDesk);

    const counterTop = new THREE.Mesh(
      new THREE.BoxGeometry(3.8, 0.08, 1.3),
      new THREE.MeshPhysicalMaterial({ color: 0x22242a, roughness: 0.1, clearcoat: 0.8 })
    );
    counterTop.position.set(0, 1.08, 2.2);
    scene.add(counterTop);

    // Salesperson Human Character at Reception
    const salespersonGroup = new THREE.Group();
    salespersonGroup.position.set(0, 0, 1.5);

    const torso = new THREE.Mesh(
      new THREE.CylinderGeometry(0.24, 0.32, 0.78, 16),
      new THREE.MeshStandardMaterial({ color: 0x16171d, roughness: 0.75 })
    );
    torso.position.y = 1.35;
    salespersonGroup.add(torso);

    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.14, 16, 16),
      new THREE.MeshStandardMaterial({ color: 0xc49e7b, roughness: 0.45 })
    );
    head.position.y = 1.88;
    salespersonGroup.add(head);

    const badge = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.01, 12), brassFrameMat);
    badge.position.set(0.08, 1.55, 0.22);
    badge.rotation.x = Math.PI / 2;
    salespersonGroup.add(badge);

    // Right arm for gesturing
    const rightArm = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.05, 0.45, 12), new THREE.MeshStandardMaterial({ color: 0x16171d }));
    rightArm.position.set(0.28, 1.35, 0.05);
    salespersonGroup.add(rightArm);

    scene.add(salespersonGroup);

    // Display Vitrine Counters in the Showroom
    const interactiveCounterMeshes: { mesh: THREE.Object3D; zone: CounterZone }[] = [];

    COUNTERS.forEach((zone) => {
      if (zone.id === 'counter-reception') return;

      const group = new THREE.Group();
      group.position.set(zone.position[0], 0, zone.position[2]);

      // Marble Pedestal
      const pedestal = new THREE.Mesh(
        new THREE.CylinderGeometry(0.65, 0.7, 0.95, 24),
        new THREE.MeshStandardMaterial({ color: 0x1a1b20, roughness: 0.25, metalness: 0.3 })
      );
      pedestal.position.y = 0.475;
      pedestal.castShadow = true;
      pedestal.receiveShadow = true;
      group.add(pedestal);

      // Gold Pedestal Ring
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.66, 0.02, 16, 32), brassFrameMat);
      ring.position.y = 0.95;
      ring.rotation.x = Math.PI / 2;
      group.add(ring);

      // Velvet Cushion Display
      const cushion = new THREE.Mesh(
        new THREE.CylinderGeometry(0.55, 0.58, 0.12, 24),
        new THREE.MeshStandardMaterial({ color: 0x0c0d10, roughness: 0.95 })
      );
      cushion.position.y = 1.01;
      group.add(cushion);

      // Glass Bell Vitrine
      const glassBell = new THREE.Mesh(
        new THREE.CylinderGeometry(0.58, 0.58, 0.85, 24, 1, true),
        glassMat
      );
      glassBell.position.y = 1.48;
      group.add(glassBell);

      const glassDome = new THREE.Mesh(
        new THREE.SphereGeometry(0.58, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2),
        glassMat
      );
      glassDome.position.y = 1.9;
      group.add(glassDome);

      // Showcase Spotlight
      const spot = new THREE.PointLight(0xfff7ea, 1.4, 3);
      spot.position.set(0, 1.8, 0);
      group.add(spot);

      // Jewellery presentation stand & item
      const stand = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.02, 16, 32), brassFrameMat);
      stand.position.y = 1.25;
      stand.rotation.x = Math.PI / 2.5;
      group.add(stand);

      scene.add(group);

      interactiveCounterMeshes.push({ mesh: pedestal, zone });
      interactiveCounterMeshes.push({ mesh: cushion, zone });
      interactiveCounterMeshes.push({ mesh: glassBell, zone });
    });

    // Raycasting for clicking counters
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    const onPointerClick = (e: MouseEvent) => {
      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const objects = interactiveCounterMeshes.map((m) => m.mesh);
      const intersects = raycaster.intersectObjects(objects, true);

      if (intersects.length > 0) {
        const hit = intersects[0].object;
        const matched = interactiveCounterMeshes.find(
          (m) => m.mesh === hit || m.mesh.children.includes(hit)
        );
        if (matched) {
          const product = products.find((p) => p.id === matched.zone.productId) || products[0];
          setActiveCounter(matched.zone);
          setInspectedProduct(product);
          setStage('counter_inspect');
        }
      }
    };

    renderer.domElement.addEventListener('click', onPointerClick);

    // Animation & Render Loop
    let animId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animId = requestAnimationFrame(animate);
      const delta = clock.getDelta();
      const time = clock.getElapsedTime();

      // Salesperson idle breathing and subtle sway
      salespersonGroup.position.y = Math.sin(time * 2) * 0.015;
      rightArm.rotation.z = Math.sin(time * 1.5) * 0.1;

      // Animate sliding doors based on doorProgressRef (0 = closed, 1 = open)
      const targetDoorX = doorProgressRef.current * 1.4;
      leftDoor.position.x = THREE.MathUtils.damp(leftDoor.position.x, -0.75 - targetDoorX, 4, delta);
      rightDoor.position.x = THREE.MathUtils.damp(rightDoor.position.x, 0.75 + targetDoorX, 4, delta);

      // Keyboard Walking Logic when exploring
      const moveSpeed = 4.2 * delta;
      const keys = keysPressedRef.current;

      if (keys['w'] || keys['arrowup']) {
        playerPosRef.current.z -= moveSpeed;
      }
      if (keys['s'] || keys['arrowdown']) {
        playerPosRef.current.z += moveSpeed;
      }
      if (keys['a'] || keys['arrowleft']) {
        playerPosRef.current.x -= moveSpeed;
      }
      if (keys['d'] || keys['arrowright']) {
        playerPosRef.current.x += moveSpeed;
      }

      // Enforce Showroom Collision Boundaries
      playerPosRef.current.x = THREE.MathUtils.clamp(playerPosRef.current.x, -6.5, 6.5);
      // If doors are open, can walk between -12 and 15
      const minZ = -12.5;
      const maxZ = doorProgressRef.current > 0.5 ? 15.0 : 8.5;
      playerPosRef.current.z = THREE.MathUtils.clamp(playerPosRef.current.z, minZ, maxZ);

      // Camera Damping to Player Position
      camera.position.x = THREE.MathUtils.damp(camera.position.x, playerPosRef.current.x, 4.5, delta);
      camera.position.y = THREE.MathUtils.damp(camera.position.y, playerPosRef.current.y, 4.5, delta);
      camera.position.z = THREE.MathUtils.damp(camera.position.z, playerPosRef.current.z, 4.5, delta);

      // Look Target Damping
      camera.lookAt(playerLookRef.current);

      renderer.render(scene, camera);
    };

    animate();

    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', handleResize);
      renderer.domElement.removeEventListener('click', onPointerClick);
      renderer.dispose();
      if (container && renderer.domElement) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [products]);

  // Stage Transitions
  const handleEnterShowroom = () => {
    setStage('entering');
    doorProgressRef.current = 1.0; // Open sliding doors!

    // Animate camera forward through the entrance
    playerPosRef.current.set(0, 1.65, 4.8);
    playerLookRef.current.set(0, 1.55, 1.5);

    setTimeout(() => {
      setStage('greeting');
      setSalespersonDialogueOpen(true);
      setWalkingHintVisible(true);
    }, 2200);
  };

  const handleWalkToCounter = (zone: CounterZone) => {
    setActiveCounter(zone);
    setSalespersonDialogueOpen(false);

    // Walk camera over to counter
    playerPosRef.current.set(zone.position[0], 1.55, zone.position[2] + 1.8);
    playerLookRef.current.set(zone.position[0], 1.25, zone.position[2]);

    setTimeout(() => {
      const product = products.find((p) => p.id === zone.productId) || products[0];
      setInspectedProduct(product);
      setStage('counter_inspect');
    }, 1200);
  };

  const handleExitShowroom = () => {
    setStage('exiting');
    setSalespersonDialogueOpen(false);
    doorProgressRef.current = 1.0; // Keep doors open for exit

    // Glide back outside
    playerPosRef.current.set(0, 1.65, 14.5);
    playerLookRef.current.set(0, 1.65, 0);

    setTimeout(() => {
      doorProgressRef.current = 0; // Close doors
      setStage('exterior');
    }, 2000);
  };

  return (
    <div className="relative w-full h-[90vh] min-h-[640px] bg-[#0A0B0E] overflow-hidden select-none">
      {/* 3D WebGL Canvas */}
      <div ref={mountRef} className="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top Floating Brand & Mode Header */}
      <div className="absolute top-6 left-6 z-20 pointer-events-none flex flex-col gap-1">
        <div className="flex items-center gap-2 text-xs font-semibold tracking-wider text-[#E6C687] uppercase">
          <Sparkles className="w-4 h-4 text-[#D4AF37]" />
          <span>VJ Gold 3D Digital Boutique</span>
        </div>
        <div className="text-xl sm:text-2xl font-serif font-bold text-[#F3F4F6] drop-shadow-md">
          {stage === 'exterior'
            ? 'Grand Architectural Façade'
            : stage === 'greeting'
            ? 'Reception & Welcome Desk'
            : stage === 'counter_inspect' && activeCounter
            ? activeCounter.name
            : 'Flagship Showroom Floor'}
        </div>
        <div className="text-xs text-[#9CA3AF]">
          {stage === 'exterior'
            ? 'Step through the grand entrance to explore handcrafted jewellery.'
            : 'Walk using W, A, S, D or tap any display counter to inspect pieces.'}
        </div>
      </div>

      {/* Top Right Quick Controls */}
      <div className="absolute top-6 right-6 z-20 flex items-center gap-2">
        <button
          onClick={toggleAudio}
          className="p-2.5 bg-[#121316]/85 hover:bg-[#1E1F24] border border-[#2B2D34] rounded-sm text-[#E6C687] backdrop-blur-md transition-colors"
          title={audioEnabled ? 'Mute Showroom Chimes' : 'Enable Ambient Chimes'}
          aria-label="Toggle audio"
        >
          {audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>

        <button
          onClick={onOpenEnquiryBasket}
          className="flex items-center gap-2 px-3 py-2 bg-[#121316]/85 hover:bg-[#1E1F24] border border-[#2B2D34] rounded-sm text-[#D1D5DB] hover:text-[#FFF8E7] backdrop-blur-md transition-colors text-xs"
          title="Open Consultation Basket"
        >
          <Heart className="w-4 h-4 text-rose-400" />
          <span>Basket ({basketCount})</span>
        </button>

        <button
          onClick={onBrowseOnline}
          className="px-3.5 py-2 bg-[#121316]/85 hover:bg-[#1E1F24] border border-[#2B2D34] rounded-sm text-[#E6C687] hover:text-white backdrop-blur-md transition-colors text-xs font-medium"
        >
          Browse Catalogue View
        </button>
      </div>

      {/* SCENE 1: CINEMATIC EXTERIOR OVERLAY */}
      {stage === 'exterior' && (
        <div className="absolute inset-0 z-30 flex items-center justify-center p-4 bg-gradient-to-t from-[#0B0C0E]/90 via-[#0B0C0E]/30 to-transparent pointer-events-none">
          <div className="max-w-xl text-center space-y-6 pointer-events-auto bg-[#0E0F13]/95 border border-[#D4AF37]/40 p-8 sm:p-10 rounded-sm shadow-2xl backdrop-blur-md animate-fadeIn">
            <div className="w-14 h-14 mx-auto rounded-sm bg-gradient-to-br from-[#E6C687] via-[#D4AF37] to-[#996515] p-0.5 shadow-md flex items-center justify-center">
              <div className="w-full h-full bg-[#0E0F13] flex items-center justify-center font-serif text-[#E6C687] font-bold text-2xl">
                VJ
              </div>
            </div>

            <div className="space-y-2">
              <h1 className="font-serif text-3xl sm:text-4xl font-bold tracking-wider text-[#F3F4F6]">
                VJ GOLD
              </h1>
              <p className="font-serif italic text-base sm:text-lg text-[#E6C687]">
                Discover the beauty of gold.
              </p>
              <p className="text-xs sm:text-sm text-[#9CA3AF] max-w-md mx-auto leading-relaxed pt-1">
                Step inside our 3D digital flagship. Walk through the showroom, inspect our handcrafted bridal chokers, Colombian emeralds, and discuss prices directly with our sales consultant.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-3">
              <button
                onClick={handleEnterShowroom}
                className="w-full sm:w-auto px-8 py-3.5 text-xs font-bold uppercase tracking-widest text-[#0B0C0E] bg-gradient-to-r from-[#E6C687] via-[#D4AF37] to-[#E6C687] hover:brightness-110 rounded-sm transition-all shadow-xl flex items-center justify-center gap-2"
              >
                <span>Enter Showroom</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onBrowseOnline}
                className="w-full sm:w-auto px-6 py-3.5 text-xs font-semibold text-[#D1D5DB] hover:text-[#FFF8E7] bg-[#14151B] border border-[#2B2D38] hover:border-[#D4AF37] rounded-sm transition-colors"
              >
                Browse Jewellery Online
              </button>
            </div>

            <div className="text-[11px] text-[#71717A] tracking-wider uppercase pt-2">
              100% BIS Hallmarked 916 & 750 Gold · Mumbai Flagship Boutique
            </div>
          </div>
        </div>
      )}

      {/* SCENE 2 & 3: SALESPERSON GREETING DIALOGUE */}
      {salespersonDialogueOpen && (
        <div className="absolute bottom-28 left-1/2 -translate-x-1/2 z-30 max-w-xl w-[94vw] bg-[#0E0F14]/95 border border-[#D4AF37]/70 p-5 rounded-sm shadow-2xl backdrop-blur-md space-y-3.5 animate-fadeIn">
          <div className="flex items-center justify-between pb-2 border-b border-[#212228]">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-[#10B981]" />
              <span className="text-xs font-bold uppercase tracking-wider text-[#E6C687]">
                Senior Jewellery Consultant
              </span>
            </div>
            <button
              onClick={() => setSalespersonDialogueOpen(false)}
              className="text-[#9CA3AF] hover:text-white text-xs"
            >
              Close
            </button>
          </div>

          <p className="text-xs sm:text-sm text-[#F3F4F6] italic leading-relaxed">
            "{dialogueText}"
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs pt-1">
            <button
              onClick={() => {
                setDialogueText("Certainly! Please follow me to our Imperial Choker & Necklace showcase.");
                handleWalkToCounter(COUNTERS[0]);
              }}
              className="p-2.5 text-left bg-[#16171E] hover:bg-[#20222A] text-[#D1D5DB] border border-[#2B2D38] rounded-sm transition-colors"
            >
              ✦ I am looking for a statement necklace
            </button>

            <button
              onClick={() => {
                setDialogueText("Right this way. Let me show you our 22K Royal Gold Bangles.");
                handleWalkToCounter(COUNTERS[2]);
              }}
              className="p-2.5 text-left bg-[#16171E] hover:bg-[#20222A] text-[#D1D5DB] border border-[#2B2D38] rounded-sm transition-colors"
            >
              ✦ Show me royal gold bangles
            </button>

            <button
              onClick={() => {
                setDialogueText("Here are our certified diamond solitaire & cocktail rings.");
                handleWalkToCounter(COUNTERS[3]);
              }}
              className="p-2.5 text-left bg-[#16171E] hover:bg-[#20222A] text-[#D1D5DB] border border-[#2B2D38] rounded-sm transition-colors"
            >
              ✦ I want to see rings or earrings
            </button>

            <button
              onClick={() => {
                setDialogueText("Let's view our solid Rajputana gold chains collection.");
                handleWalkToCounter(COUNTERS[4]);
              }}
              className="p-2.5 text-left bg-[#16171E] hover:bg-[#20222A] text-[#D1D5DB] border border-[#2B2D38] rounded-sm transition-colors"
            >
              ✦ Show me solid gold chains
            </button>

            <button
              onClick={() => {
                setSalespersonDialogueOpen(false);
                setBudgetModalOpen(true);
              }}
              className="p-2.5 text-left bg-[#16171E] hover:bg-[#20222A] text-[#E6C687] border border-[#D4AF37]/40 rounded-sm transition-colors"
            >
              ✦ I have a specific budget in mind
            </button>

            <a
              href={buildWhatsAppLink(
                whatsappNumber,
                'Hello VJ Gold, I am currently inside your 3D digital showroom and would like to speak directly with the shop owner.'
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 text-left bg-[#14231B] hover:bg-[#1A3325] text-[#25D366] border border-[#25D366]/40 rounded-sm transition-colors flex items-center justify-between"
            >
              <span>✦ Speak to Shop Owner on WhatsApp</span>
              <MessageCircle className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      )}

      {/* WALKING KEYBOARD & TOUCH HINT */}
      {walkingHintVisible && stage !== 'exterior' && (
        <div className="absolute top-24 left-6 z-20 bg-[#101115]/85 border border-[#262731] px-3.5 py-2 rounded-sm text-[11px] text-[#A1A1AA] backdrop-blur-md flex items-center gap-3">
          <Footprints className="w-4 h-4 text-[#E6C687]" />
          <span>Use <strong>W, A, S, D</strong> or Arrow keys to walk freely · Click counters to inspect</span>
          <button
            onClick={() => setWalkingHintVisible(false)}
            className="text-[#71717A] hover:text-white ml-2 text-xs"
          >
            ✕
          </button>
        </div>
      )}

      {/* COUNTER INSPECTION MODAL */}
      {inspectedProduct && activeCounter && (
        <CounterInspectionModal
          product={inspectedProduct}
          allProducts={products}
          rates={rates}
          onClose={() => {
            setInspectedProduct(null);
            setStage('exploring');
          }}
          onSelectAlternative={(alt) => setInspectedProduct(alt)}
          onInspect3DOrbit={onInspect3DOrbit}
          onToggleWishlist={onToggleWishlist}
          isInWishlist={wishlistIds.includes(inspectedProduct.id)}
          onOpenAppointment={onOpenAppointment}
          onOpenVirtualTryOn={onOpenVirtualTryOn}
          whatsappNumber={whatsappNumber}
        />
      )}

      {/* BUDGET MODAL */}
      <BudgetModal
        isOpen={budgetModalOpen}
        onClose={() => setBudgetModalOpen(false)}
        products={products}
        onSelectProduct={(p) => {
          setInspectedProduct(p);
          setStage('counter_inspect');
        }}
        whatsappNumber={whatsappNumber}
      />

      {/* UNIFIED ERGONOMIC BOTTOM DOCK (Directive #5: Zero Viewport Occlusion) */}
      {stage !== 'exterior' && (
        <div
          className={`absolute left-1/2 -translate-x-1/2 z-20 transition-all duration-300 w-[94vw] max-w-[940px] flex flex-col items-center ${
            controlsCollapsed ? 'bottom-[-92px]' : 'bottom-4'
          }`}
        >
          {/* Toggle Button */}
          <button
            onClick={() => setControlsCollapsed(!controlsCollapsed)}
            className="flex items-center gap-1.5 px-3 py-1 bg-[#101115]/90 border-t border-x border-[#2B2D34] rounded-t-sm text-[11px] font-medium text-[#E6C687] hover:text-white backdrop-blur-md shadow-md"
          >
            {controlsCollapsed ? (
              <>
                <ChevronUp className="w-3.5 h-3.5" />
                <span>Show Showroom Navigator</span>
              </>
            ) : (
              <>
                <ChevronDown className="w-3.5 h-3.5" />
                <span>Cinema View</span>
              </>
            )}
          </button>

          {/* Consolidated Controls */}
          <div className="w-full bg-[#101115]/95 border border-[#2B2D34] rounded-sm p-2 sm:p-3 shadow-2xl backdrop-blur-md flex flex-col sm:flex-row items-center justify-between gap-3">
            {/* Quick Counter Waypoints */}
            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 scrollbar-none">
              <button
                onClick={() => {
                  playerPosRef.current.set(0, 1.65, 4.5);
                  playerLookRef.current.set(0, 1.55, 1.5);
                  setSalespersonDialogueOpen(true);
                }}
                className="px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap shrink-0 bg-[#E6C687] text-[#0B0C0E] font-semibold"
              >
                Reception Desk
              </button>

              {COUNTERS.filter((c) => c.id !== 'counter-reception').map((counter) => (
                <button
                  key={counter.id}
                  onClick={() => handleWalkToCounter(counter)}
                  className="px-3 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap shrink-0 text-[#D1D5DB] hover:text-white bg-[#16171E] hover:bg-[#20222A] border border-[#282930]"
                >
                  {counter.name.replace(' Counter', '')}
                </button>
              ))}
            </div>

            {/* Right Quick Actions */}
            <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end border-t sm:border-t-0 pt-2 sm:pt-0 border-[#23242A]">
              <button
                onClick={() => setBudgetModalOpen(true)}
                className="px-3 py-1.5 text-xs text-[#E6C687] bg-[#1A1812] border border-[#D4AF37]/40 hover:border-[#D4AF37] rounded-sm transition-colors whitespace-nowrap shrink-0 flex items-center gap-1"
              >
                <DollarSign className="w-3 h-3" />
                <span>Budget Guidance</span>
              </button>

              <button
                onClick={handleExitShowroom}
                className="px-3 py-1.5 text-xs text-[#9CA3AF] hover:text-red-300 bg-[#181920] border border-[#2B2D38] rounded-sm transition-colors whitespace-nowrap shrink-0 flex items-center gap-1"
                title="Exit to Grand Façade"
              >
                <LogOut className="w-3 h-3" />
                <span>Exit Showroom</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
