import React, { useState } from 'react';
import { Product, GoldRates } from '../types';
import { api, buildWhatsAppLink, formatINR } from '../services/api';
import {
  X,
  Sparkles,
  MessageCircle,
  Calendar,
  ShieldCheck,
  Send,
  Scale,
  Award,
  Heart,
  ChevronRight,
  ArrowRight,
  RotateCw,
  Eye,
  Camera,
} from 'lucide-react';

interface CounterInspectionModalProps {
  product: Product;
  allProducts: Product[];
  rates: GoldRates;
  onClose: () => void;
  onSelectAlternative: (product: Product) => void;
  onInspect3DOrbit: (product: Product) => void;
  onToggleWishlist: (product: Product) => void;
  isInWishlist: boolean;
  onOpenAppointment: () => void;
  onOpenVirtualTryOn?: (product: Product) => void;
  whatsappNumber: string;
}

interface DialogueTurn {
  sender: 'salesperson' | 'customer';
  text: string;
}

export const CounterInspectionModal: React.FC<CounterInspectionModalProps> = ({
  product,
  allProducts,
  rates,
  onClose,
  onSelectAlternative,
  onInspect3DOrbit,
  onToggleWishlist,
  isInWishlist,
  onOpenAppointment,
  onOpenVirtualTryOn,
  whatsappNumber,
}) => {
  const [activeImgIdx, setActiveImgIdx] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [zoomCoords, setZoomCoords] = useState({ x: 50, y: 50 });
  const [customQuestion, setCustomQuestion] = useState('');
  const [loadingAnswer, setLoadingAnswer] = useState(false);

  // Salesperson conversation log for this product
  const [conversation, setConversation] = useState<DialogueTurn[]>([
    {
      sender: 'salesperson',
      text: `Here is our ${product.name} (SKU: ${product.sku}). It is handcrafted in ${product.goldPurity} and weighs ${product.grossWeight} grams. What would you like to know about this piece?`,
    },
  ]);

  const images = [product.primaryImage, ...(product.additionalImages || [])];

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;
    setZoomCoords({ x, y });
  };

  const handleAskQuestion = async (question: string) => {
    if (!question.trim() || loadingAnswer) return;

    const userTurn: DialogueTurn = { sender: 'customer', text: question };
    setConversation((prev) => [...prev, userTurn]);
    setCustomQuestion('');
    setLoadingAnswer(true);

    try {
      const answer = await api.askConsultant(question, product.id);
      setConversation((prev) => [...prev, { sender: 'salesperson', text: answer }]);
    } catch {
      setConversation((prev) => [
        ...prev,
        {
          sender: 'salesperson',
          text: `For exact current day pricing and hallmark confirmation, please connect directly with our boutique manager on WhatsApp.`,
        },
      ]);
    } finally {
      setLoadingAnswer(false);
    }
  };

  // Find alternative pieces in the catalogue
  const alternatives = allProducts.filter(
    (p) => p.category === product.category && p.id !== product.id
  ).slice(0, 3);

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="max-w-4xl w-full bg-[#0F1014] border border-[#D4AF37]/50 rounded-sm shadow-2xl overflow-hidden flex flex-col my-auto max-h-[92vh]">
        {/* Header Bar */}
        <div className="bg-[#14151B] border-b border-[#24252D] p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-sm bg-gradient-to-br from-[#E6C687] to-[#D4AF37] p-0.5 flex items-center justify-center">
              <div className="w-full h-full bg-[#0F1014] flex items-center justify-center font-serif text-[#E6C687] font-bold text-xs">
                VJ
              </div>
            </div>
            <div>
              <div className="text-[10px] text-[#E6C687] font-semibold uppercase tracking-wider">
                Showroom Display Counter · {product.category}
              </div>
              <h3 className="font-serif text-lg font-bold text-[#F3F4F6] line-clamp-1">
                {product.name}
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onToggleWishlist(product)}
              className={`p-2 rounded-sm border transition-colors ${
                isInWishlist
                  ? 'bg-rose-950/40 border-rose-800 text-rose-400'
                  : 'bg-[#181920] border-[#2A2B34] text-[#9CA3AF] hover:text-white'
              }`}
              title={isInWishlist ? 'Remove from Enquiry Basket' : 'Save to Enquiry Basket'}
            >
              <Heart className={`w-4 h-4 ${isInWishlist ? 'fill-rose-400' : ''}`} />
            </button>

            <button
              onClick={onClose}
              className="p-2 text-[#9CA3AF] hover:text-white border border-[#2A2B34] rounded-sm hover:bg-[#1E1F26]"
              aria-label="Return to Showroom"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body: Two Columns */}
        <div className="grid grid-cols-1 lg:grid-cols-12 flex-1 overflow-y-auto divide-y lg:divide-y-0 lg:divide-x divide-[#24252D]">
          {/* Left Column: Product Photo Stage & Specifications (6 cols) */}
          <div className="lg:col-span-6 p-5 sm:p-6 space-y-4 flex flex-col justify-between">
            <div className="space-y-4">
              {/* Zoomable Image Stage */}
              <div
                onMouseEnter={() => setIsZoomed(true)}
                onMouseLeave={() => setIsZoomed(false)}
                onMouseMove={handleMouseMove}
                className="relative aspect-square w-full bg-[#08090C] border border-[#262731] rounded-sm overflow-hidden cursor-crosshair group shadow-inner"
              >
                <img
                  src={images[activeImgIdx] || product.primaryImage}
                  alt={product.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                  style={{
                    transformOrigin: `${zoomCoords.x}% ${zoomCoords.y}%`,
                    transform: isZoomed ? 'scale(1.9)' : 'scale(1)',
                    transition: isZoomed ? 'transform 0.1s ease-out' : 'transform 0.3s ease',
                  }}
                />

                <div className="absolute top-2.5 left-2.5 z-10 text-[10px] text-[#A1A1AA] uppercase tracking-wider bg-black/60 px-2 py-0.5 backdrop-blur-md">
                  {isZoomed ? 'Magnified' : 'Hover to Zoom'}
                </div>

                {/* 3D Inspect & Virtual Try-On Buttons */}
                <div className="absolute bottom-2.5 right-2.5 z-10 flex items-center gap-1.5">
                  {onOpenVirtualTryOn && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenVirtualTryOn(product);
                      }}
                      className="flex items-center gap-1 px-2.5 py-1.5 bg-[#D4AF37] text-[#0B0C0E] text-[11px] font-bold rounded-sm backdrop-blur-md hover:bg-[#E5C158] transition-colors"
                      title="Virtual Try-On"
                    >
                      <Camera className="w-3 h-3" />
                      <span>Virtual Try-On</span>
                    </button>
                  )}

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onInspect3DOrbit(product);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-[#0B0C0E]/90 text-[#E6C687] text-[11px] font-semibold border border-[#D4AF37]/50 rounded-sm backdrop-blur-md hover:bg-[#D4AF37] hover:text-[#0B0C0E]"
                  >
                    <RotateCw className="w-3 h-3" />
                    <span>3D Orbit</span>
                  </button>
                </div>
              </div>

              {/* Thumbnail Bar */}
              {images.length > 1 && (
                <div className="flex gap-2">
                  {images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setActiveImgIdx(idx)}
                      className={`w-14 h-14 rounded-sm overflow-hidden border-2 transition-all ${
                        activeImgIdx === idx ? 'border-[#D4AF37]' : 'border-[#262731] opacity-70'
                      }`}
                    >
                      <img src={img} alt="Angle thumbnail" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              {/* Verified Atelier Specifications */}
              <div className="bg-[#14151B] border border-[#24252D] p-3.5 rounded-sm space-y-2 text-xs">
                <div className="flex items-center justify-between text-[#E6C687] font-semibold text-[11px] uppercase tracking-wider pb-1 border-b border-[#202128]">
                  <span className="flex items-center gap-1.5">
                    <Scale className="w-3.5 h-3.5" />
                    <span>Verified Craftsmanship Specs</span>
                  </span>
                  <span className="font-mono text-[#A1A1AA]">SKU: {product.sku}</span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-[#71717A] block">Gold Purity:</span>
                    <span className="font-medium text-[#F3F4F6]">{product.goldPurity}</span>
                  </div>
                  <div>
                    <span className="text-[#71717A] block">Gross Weight:</span>
                    <span className="font-mono tabular-nums font-medium text-[#F3F4F6]">{product.grossWeight}g</span>
                  </div>
                  <div>
                    <span className="text-[#71717A] block">Net Gold Weight:</span>
                    <span className="font-mono tabular-nums font-semibold text-[#E6C687]">{product.netGoldWeight}g</span>
                  </div>
                  <div>
                    <span className="text-[#71717A] block">Making Charges:</span>
                    <span className="font-mono tabular-nums text-[#D1D5DB]">₹{product.makingChargesPerGram}/g</span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-[#71717A] block">Gemstones & Diamonds:</span>
                    <span className="text-[#D1D5DB] font-medium">{product.stoneDetails}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-[#202128] flex items-center justify-between">
                  <span className="text-[10px] text-[#A1A1AA] uppercase">Showroom Price:</span>
                  <span className="font-mono tabular-nums font-bold text-[#E6C687] text-base">
                    {formatINR(product.price)}
                  </span>
                </div>
              </div>
            </div>

            {/* Direct Shop Owner WhatsApp CTA */}
            <div className="space-y-2 pt-2">
              <a
                href={buildWhatsAppLink(
                  whatsappNumber,
                  `Hello VJ Gold, I am inspecting ${product.name} (SKU: ${product.sku}) in your 3D Showroom. Please share the confirmed quotation, today's gold rate, and availability for boutique trial.`
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 text-xs font-bold uppercase tracking-wider text-[#0B0C0E] bg-[#25D366] hover:bg-[#20bd5a] rounded-sm transition-all flex items-center justify-center gap-2 shadow-lg"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Enquire Directly on WhatsApp (SKU: {product.sku})</span>
              </a>

              <button
                onClick={onOpenAppointment}
                className="w-full py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors flex items-center justify-center gap-1.5"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Book Flagship Showroom Trial</span>
              </button>
            </div>
          </div>

          {/* Right Column: Live Conversation with Salesperson & Alternatives (6 cols) */}
          <div className="lg:col-span-6 p-5 sm:p-6 flex flex-col justify-between space-y-4 bg-[#111216]">
            {/* Salesperson Identity Strip */}
            <div className="flex items-center justify-between pb-3 border-b border-[#24252D]">
              <div className="flex items-center gap-2.5">
                <div className="w-3 h-3 rounded-full bg-[#10B981]" />
                <span className="font-serif font-bold text-sm text-[#F3F4F6]">
                  Senior Jewellery Consultant
                </span>
              </div>
              <div className="text-[10px] text-[#E6C687] flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" />
                <span>Verified Atelier Information</span>
              </div>
            </div>

            {/* Conversation Log */}
            <div className="flex-1 overflow-y-auto space-y-3 pr-1 max-h-[280px] scrollbar-thin">
              {conversation.map((turn, i) => (
                <div
                  key={i}
                  className={`flex flex-col ${
                    turn.sender === 'customer' ? 'items-end' : 'items-start'
                  }`}
                >
                  <div
                    className={`max-w-[88%] p-3 rounded-sm text-xs leading-relaxed ${
                      turn.sender === 'customer'
                        ? 'bg-[#E6C687] text-[#0B0C0E] font-medium'
                        : 'bg-[#181920] border border-[#282932] text-[#E5E7EB]'
                    }`}
                  >
                    {turn.text}
                  </div>
                  <span className="text-[9px] text-[#6B7280] mt-0.5 px-1 capitalize">
                    {turn.sender === 'customer' ? 'You' : 'Consultant'}
                  </span>
                </div>
              ))}

              {loadingAnswer && (
                <div className="flex items-center gap-2 text-xs text-[#E6C687] italic p-2">
                  <Sparkles className="w-3.5 h-3.5 animate-spin" />
                  <span>Consulting workshop ledger...</span>
                </div>
              )}
            </div>

            {/* Quick Question Buttons */}
            <div className="space-y-1.5 pt-2">
              <span className="text-[10px] uppercase text-[#71717A] tracking-wider block">
                Suggested Questions for Consultant:
              </span>
              <div className="grid grid-cols-2 gap-1.5 text-[11px]">
                <button
                  onClick={() => handleAskQuestion(`What is the price of this product?`)}
                  className="p-2 text-left bg-[#181920] hover:bg-[#22242D] text-[#D1D5DB] border border-[#282932] rounded-sm transition-colors truncate"
                >
                  ✦ Confirm listed price
                </button>
                <button
                  onClick={() => handleAskQuestion(`What is the exact net gold weight and purity?`)}
                  className="p-2 text-left bg-[#181920] hover:bg-[#22242D] text-[#D1D5DB] border border-[#282932] rounded-sm transition-colors truncate"
                >
                  ✦ Net gold weight & purity
                </button>
                <button
                  onClick={() => handleAskQuestion(`What are the making charges on this design?`)}
                  className="p-2 text-left bg-[#181920] hover:bg-[#22242D] text-[#D1D5DB] border border-[#282932] rounded-sm transition-colors truncate"
                >
                  ✦ Making charges policy
                </button>
                <button
                  onClick={() => handleAskQuestion(`Is this piece currently in the showroom for trial?`)}
                  className="p-2 text-left bg-[#181920] hover:bg-[#22242D] text-[#D1D5DB] border border-[#282932] rounded-sm transition-colors truncate"
                >
                  ✦ In-store availability
                </button>
              </div>
            </div>

            {/* Custom Input */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleAskQuestion(customQuestion);
              }}
              className="flex gap-2"
            >
              <input
                type="text"
                value={customQuestion}
                onChange={(e) => setCustomQuestion(e.target.value)}
                placeholder="Ask about gemstones, customization, trial..."
                className="flex-1 bg-[#181920] border border-[#282932] rounded-sm px-3 py-2 text-xs text-[#F3F4F6] placeholder-[#6B7280] focus:border-[#D4AF37] focus:outline-none"
              />
              <button
                type="submit"
                disabled={loadingAnswer || !customQuestion.trim()}
                className="px-4 py-2 bg-[#D4AF37] hover:bg-[#E5C158] disabled:opacity-50 text-[#0B0C0E] text-xs font-semibold rounded-sm transition-colors flex items-center justify-center gap-1"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Ask</span>
              </button>
            </form>

            {/* Alternative Pieces on Display */}
            {alternatives.length > 0 && (
              <div className="pt-3 border-t border-[#24252D] space-y-2">
                <span className="text-[10px] uppercase text-[#E6C687] font-semibold tracking-wider block">
                  Other Designs at this Counter:
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {alternatives.map((alt) => (
                    <div
                      key={alt.id}
                      onClick={() => onSelectAlternative(alt)}
                      className="bg-[#16171E] border border-[#282932] hover:border-[#D4AF37] p-1.5 rounded-sm cursor-pointer transition-all space-y-1 group"
                    >
                      <div className="aspect-square w-full rounded-sm overflow-hidden bg-[#0A0B0E]">
                        <img src={alt.primaryImage} alt={alt.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                      </div>
                      <div className="text-[10px] text-[#F3F4F6] font-medium line-clamp-1">{alt.name}</div>
                      <div className="text-[9px] text-[#E6C687] font-mono tabular-nums">{formatINR(alt.price)}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
