import React from 'react';
import { Product } from '../types';
import { Eye, MessageCircle, Sparkles, Scale, Check } from 'lucide-react';
import { buildWhatsAppLink, formatINR } from '../services/api';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  onInspect3D: (product: Product) => void;
  whatsappNumber: string;
  isComparing?: boolean;
  onToggleCompare?: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onSelect,
  onInspect3D,
  whatsappNumber,
  isComparing = false,
  onToggleCompare,
}) => {
  return (
    <div className="group bg-[#101114] border border-[#212227] hover:border-[#D4AF37]/60 rounded-sm overflow-hidden flex flex-col justify-between transition-all duration-300 hover:-translate-y-0.5 hover:shadow-xl">
      {/* Lead with imagery (65-75% height) */}
      <div
        onClick={() => onSelect(product)}
        className="relative aspect-square w-full bg-[#08090C] overflow-hidden cursor-pointer"
      >
        <img
          src={product.primaryImage}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />

        {/* Subtle unboxed top kicker */}
        <div className="absolute top-3 left-3 z-10 flex items-center gap-1.5 text-[10px] font-medium tracking-widest uppercase text-[#F3F4F6] bg-black/60 px-2 py-1 backdrop-blur-md">
          <span>{product.goldPurity.split(' ')[0]}</span>
          <span>·</span>
          <span>{product.grossWeight}g</span>
        </div>

        {/* Compare Toggle Button */}
        {onToggleCompare && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onToggleCompare(product);
            }}
            className={`absolute top-3 right-3 z-20 flex items-center gap-1 px-2.5 py-1 text-[10px] font-semibold tracking-wider uppercase rounded-sm backdrop-blur-md transition-all ${
              isComparing
                ? 'bg-[#E6C687] text-[#0B0C0E] shadow-md border border-[#FFF8E7]'
                : 'bg-black/60 text-[#D1D5DB] hover:text-white border border-[#3F3F46] hover:border-[#D4AF37]'
            }`}
            title={isComparing ? 'Remove from comparison' : 'Add to side-by-side comparison (up to 3)'}
          >
            {isComparing ? (
              <>
                <Check className="w-3 h-3 text-[#0B0C0E]" />
                <span>Compared</span>
              </>
            ) : (
              <>
                <Scale className="w-3 h-3 text-[#E6C687]" />
                <span>Compare</span>
              </>
            )}
          </button>
        )}

        {/* 3D Inspect Quick Pill Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onInspect3D(product);
          }}
          className="absolute bottom-3 right-3 z-10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1.5 px-2.5 py-1.5 bg-[#0B0C0E]/90 text-[#E6C687] text-[11px] font-medium border border-[#D4AF37]/50 rounded-sm backdrop-blur-md hover:bg-[#D4AF37] hover:text-[#0B0C0E]"
          title="Inspect in 3D Studio"
        >
          <Sparkles className="w-3 h-3" />
          <span>3D Inspect</span>
        </button>
      </div>

      {/* Card Content & Metadata */}
      <div className="p-5 flex flex-col justify-between flex-grow space-y-4">
        <div className="space-y-1.5">
          <div className="text-[11px] font-medium uppercase tracking-wider text-[#A1A1AA]">
            {product.category}
          </div>

          <h3
            onClick={() => onSelect(product)}
            className="font-serif text-lg font-bold text-[#F3F4F6] hover:text-[#E6C687] cursor-pointer transition-colors line-clamp-1"
            title={product.name}
          >
            {product.name}
          </h3>

          <p className="text-xs text-[#9CA3AF] line-clamp-2 leading-relaxed">
            {product.description}
          </p>
        </div>

        {/* Price & Weight Row */}
        <div className="pt-3 border-t border-[#1C1D22] flex items-baseline justify-between">
          <div>
            <span className="text-[10px] uppercase text-[#71717A] tracking-wider block">
              Indicative Price
            </span>
            <div className="font-mono tabular-nums font-semibold text-[#E6C687] text-base">
              {formatINR(product.price)}
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] uppercase text-[#71717A] tracking-wider block">
              Availability
            </span>
            <span className="text-[11px] text-[#D1D5DB] font-medium">
              {product.availability.includes('Available') ? 'In Boutique' : 'Made to Order'}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={() => onSelect(product)}
            className="w-full py-2 text-xs font-semibold text-[#D1D5DB] hover:text-[#FFF8E7] bg-[#16171C] hover:bg-[#202127] border border-[#2B2D34] rounded-sm transition-colors flex items-center justify-center gap-1"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Specifications</span>
          </button>

          <a
            href={buildWhatsAppLink(
              whatsappNumber,
              `Hello VJ Gold, I am interested in ${product.name} (SKU: ${product.sku}). Please share the latest verified quotation, gold rate, and availability.`
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-2 text-xs font-medium text-[#25D366] bg-[#25D366]/10 hover:bg-[#25D366]/20 border border-[#25D366]/30 rounded-sm transition-colors flex items-center justify-center gap-1.5"
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>WhatsApp</span>
          </a>
        </div>
      </div>
    </div>
  );
};
