import React, { useState } from 'react';
import { api } from '../services/api';
import { Calendar, Clock, User, Phone, Mail, CheckCircle2, X } from 'lucide-react';

interface AppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: string[];
}

export const AppointmentModal: React.FC<AppointmentModalProps> = ({
  isOpen,
  onClose,
  categories,
}) => {
  if (!isOpen) return null;

  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [preferredDate, setPreferredDate] = useState('');
  const [preferredTimeSlot, setPreferredTimeSlot] = useState('3:00 PM - 4:30 PM');
  const [categoryOfInterest, setCategoryOfInterest] = useState(categories[0] || 'Necklaces & Chokers');
  const [guestCount, setGuestCount] = useState(2);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [error, setError] = useState('');

  const timeSlots = [
    '11:00 AM - 12:30 PM',
    '1:00 PM - 2:30 PM',
    '3:00 PM - 4:30 PM',
    '5:00 PM - 6:30 PM',
    '7:00 PM - 8:30 PM',
  ];

  // Minimum date is tomorrow
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const minDateString = tomorrow.toISOString().split('T')[0];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!customerName.trim() || !phone.trim() || !preferredDate) {
      setError('Please provide your name, phone number, and preferred date.');
      return;
    }

    setLoading(true);
    try {
      await api.bookAppointment({
        customerName: customerName.trim(),
        phone: phone.trim(),
        email: email.trim() || undefined,
        preferredDate,
        preferredTimeSlot,
        categoryOfInterest,
        guestCount: Number(guestCount),
        message: message.trim() || undefined,
      });
      setConfirmed(true);
    } catch (err: any) {
      setError(err?.message || 'Failed to submit appointment request. Please retry.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="max-w-lg w-full bg-[#101115] border border-[#D4AF37]/50 rounded-sm shadow-2xl p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#9CA3AF] hover:text-white p-1"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {confirmed ? (
          <div className="text-center py-8 space-y-4">
            <CheckCircle2 className="w-14 h-14 text-[#D4AF37] mx-auto" />
            <h3 className="font-serif text-2xl font-bold text-[#F3F4F6]">
              Showroom Visit Requested
            </h3>
            <p className="text-xs text-[#9CA3AF] leading-relaxed max-w-sm mx-auto">
              Thank you, {customerName}. Your appointment request for{' '}
              <strong className="text-[#E6C687]">{preferredDate}</strong> at{' '}
              <strong className="text-[#E6C687]">{preferredTimeSlot}</strong> has been logged in our store registry. Our concierge team will confirm via WhatsApp or phone call.
            </p>
            <div className="pt-4">
              <button
                onClick={onClose}
                className="px-6 py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors"
              >
                Return to Store
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1">
              <span className="text-[10px] font-semibold tracking-wider text-[#E6C687] uppercase">
                Private Consultation
              </span>
              <h2 className="font-serif text-2xl font-bold text-[#F3F4F6]">
                Book a Flagship Boutique Visit
              </h2>
              <p className="text-xs text-[#9CA3AF]">
                Experience bridal trial sessions in our dedicated VIP lounge with our master gemologists.
              </p>
            </div>

            {error && (
              <div className="p-3 bg-red-950/40 border border-red-800 text-red-300 text-xs rounded-sm">
                {error}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Full Name *
                </label>
                <div className="relative">
                  <User className="w-3.5 h-3.5 absolute left-3 top-3 text-[#6B7280]" />
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Ananya Roy"
                    className="w-full bg-[#17181F] border border-[#2B2D38] rounded-sm pl-9 pr-3 py-2 text-[#F3F4F6] placeholder-[#6B7280] focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Phone Number (WhatsApp) *
                </label>
                <div className="relative">
                  <Phone className="w-3.5 h-3.5 absolute left-3 top-3 text-[#6B7280]" />
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98200 00000"
                    className="w-full bg-[#17181F] border border-[#2B2D38] rounded-sm pl-9 pr-3 py-2 text-[#F3F4F6] placeholder-[#6B7280] focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Preferred Date *
                </label>
                <div className="relative">
                  <Calendar className="w-3.5 h-3.5 absolute left-3 top-3 text-[#6B7280]" />
                  <input
                    type="date"
                    required
                    min={minDateString}
                    value={preferredDate}
                    onChange={(e) => setPreferredDate(e.target.value)}
                    className="w-full bg-[#17181F] border border-[#2B2D38] rounded-sm pl-9 pr-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Time Slot *
                </label>
                <div className="relative">
                  <Clock className="w-3.5 h-3.5 absolute left-3 top-3 text-[#6B7280]" />
                  <select
                    value={preferredTimeSlot}
                    onChange={(e) => setPreferredTimeSlot(e.target.value)}
                    className="w-full bg-[#17181F] border border-[#2B2D38] rounded-sm pl-9 pr-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                  >
                    {timeSlots.map((slot) => (
                      <option key={slot} value={slot} className="bg-[#101115]">
                        {slot}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Category of Interest
                </label>
                <select
                  value={categoryOfInterest}
                  onChange={(e) => setCategoryOfInterest(e.target.value)}
                  className="w-full bg-[#17181F] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                >
                  {categories.map((c) => (
                    <option key={c} value={c} className="bg-[#101115]">
                      {c}
                    </option>
                  ))}
                  <option value="Bridal Trousseau Consultation" className="bg-[#101115]">
                    Full Bridal Trousseau Consultation
                  </option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Accompanying Guests
                </label>
                <select
                  value={guestCount}
                  onChange={(e) => setGuestCount(Number(e.target.value))}
                  className="w-full bg-[#17181F] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                >
                  <option value={1} className="bg-[#101115]">1 Person</option>
                  <option value={2} className="bg-[#101115]">2 Persons</option>
                  <option value={3} className="bg-[#101115]">3 Persons (Family)</option>
                  <option value={4} className="bg-[#101115]">4+ Persons (Bridal Party)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                Special Requests or Specific Designs to Inspect
              </label>
              <textarea
                rows={2}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="e.g. We would like to view the Imperial Emerald Choker Set and discuss matching bangles."
                className="w-full bg-[#17181F] border border-[#2B2D38] rounded-sm p-2 text-xs text-[#F3F4F6] placeholder-[#6B7280] focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 text-xs font-bold uppercase tracking-widest text-[#0B0C0E] bg-gradient-to-r from-[#E6C687] to-[#D4AF37] hover:from-[#F0D8A8] hover:to-[#E5C158] disabled:opacity-50 rounded-sm transition-all shadow-md"
              >
                {loading ? 'Submitting Request...' : 'Confirm Appointment Request'}
              </button>
              <p className="text-[10px] text-[#71717A] text-center mt-2">
                Subject to confirmation by VJ Gold flagship boutique concierge.
              </p>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
