import React, { useState, useEffect } from 'react';
import { Product, GoldRates, StoreSettings, Enquiry, Appointment } from '../types';
import { api, formatINR } from '../services/api';
import {
  Lock,
  Unlock,
  Package,
  Users,
  Calendar,
  DollarSign,
  Settings,
  Plus,
  Trash2,
  Edit2,
  Save,
  Check,
  X,
  RefreshCw,
  Eye,
  ShieldCheck,
} from 'lucide-react';

interface AdminPageProps {
  products: Product[];
  rates: GoldRates;
  settings: StoreSettings;
  onRefreshData: () => Promise<void>;
}

export const AdminPage: React.FC<AdminPageProps> = ({
  products,
  rates,
  settings,
  onRefreshData,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return sessionStorage.getItem('vjg_admin_auth') === 'true';
  });
  const [pinInput, setPinInput] = useState('');
  const [authError, setAuthError] = useState('');

  const [activeTab, setActiveTab] = useState<'products' | 'enquiries' | 'appointments' | 'rates' | 'settings'>('products');

  // Enquiries & Appointments state
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loadingData, setLoadingData] = useState(false);

  // Edit / Create Product Modal
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [isCreatingNew, setIsCreatingNew] = useState(false);

  // Gold Rate form state
  const [rateForm, setRateForm] = useState<GoldRates>(rates);
  const [rateSaved, setRateSaved] = useState(false);

  // Settings form state
  const [settingsForm, setSettingsForm] = useState<StoreSettings>(settings);
  const [settingsSaved, setSettingsSaved] = useState(false);

  useEffect(() => {
    setRateForm(rates);
  }, [rates]);

  useEffect(() => {
    setSettingsForm(settings);
  }, [settings]);

  const loadAdminRecords = async () => {
    setLoadingData(true);
    try {
      const [enqs, apts] = await Promise.all([
        api.getEnquiries(),
        api.getAppointments(),
      ]);
      setEnquiries(enqs);
      setAppointments(apts);
    } catch (err) {
      console.warn('Failed to fetch admin data:', err);
    } finally {
      setLoadingData(false);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      loadAdminRecords();
    }
  }, [isAuthenticated]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Default authorized PIN for VJ Gold Store Manager: 7788
    if (pinInput === '7788' || pinInput === 'vjgold2026') {
      setIsAuthenticated(true);
      sessionStorage.setItem('vjg_admin_auth', 'true');
      setAuthError('');
    } else {
      setAuthError('Invalid Security PIN. (Default Store Manager PIN: 7788)');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('vjg_admin_auth');
  };

  // Product CRUD
  const handleSaveProduct = async () => {
    if (!editingProduct?.name || !editingProduct?.sku) {
      alert('Product Name and SKU are required');
      return;
    }

    try {
      if (isCreatingNew) {
        await api.createProduct({
          ...editingProduct,
          slug: editingProduct.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
          grossWeight: Number(editingProduct.grossWeight) || 10,
          netGoldWeight: Number(editingProduct.netGoldWeight) || 9,
          makingChargesPerGram: Number(editingProduct.makingChargesPerGram) || 600,
          price: editingProduct.price ? Number(editingProduct.price) : null,
          additionalImages: editingProduct.additionalImages || [],
          showIn3DShowroom: editingProduct.showIn3DShowroom ?? true,
          showroomZone: editingProduct.showroomZone || 'necklaces',
        });
      } else if (editingProduct.id) {
        await api.updateProduct(editingProduct.id, editingProduct);
      }
      await onRefreshData();
      setEditingProduct(null);
      setIsCreatingNew(false);
    } catch (err: any) {
      alert(`Error saving product: ${err.message}`);
    }
  };

  const handleDeleteProduct = async (id: string, name: string) => {
    if (confirm(`Are you sure you want to remove "${name}" from the catalogue?`)) {
      await api.deleteProduct(id);
      await onRefreshData();
    }
  };

  // Rates Update
  const handleSaveRates = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.updateGoldRates({
        ...rateForm,
        rate24kPerGram: Number(rateForm.rate24kPerGram),
        rate22kPerGram: Number(rateForm.rate22kPerGram),
        rate18kPerGram: Number(rateForm.rate18kPerGram),
        silverRatePerGram: Number(rateForm.silverRatePerGram),
      });
      await onRefreshData();
      setRateSaved(true);
      setTimeout(() => setRateSaved(false), 3000);
    } catch (err: any) {
      alert(`Error updating rates: ${err.message}`);
    }
  };

  // Settings Update
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await api.updateSettings(settingsForm);
      await onRefreshData();
      setSettingsSaved(true);
      setTimeout(() => setSettingsSaved(false), 3000);
    } catch (err: any) {
      alert(`Error updating settings: ${err.message}`);
    }
  };

  // Enquiry status change
  const handleEnquiryStatus = async (id: string, status: Enquiry['status'], notes?: string) => {
    await api.updateEnquiryStatus(id, status, notes);
    loadAdminRecords();
  };

  // Appointment status change
  const handleAppointmentStatus = async (id: string, status: Appointment['status'], notes?: string) => {
    await api.updateAppointmentStatus(id, status, notes);
    loadAdminRecords();
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-[#101115] border border-[#D4AF37]/50 rounded-sm p-8 shadow-2xl space-y-6">
          <div className="text-center space-y-2">
            <div className="w-12 h-12 mx-auto rounded-sm bg-[#1A1812] border border-[#D4AF37]/40 flex items-center justify-center text-[#E6C687]">
              <Lock className="w-6 h-6 text-[#D4AF37]" />
            </div>
            <h2 className="font-serif text-2xl font-bold text-[#F3F4F6]">
              VJ Gold Boutique Portal
            </h2>
            <p className="text-xs text-[#9CA3AF]">
              Restricted access for authorized store managers and goldsmiths.
            </p>
          </div>

          {authError && (
            <div className="p-3 bg-red-950/40 border border-red-800 text-red-300 text-xs rounded-sm">
              {authError}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                Store Manager Security PIN
              </label>
              <input
                type="password"
                required
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                placeholder="Enter 4-digit PIN (Default: 7788)"
                className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2.5 text-center text-sm tracking-widest text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
              />
              <span className="text-[10px] text-[#71717A] block mt-1 text-center">
                Default Master PIN: <strong>7788</strong>
              </span>
            </div>

            <button
              type="submit"
              className="w-full py-3 text-xs font-bold uppercase tracking-widest text-[#0B0C0E] bg-gradient-to-r from-[#E6C687] to-[#D4AF37] hover:from-[#F0D8A8] hover:to-[#E5C158] rounded-sm transition-all shadow-md flex items-center justify-center gap-2"
            >
              <Unlock className="w-3.5 h-3.5" />
              <span>Authenticate Session</span>
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Top Admin Bar */}
      <div className="bg-[#101115] border border-[#212228] p-5 rounded-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-semibold uppercase tracking-wider text-[#E6C687]">
            Store Administration Dashboard
          </span>
          <h1 className="font-serif text-2xl font-bold text-[#F3F4F6]">
            VJ Gold Inventory & Leads Console
          </h1>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={loadAdminRecords}
            disabled={loadingData}
            className="flex items-center gap-1.5 px-3 py-2 text-xs text-[#D1D5DB] bg-[#16171E] border border-[#2B2D38] rounded-sm hover:text-white"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loadingData ? 'animate-spin' : ''}`} />
            <span>Sync</span>
          </button>

          <button
            onClick={handleLogout}
            className="px-4 py-2 text-xs font-medium text-red-400 bg-red-950/20 border border-red-900/40 hover:bg-red-950/40 rounded-sm transition-colors"
          >
            Sign Out
          </button>
        </div>
      </div>

      {/* KPI Overview Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#101115] border border-[#212228] p-4 rounded-sm">
          <span className="text-[10px] uppercase text-[#71717A] tracking-wider block">
            Catalogue Pieces
          </span>
          <div className="font-mono tabular-nums text-2xl font-bold text-[#F3F4F6] mt-1">
            {products.length}
          </div>
          <span className="text-[10px] text-[#A1A1AA]">
            {products.filter((p) => p.isPriceVerified).length} with verified price
          </span>
        </div>

        <div className="bg-[#101115] border border-[#212228] p-4 rounded-sm">
          <span className="text-[10px] uppercase text-[#71717A] tracking-wider block">
            Customer Inquiries
          </span>
          <div className="font-mono tabular-nums text-2xl font-bold text-[#E6C687] mt-1">
            {enquiries.length}
          </div>
          <span className="text-[10px] text-[#A1A1AA]">
            {enquiries.filter((e) => e.status === 'New').length} pending review
          </span>
        </div>

        <div className="bg-[#101115] border border-[#212228] p-4 rounded-sm">
          <span className="text-[10px] uppercase text-[#71717A] tracking-wider block">
            Showroom Appointments
          </span>
          <div className="font-mono tabular-nums text-2xl font-bold text-[#10B981] mt-1">
            {appointments.length}
          </div>
          <span className="text-[10px] text-[#A1A1AA]">
            {appointments.filter((a) => a.status === 'Requested').length} awaiting confirmation
          </span>
        </div>

        <div className="bg-[#101115] border border-[#212228] p-4 rounded-sm">
          <span className="text-[10px] uppercase text-[#71717A] tracking-wider block">
            Active 22K Bullion Rate
          </span>
          <div className="font-mono tabular-nums text-2xl font-bold text-[#F3F4F6] mt-1">
            ₹{rates.rate22kPerGram}/g
          </div>
          <span className="text-[10px] text-[#A1A1AA]">Daily rate active</span>
        </div>
      </div>

      {/* Navigation Tabs (Rule 1A compliant buttons) */}
      <div className="flex items-center gap-1.5 border-b border-[#212228] pb-3 overflow-x-auto scrollbar-none">
        <button
          onClick={() => setActiveTab('products')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-sm whitespace-nowrap shrink-0 transition-colors ${
            activeTab === 'products'
              ? 'bg-[#E6C687] text-[#0B0C0E]'
              : 'text-[#D1D5DB] hover:text-white bg-[#14151B] border border-[#262731]'
          }`}
        >
          <Package className="w-3.5 h-3.5" />
          <span>Product Catalogue ({products.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('enquiries')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-sm whitespace-nowrap shrink-0 transition-colors ${
            activeTab === 'enquiries'
              ? 'bg-[#E6C687] text-[#0B0C0E]'
              : 'text-[#D1D5DB] hover:text-white bg-[#14151B] border border-[#262731]'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Leads & Enquiries ({enquiries.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('appointments')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-sm whitespace-nowrap shrink-0 transition-colors ${
            activeTab === 'appointments'
              ? 'bg-[#E6C687] text-[#0B0C0E]'
              : 'text-[#D1D5DB] hover:text-white bg-[#14151B] border border-[#262731]'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Showroom Visits ({appointments.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('rates')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-sm whitespace-nowrap shrink-0 transition-colors ${
            activeTab === 'rates'
              ? 'bg-[#E6C687] text-[#0B0C0E]'
              : 'text-[#D1D5DB] hover:text-white bg-[#14151B] border border-[#262731]'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          <span>Daily Gold Rates</span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-sm whitespace-nowrap shrink-0 transition-colors ${
            activeTab === 'settings'
              ? 'bg-[#E6C687] text-[#0B0C0E]'
              : 'text-[#D1D5DB] hover:text-white bg-[#14151B] border border-[#262731]'
          }`}
        >
          <Settings className="w-3.5 h-3.5" />
          <span>Store Settings</span>
        </button>
      </div>

      {/* TAB 1: PRODUCT CATALOGUE */}
      {activeTab === 'products' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="font-serif text-xl font-bold text-[#F3F4F6]">
              Jewellery Records ({products.length})
            </h3>
            <button
              onClick={() => {
                setIsCreatingNew(true);
                setEditingProduct({
                  id: `vjg-${Date.now()}`,
                  sku: `VJG-NC-${String(products.length + 1).padStart(3, '0')}`,
                  name: '',
                  category: 'Necklaces & Chokers',
                  description: '',
                  primaryImage: '/src/assets/images/emerald_choker_set_slate_1791987078349.jpg',
                  goldPurity: '22K (916) Hallmark',
                  grossWeight: 35.0,
                  netGoldWeight: 32.5,
                  stoneWeight: 2.5,
                  stoneDetails: 'Certified Diamonds & Gemstones',
                  makingChargesPerGram: 650,
                  isPriceVerified: true,
                  price: 245000,
                  availability: 'Available in Showroom',
                  isFeatured: false,
                  isNewArrival: true,
                  showIn3DShowroom: true,
                  showroomZone: 'necklaces',
                });
              }}
              className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Jewellery Piece</span>
            </button>
          </div>

          <div className="bg-[#101115] border border-[#212228] rounded-sm overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#16171E] text-[#9CA3AF] border-b border-[#212228] uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3">Piece</th>
                  <th className="p-3">SKU</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Purity / Wt.</th>
                  <th className="p-3">Price</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1D1E25] text-[#D1D5DB]">
                {products.map((p) => (
                  <tr key={p.id} className="hover:bg-[#14151C] transition-colors">
                    <td className="p-3 flex items-center gap-3">
                      <img
                        src={p.primaryImage}
                        alt={p.name}
                        className="w-10 h-10 object-cover rounded-sm border border-[#2B2D38]"
                      />
                      <div>
                        <div className="font-semibold text-[#F3F4F6] line-clamp-1">{p.name}</div>
                        <div className="text-[10px] text-[#A1A1AA]">{p.goldPurity}</div>
                      </div>
                    </td>
                    <td className="p-3 font-mono text-xs">{p.sku}</td>
                    <td className="p-3">{p.category}</td>
                    <td className="p-3 font-mono tabular-nums">
                      {p.grossWeight}g gross / {p.netGoldWeight}g net
                    </td>
                    <td className="p-3 font-mono tabular-nums font-semibold text-[#E6C687]">
                      {p.isPriceVerified && p.price ? formatINR(p.price) : 'On Request'}
                    </td>
                    <td className="p-3">
                      <span className="text-[10px] px-2 py-0.5 rounded-sm bg-[#16171E] text-[#10B981] border border-[#2B2D38]">
                        {p.availability}
                      </span>
                    </td>
                    <td className="p-3 text-right space-x-2">
                      <button
                        onClick={() => {
                          setIsCreatingNew(false);
                          setEditingProduct(p);
                        }}
                        className="p-1.5 text-[#E6C687] hover:text-white"
                        title="Edit piece"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteProduct(p.id, p.name)}
                        className="p-1.5 text-red-400 hover:text-red-300"
                        title="Remove piece"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: LEADS & ENQUIRIES */}
      {activeTab === 'enquiries' && (
        <div className="space-y-4">
          <h3 className="font-serif text-xl font-bold text-[#F3F4F6]">
            Customer Inquiries & WhatsApp Leads ({enquiries.length})
          </h3>

          <div className="bg-[#101115] border border-[#212228] rounded-sm overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#16171E] text-[#9CA3AF] border-b border-[#212228] uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3">Customer</th>
                  <th className="p-3">Contact</th>
                  <th className="p-3">Inquiry Type</th>
                  <th className="p-3">Message</th>
                  <th className="p-3">Date</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1D1E25] text-[#D1D5DB]">
                {enquiries.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-6 text-center text-[#71717A]">
                      No inquiries logged yet.
                    </td>
                  </tr>
                ) : (
                  enquiries.map((e) => (
                    <tr key={e.id} className="hover:bg-[#14151C] transition-colors">
                      <td className="p-3 font-semibold text-[#F3F4F6]">{e.customerName}</td>
                      <td className="p-3 font-mono">{e.phone}</td>
                      <td className="p-3 text-[#E6C687]">{e.enquiryType}</td>
                      <td className="p-3 max-w-xs truncate text-[#9CA3AF]" title={e.message}>
                        {e.message}
                      </td>
                      <td className="p-3 font-mono text-[10px] text-[#71717A]">
                        {new Date(e.createdAt).toLocaleDateString()}
                      </td>
                      <td className="p-3">
                        <select
                          value={e.status}
                          onChange={(ev) => handleEnquiryStatus(e.id, ev.target.value as any)}
                          className="bg-[#16171E] border border-[#2B2D38] rounded-sm px-2 py-1 text-xs text-[#D1D5DB]"
                        >
                          <option value="New">New</option>
                          <option value="Contacted">Contacted</option>
                          <option value="Follow-up">Follow-up</option>
                          <option value="Quotation Requested">Quotation Requested</option>
                          <option value="Converted">Converted</option>
                          <option value="Closed">Closed</option>
                        </select>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: SHOWROOM APPOINTMENTS */}
      {activeTab === 'appointments' && (
        <div className="space-y-4">
          <h3 className="font-serif text-xl font-bold text-[#F3F4F6]">
            Showroom Visit Requests ({appointments.length})
          </h3>

          <div className="bg-[#101115] border border-[#212228] rounded-sm overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#16171E] text-[#9CA3AF] border-b border-[#212228] uppercase tracking-wider text-[10px]">
                <tr>
                  <th className="p-3">Client</th>
                  <th className="p-3">Phone</th>
                  <th className="p-3">Requested Date & Slot</th>
                  <th className="p-3">Interest / Guests</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1D1E25] text-[#D1D5DB]">
                {appointments.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-6 text-center text-[#71717A]">
                      No showroom visit bookings recorded.
                    </td>
                  </tr>
                ) : (
                  appointments.map((a) => (
                    <tr key={a.id} className="hover:bg-[#14151C] transition-colors">
                      <td className="p-3 font-semibold text-[#F3F4F6]">{a.customerName}</td>
                      <td className="p-3 font-mono">{a.phone}</td>
                      <td className="p-3">
                        <div className="font-medium text-[#E6C687]">{a.preferredDate}</div>
                        <div className="text-[10px] text-[#A1A1AA]">{a.preferredTimeSlot}</div>
                      </td>
                      <td className="p-3">
                        <div>{a.categoryOfInterest}</div>
                        <div className="text-[10px] text-[#71717A]">{a.guestCount} guests</div>
                      </td>
                      <td className="p-3">
                        <select
                          value={a.status}
                          onChange={(ev) => handleAppointmentStatus(a.id, ev.target.value as any)}
                          className="bg-[#16171E] border border-[#2B2D38] rounded-sm px-2 py-1 text-xs text-[#D1D5DB]"
                        >
                          <option value="Requested">Requested</option>
                          <option value="Confirmed">Confirmed</option>
                          <option value="Completed">Completed</option>
                          <option value="Cancelled">Cancelled</option>
                        </select>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: DAILY GOLD RATES */}
      {activeTab === 'rates' && (
        <div className="max-w-xl space-y-6">
          <div className="space-y-1">
            <h3 className="font-serif text-xl font-bold text-[#F3F4F6]">
              Manage Daily Bullion Rates
            </h3>
            <p className="text-xs text-[#9CA3AF]">
              Update the active spot rates per gram. These figures immediately recalculate all estimations on the customer website and 3D showroom.
            </p>
          </div>

          {rateSaved && (
            <div className="p-3 bg-emerald-950/40 border border-emerald-800 text-emerald-300 text-xs rounded-sm flex items-center gap-2">
              <Check className="w-4 h-4" />
              <span>Bullion rates updated successfully across store.</span>
            </div>
          )}

          <form onSubmit={handleSaveRates} className="bg-[#101115] border border-[#212228] p-6 rounded-sm space-y-4 text-xs">
            <div>
              <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                24K (999) Fine Gold Rate (₹ / Gram)
              </label>
              <input
                type="number"
                required
                value={rateForm.rate24kPerGram}
                onChange={(e) => setRateForm({ ...rateForm, rate24kPerGram: Number(e.target.value) })}
                className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] font-mono tabular-nums focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                22K (916) Hallmark Gold Rate (₹ / Gram)
              </label>
              <input
                type="number"
                required
                value={rateForm.rate22kPerGram}
                onChange={(e) => setRateForm({ ...rateForm, rate22kPerGram: Number(e.target.value) })}
                className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] font-mono tabular-nums focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                18K (750) Hallmark Gold Rate (₹ / Gram)
              </label>
              <input
                type="number"
                required
                value={rateForm.rate18kPerGram}
                onChange={(e) => setRateForm({ ...rateForm, rate18kPerGram: Number(e.target.value) })}
                className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] font-mono tabular-nums focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                Silver Rate (₹ / Gram)
              </label>
              <input
                type="number"
                required
                value={rateForm.silverRatePerGram}
                onChange={(e) => setRateForm({ ...rateForm, silverRatePerGram: Number(e.target.value) })}
                className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] font-mono tabular-nums focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors flex items-center justify-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Save & Publish Live Gold Rates</span>
            </button>
          </form>
        </div>
      )}

      {/* TAB 5: STORE SETTINGS */}
      {activeTab === 'settings' && (
        <div className="max-w-xl space-y-6">
          <div className="space-y-1">
            <h3 className="font-serif text-xl font-bold text-[#F3F4F6]">
              Boutique Contact & Configuration
            </h3>
            <p className="text-xs text-[#9CA3AF]">
              Configure official phone numbers, WhatsApp routing, and flagship address.
            </p>
          </div>

          {settingsSaved && (
            <div className="p-3 bg-emerald-950/40 border border-emerald-800 text-emerald-300 text-xs rounded-sm flex items-center gap-2">
              <Check className="w-4 h-4" />
              <span>Store settings updated successfully.</span>
            </div>
          )}

          <form onSubmit={handleSaveSettings} className="bg-[#101115] border border-[#212228] p-6 rounded-sm space-y-4 text-xs">
            <div>
              <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                WhatsApp Number (for direct enquiries without '+')
              </label>
              <input
                type="text"
                required
                value={settingsForm.whatsappNumber}
                onChange={(e) => setSettingsForm({ ...settingsForm, whatsappNumber: e.target.value })}
                className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] font-mono focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                Display Phone Number
              </label>
              <input
                type="text"
                required
                value={settingsForm.phone}
                onChange={(e) => setSettingsForm({ ...settingsForm, phone: e.target.value })}
                className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                Email Address
              </label>
              <input
                type="email"
                required
                value={settingsForm.email}
                onChange={(e) => setSettingsForm({ ...settingsForm, email: e.target.value })}
                className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                Showroom Address
              </label>
              <textarea
                rows={2}
                required
                value={settingsForm.address}
                onChange={(e) => setSettingsForm({ ...settingsForm, address: e.target.value })}
                className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm p-2 text-xs text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors flex items-center justify-center gap-1.5"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Update Store Settings</span>
            </button>
          </form>
        </div>
      )}

      {/* Product Edit / Create Modal */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="max-w-2xl w-full bg-[#101115] border border-[#D4AF37]/50 rounded-sm shadow-2xl p-6 max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between border-b border-[#212228] pb-3">
              <h3 className="font-serif text-xl font-bold text-[#F3F4F6]">
                {isCreatingNew ? 'Add New Jewellery Piece' : `Edit ${editingProduct.name}`}
              </h3>
              <button
                onClick={() => setEditingProduct(null)}
                className="text-[#9CA3AF] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Product Name *
                </label>
                <input
                  type="text"
                  required
                  value={editingProduct.name || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                  placeholder="e.g. Imperial Emerald & Pavé Diamond Choker Set"
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  SKU / Identifier *
                </label>
                <input
                  type="text"
                  required
                  value={editingProduct.sku || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, sku: e.target.value })}
                  placeholder="e.g. VJG-NC-001"
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] font-mono focus:border-[#D4AF37] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Category
                </label>
                <select
                  value={editingProduct.category || 'Necklaces & Chokers'}
                  onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                >
                  <option value="Necklaces & Chokers">Necklaces & Chokers</option>
                  <option value="Bangles & Bracelets">Bangles & Bracelets</option>
                  <option value="Rings & Earrings">Rings & Earrings</option>
                  <option value="Gold Chains">Gold Chains</option>
                  <option value="Pendants">Pendants</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Gold Purity
                </label>
                <input
                  type="text"
                  value={editingProduct.goldPurity || '22K (916) Hallmark'}
                  onChange={(e) => setEditingProduct({ ...editingProduct, goldPurity: e.target.value })}
                  placeholder="e.g. 22K (916) / 18K (750)"
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Gross Weight (Grams)
                </label>
                <input
                  type="number"
                  step={0.1}
                  value={editingProduct.grossWeight || 0}
                  onChange={(e) => setEditingProduct({ ...editingProduct, grossWeight: Number(e.target.value) })}
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] font-mono focus:border-[#D4AF37] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Net Gold Weight (Grams)
                </label>
                <input
                  type="number"
                  step={0.1}
                  value={editingProduct.netGoldWeight || 0}
                  onChange={(e) => setEditingProduct({ ...editingProduct, netGoldWeight: Number(e.target.value) })}
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] font-mono focus:border-[#D4AF37] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Price (₹ INR, leave empty if On Request)
                </label>
                <input
                  type="number"
                  value={editingProduct.price || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, price: e.target.value ? Number(e.target.value) : null, isPriceVerified: Boolean(e.target.value) })}
                  placeholder="e.g. 348500"
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] font-mono focus:border-[#D4AF37] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Availability
                </label>
                <select
                  value={editingProduct.availability || 'Available in Showroom'}
                  onChange={(e) => setEditingProduct({ ...editingProduct, availability: e.target.value })}
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                >
                  <option value="Available in Showroom">Available in Showroom</option>
                  <option value="Made to Order / Trial in Store">Made to Order / Trial in Store</option>
                  <option value="Reserved">Reserved</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Primary Image Path or URL
                </label>
                <input
                  type="text"
                  value={editingProduct.primaryImage || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, primaryImage: e.target.value })}
                  placeholder="/src/assets/images/emerald_choker_set_slate_1791987078349.jpg"
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] font-mono focus:border-[#D4AF37] focus:outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Stone Details
                </label>
                <input
                  type="text"
                  value={editingProduct.stoneDetails || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, stoneDetails: e.target.value })}
                  placeholder="e.g. Natural Oval Green Emerald (2.10 ct) with Diamonds (2.50 ctw)"
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Description
                </label>
                <textarea
                  rows={3}
                  value={editingProduct.description || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                  placeholder="Detailed description of craftsmanship and design..."
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm p-2 text-xs text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-[#212228]">
              <button
                type="button"
                onClick={() => setEditingProduct(null)}
                className="px-4 py-2 text-xs text-[#9CA3AF] hover:text-white"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveProduct}
                className="px-6 py-2 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm"
              >
                Save Product
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
