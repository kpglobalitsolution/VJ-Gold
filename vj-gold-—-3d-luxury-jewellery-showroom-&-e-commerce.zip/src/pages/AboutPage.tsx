import React from 'react';
import { StoreSettings } from '../types';
import { ShieldCheck, Award, Gem, Instagram, ExternalLink, Calendar, MapPin } from 'lucide-react';

interface AboutPageProps {
  settings: StoreSettings;
  onOpenAppointment: () => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ settings, onOpenAppointment }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Editorial Header */}
      <div className="max-w-3xl mx-auto text-center space-y-4">
        <span className="text-xs font-semibold uppercase tracking-widest text-[#E6C687]">
          Haute Joaillerie & Indian Craftsmanship
        </span>
        <h1 className="font-serif text-4xl sm:text-5xl font-bold text-[#F3F4F6] text-balance">
          The Art of Fine Jewellery at VJ Gold
        </h1>
        <p className="text-sm text-[#9CA3AF] leading-relaxed">
          Founded on uncompromised integrity, rigorous Bureau of Indian Standards (BIS) hallmarking, and exquisite gemological artistry, VJ Gold curates exceptional gold, emerald, and diamond pieces that endure across generations.
        </p>
      </div>

      {/* Brand Hero Visual Showcase */}
      <div className="relative aspect-[21/9] w-full rounded-sm overflow-hidden border border-[#2B2D38] shadow-2xl">
        <img
          src="/src/assets/images/vj_gold_showroom_interior_1791987078371.jpg"
          alt="VJ Gold Flagship Boutique Interior"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C0E]/90 via-[#0B0C0E]/30 to-transparent flex flex-col justify-end p-8 sm:p-12">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#E6C687]">
            Flagship Atelier
          </span>
          <div className="font-serif text-2xl sm:text-3xl font-bold text-[#F3F4F6]">
            The Luxury Consultation Sanctuary
          </div>
          <p className="text-xs sm:text-sm text-[#9CA3AF] max-w-xl mt-1">
            Where each client receives personalized attention, gemological appraisals, and private bridal suite trials.
          </p>
        </div>
      </div>

      {/* 3 Core Heritage Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-[#101115] border border-[#212228] p-7 rounded-sm space-y-3">
          <div className="w-10 h-10 rounded-sm bg-[#16171E] border border-[#2A2B33] flex items-center justify-center text-[#E6C687]">
            <ShieldCheck className="w-5 h-5 text-[#D4AF37]" />
          </div>
          <h3 className="font-serif text-xl font-bold text-[#F3F4F6]">
            Mandatory BIS Hallmarking
          </h3>
          <p className="text-xs text-[#9CA3AF] leading-relaxed">
            Every piece crafted by VJ Gold bears the official 6-digit HUID (Hallmark Unique Identification) stamped under Bureau of Indian Standards authority. 916 purity for 22 Karat and 750 purity for 18 Karat gold are verified and weighed before your eyes.
          </p>
        </div>

        <div className="bg-[#101115] border border-[#212228] p-7 rounded-sm space-y-3">
          <div className="w-10 h-10 rounded-sm bg-[#16171E] border border-[#2A2B33] flex items-center justify-center text-[#E6C687]">
            <Gem className="w-5 h-5 text-[#D4AF37]" />
          </div>
          <h3 className="font-serif text-xl font-bold text-[#F3F4F6]">
            Natural Unheated Gemstones
          </h3>
          <p className="text-xs text-[#9CA3AF] leading-relaxed">
            Our signature choker collar sets feature radiant natural emerald cabochons and baguettes selected for rich saturation and crystalline clarity, matched with certified conflict-free natural diamonds.
          </p>
        </div>

        <div className="bg-[#101115] border border-[#212228] p-7 rounded-sm space-y-3">
          <div className="w-10 h-10 rounded-sm bg-[#16171E] border border-[#2A2B33] flex items-center justify-center text-[#E6C687]">
            <Award className="w-5 h-5 text-[#D4AF37]" />
          </div>
          <h3 className="font-serif text-xl font-bold text-[#F3F4F6]">
            Transparent Gold Accounting
          </h3>
          <p className="text-xs text-[#9CA3AF] leading-relaxed">
            We provide unambiguous invoice breakdowns: net gold weight, stone weight deducted, honest making charges, and daily spot metal rates. No hidden markups or fabricated charges.
          </p>
        </div>
      </div>

      {/* Official Links & Social Presence */}
      <div className="bg-[#121316] border border-[#24252D] p-8 rounded-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#E6C687]">
            Official Brand Handles
          </span>
          <h3 className="font-serif text-2xl font-bold text-[#F3F4F6]">
            Connect with VJ Gold
          </h3>
          <p className="text-xs text-[#9CA3AF] max-w-lg">
            Follow our Instagram feed for daily design unveilings, bride testimonials, and gold rate updates.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <a
            href={settings.instagram || 'https://www.instagram.com/vj._.gold/'}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-[#E6C687] bg-[#1A1812] border border-[#D4AF37]/50 rounded-sm hover:bg-[#D4AF37] hover:text-[#0B0C0E] transition-all"
          >
            <Instagram className="w-4 h-4" />
            <span>Instagram: @vj._.gold</span>
            <ExternalLink className="w-3.5 h-3.5 opacity-60" />
          </a>

          <button
            onClick={onOpenAppointment}
            className="flex items-center gap-2 px-5 py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors"
          >
            <Calendar className="w-4 h-4" />
            <span>Book Boutique Visit</span>
          </button>
        </div>
      </div>
    </div>
  );
};
