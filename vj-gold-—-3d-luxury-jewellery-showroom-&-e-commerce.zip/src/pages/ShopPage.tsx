import React, { useState, useMemo } from 'react';
import { Product } from '../types';
import { ProductCard } from '../components/ProductCard';
import { ProductCompareModal } from '../components/ProductCompareModal';
import { Search, Filter, Sparkles, RotateCcw, Scale, ArrowRight, Check, AlertCircle } from 'lucide-react';

interface ShopPageProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onInspect3D: (product: Product) => void;
  whatsappNumber: string;
}

export const ShopPage: React.FC<ShopPageProps> = ({
  products,
  onSelectProduct,
  onInspect3D,
  whatsappNumber,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPurity, setSelectedPurity] = useState<string>('all');
  const [onlyVerifiedPrices, setOnlyVerifiedPrices] = useState(false);
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'weight'>('featured');

  // Compare Products State (up to 3 items)
  const [compareList, setCompareList] = useState<Product[]>([]);
  const [isCompareOpen, setIsCompareOpen] = useState(false);
  const [compareWarning, setCompareWarning] = useState<string | null>(null);

  const handleToggleCompare = (product: Product) => {
    setCompareList((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        setCompareWarning(null);
        return prev.filter((p) => p.id !== product.id);
      }
      if (prev.length >= 3) {
        setCompareWarning('You can compare up to 3 items at a time. Click "Compare Now" or deselect an item.');
        setTimeout(() => setCompareWarning(null), 4000);
        return prev;
      }
      setCompareWarning(null);
      return [...prev, product];
    });
  };

  const handleRemoveFromCompare = (productId: string) => {
    setCompareList((prev) => prev.filter((p) => p.id !== productId));
  };

  const handleClearCompare = () => {
    setCompareList([]);
    setCompareWarning(null);
  };

  const categories = useMemo(() => {
    const set = new Set(products.map((p) => p.category));
    return ['All', ...Array.from(set)];
  }, [products]);

  const filteredProducts = useMemo(() => {
    return products
      .filter((p) => {
        if (selectedCategory !== 'All' && p.category !== selectedCategory) return false;
        if (onlyVerifiedPrices && (!p.isPriceVerified || !p.price)) return false;
        if (selectedPurity !== 'all') {
          if (!p.goldPurity.toLowerCase().includes(selectedPurity.toLowerCase())) return false;
        }
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchName = p.name.toLowerCase().includes(q);
          const matchSku = p.sku.toLowerCase().includes(q);
          const matchDesc = p.description.toLowerCase().includes(q);
          const matchCat = p.category.toLowerCase().includes(q);
          if (!matchName && !matchSku && !matchDesc && !matchCat) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'price-low') {
          return (a.price || 9999999) - (b.price || 9999999);
        }
        if (sortBy === 'price-high') {
          return (b.price || 0) - (a.price || 0);
        }
        if (sortBy === 'weight') {
          return b.grossWeight - a.grossWeight;
        }
        return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
      });
  }, [products, selectedCategory, searchQuery, selectedPurity, onlyVerifiedPrices, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Page Header */}
      <div className="space-y-2 border-b border-[#212228] pb-6">
        <span className="text-xs font-semibold uppercase tracking-wider text-[#E6C687]">
          Fine Jewellery Collection
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#F3F4F6]">
          Catalogue & Showroom Pieces
        </h1>
        <p className="text-xs text-[#9CA3AF] max-w-2xl leading-relaxed">
          Explore our real collection of handcrafted chokers, necklaces, royal bangles, and diamond cocktail rings. Prices and weights are verified against our workshop records.
        </p>
      </div>

      {/* Filter and Search Controls */}
      <div className="space-y-4 bg-[#101115] border border-[#212228] p-4 sm:p-5 rounded-sm">
        {/* Category Tabs (Functional buttons with clean states, Rule 1A) */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 text-xs font-medium rounded-sm whitespace-nowrap shrink-0 transition-colors ${
                selectedCategory === cat
                  ? 'bg-[#E6C687] text-[#0B0C0E] font-semibold'
                  : 'text-[#D1D5DB] hover:text-[#FFF8E7] bg-[#16171E] hover:bg-[#20222A] border border-[#2B2D38]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Sub-Filters Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs pt-2 border-t border-[#1C1D24]">
          {/* Search Bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-[#6B7280]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name, SKU, stone..."
              className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm pl-9 pr-3 py-2 text-xs text-[#F3F4F6] placeholder-[#6B7280] focus:border-[#D4AF37] focus:outline-none"
            />
          </div>

          {/* Purity Select */}
          <div>
            <select
              value={selectedPurity}
              onChange={(e) => setSelectedPurity(e.target.value)}
              className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-xs text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
            >
              <option value="all">All Gold Purities</option>
              <option value="22k">22K (916) Hallmark</option>
              <option value="18k">18K (750) Hallmark</option>
            </select>
          </div>

          {/* Sorting */}
          <div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-xs text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
            >
              <option value="featured">Featured First</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="weight">Gross Weight: Highest</option>
            </select>
          </div>

          {/* Verified price toggle */}
          <div className="flex items-center gap-2 px-3 py-2 bg-[#16171E] border border-[#2B2D38] rounded-sm">
            <input
              type="checkbox"
              id="verifiedOnly"
              checked={onlyVerifiedPrices}
              onChange={(e) => setOnlyVerifiedPrices(e.target.checked)}
              className="rounded text-[#D4AF37] focus:ring-0 bg-[#0E0F13] border-[#3F3F46]"
            />
            <label htmlFor="verifiedOnly" className="text-[11px] text-[#D1D5DB] select-none cursor-pointer">
              Listed Prices Only
            </label>
          </div>
        </div>
      </div>

      {/* Product Count & Active Filters Indicator */}
      <div className="flex items-center justify-between text-xs text-[#9CA3AF]">
        <div>
          Showing <span className="font-semibold text-[#F3F4F6]">{filteredProducts.length}</span> pieces
          {selectedCategory !== 'All' && <span> in {selectedCategory}</span>}
        </div>

        {(searchQuery || selectedCategory !== 'All' || selectedPurity !== 'all' || onlyVerifiedPrices) && (
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSearchQuery('');
              setSelectedPurity('all');
              setOnlyVerifiedPrices(false);
            }}
            className="flex items-center gap-1 text-[#E6C687] hover:underline"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Filters</span>
          </button>
        )}
      </div>

      {/* Comparison limit notice toast */}
      {compareWarning && (
        <div className="p-3 bg-amber-950/40 border border-amber-600/60 rounded-sm text-xs text-amber-200 flex items-center justify-between gap-2 shadow-lg animate-fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-[#D4AF37] shrink-0" />
            <span>{compareWarning}</span>
          </div>
          <button
            onClick={() => setIsCompareOpen(true)}
            className="underline font-semibold text-[#FFF8E7] hover:text-white shrink-0"
          >
            Open Compare Now →
          </button>
        </div>
      )}

      {/* Product Grid */}
      {filteredProducts.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={onSelectProduct}
              onInspect3D={onInspect3D}
              whatsappNumber={whatsappNumber}
              isComparing={compareList.some((c) => c.id === product.id)}
              onToggleCompare={handleToggleCompare}
            />
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="text-center py-16 bg-[#101115] border border-[#212228] rounded-sm space-y-4">
          <Sparkles className="w-10 h-10 text-[#71717A] mx-auto" />
          <h3 className="font-serif text-xl font-bold text-[#F3F4F6]">
            No Jewellery Matches Your Selection
          </h3>
          <p className="text-xs text-[#9CA3AF] max-w-sm mx-auto">
            Try adjusting your search query, switching gold purity, or clearing the filter options.
          </p>
          <button
            onClick={() => {
              setSelectedCategory('All');
              setSearchQuery('');
              setSelectedPurity('all');
              setOnlyVerifiedPrices(false);
            }}
            className="px-5 py-2 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors"
          >
            Show All Pieces
          </button>
        </div>
      )}

      {/* Floating Compare Bottom Bar */}
      {compareList.length > 0 && (
        <aside
          aria-label="Product comparison bar"
          className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 w-[94%] max-w-2xl bg-[#14151C]/95 backdrop-blur-md border border-[#D4AF37]/80 rounded-sm shadow-2xl p-3 sm:px-4 sm:py-3 flex items-center justify-between gap-3 text-xs ring-1 ring-[#D4AF37]/30"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex items-center gap-1.5 shrink-0">
              <Scale className="w-4 h-4 text-[#D4AF37]" />
              <span className="font-semibold text-[#F3F4F6] hidden sm:inline">Compare:</span>
              <span className="font-mono text-[#E6C687] font-bold">({compareList.length}/3)</span>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto py-0.5 scrollbar-none">
              {compareList.map((p) => (
                <div key={p.id} className="relative group shrink-0">
                  <img
                    src={p.primaryImage}
                    alt={p.name}
                    className="w-10 h-10 object-cover rounded-sm border border-[#3A3B47]"
                    title={p.name}
                  />
                  <button
                    onClick={() => handleRemoveFromCompare(p.id)}
                    className="absolute -top-1.5 -right-1.5 bg-[#1F2028] text-white hover:text-red-400 rounded-full w-4 h-4 flex items-center justify-center border border-[#4B4D5C] text-[10px]"
                    title="Remove piece"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setIsCompareOpen(true)}
              className="px-3.5 py-2 text-xs font-bold text-[#0B0C0E] bg-gradient-to-r from-[#E6C687] to-[#D4AF37] hover:from-[#F0D8A8] hover:to-[#E5C158] rounded-sm transition-all shadow-md flex items-center gap-1.5"
            >
              <span>Compare Now</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={handleClearCompare}
              className="p-2 text-[#9CA3AF] hover:text-white"
              title="Clear comparison list"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </aside>
      )}

      {/* Side-by-Side Product Comparison Modal */}
      <ProductCompareModal
        isOpen={isCompareOpen}
        onClose={() => setIsCompareOpen(false)}
        products={compareList}
        onRemove={handleRemoveFromCompare}
        onClear={handleClearCompare}
        onSelectProduct={onSelectProduct}
        onInspect3D={onInspect3D}
        whatsappNumber={whatsappNumber}
      />
    </div>
  );
};
