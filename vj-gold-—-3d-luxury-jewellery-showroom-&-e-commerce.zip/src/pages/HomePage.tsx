import React from 'react';
import { Product, GoldRates, StoreSettings } from '../types';
import { ProductCard } from '../components/ProductCard';
import {
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Calendar,
  MessageCircle,
  Gem,
  Award,
  Layers,
  Compass,
} from 'lucide-react';
import { buildWhatsAppLink } from '../services/api';

interface HomePageProps {
  products: Product[];
  rates: GoldRates;
  settings: StoreSettings;
  onNavigate: (tab: string) => void;
  onSelectProduct: (product: Product) => void;
  onInspect3D: (product: Product) => void;
  onOpenAppointment: () => void;
  onOpenConsultant: () => void;
  whatsappNumber: string;
}

export const HomePage: React.FC<HomePageProps> = ({
  products,
  rates,
  settings,
  onNavigate,
  onSelectProduct,
  onInspect3D,
  onOpenAppointment,
  onOpenConsultant,
  whatsappNumber,
}) => {
  const featuredProducts = products.filter((p) => p.isFeatured).slice(0, 4);

  return (
    <div className="space-y-20 pb-20">
      {/* Hero Section */}
      <section className="relative pt-6 sm:pt-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column: Brand Statement & Route to Showroom */}
          <div className="lg:col-span-7 space-y-6">
            <div className="flex items-center gap-2 text-xs font-semibold tracking-widest uppercase text-[#E6C687]">
              <Sparkles className="w-4 h-4 text-[#D4AF37]" />
              <span>Haute Joaillerie & Royal Bullion</span>
            </div>

            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-[#F3F4F6] leading-[1.15] text-balance">
              Where Precious Heritage Meets Contemporary Precision.
            </h1>

            <p className="text-sm sm:text-base text-[#9CA3AF] leading-relaxed max-w-xl">
              Experience the digital flagship of <strong>VJ Gold</strong>. Walk through our photorealistic 3D showroom, inspect handcrafted statement chokers with natural Colombian emeralds and certified diamond pavé, and consult with our jewellery specialists in real time.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 pt-2">
              <button
                onClick={() => onNavigate('showroom')}
                className="px-8 py-3.5 text-xs font-bold uppercase tracking-widest text-[#0B0C0E] bg-gradient-to-r from-[#E6C687] via-[#D4AF37] to-[#E6C687] hover:brightness-110 rounded-sm transition-all shadow-xl flex items-center justify-center gap-2"
              >
                <Compass className="w-4 h-4" />
                <span>Enter 3D Digital Showroom</span>
              </button>

              <button
                onClick={() => onNavigate('shop')}
                className="px-6 py-3.5 text-xs font-semibold text-[#D1D5DB] hover:text-[#FFF8E7] bg-[#14151B] hover:bg-[#1E1F27] border border-[#2B2D38] hover:border-[#D4AF37] rounded-sm transition-colors text-center"
              >
                Browse Jewellery Catalogue
              </button>
            </div>

            {/* Micro Trust Strip (Clean unboxed metadata) */}
            <div className="pt-4 border-t border-[#1F2026] flex flex-wrap items-center gap-4 text-xs text-[#9CA3AF]">
              <div className="flex items-center gap-1.5 text-[#E6C687]">
                <ShieldCheck className="w-4 h-4 text-[#D4AF37]" />
                <span className="font-medium">100% BIS Hallmarked</span>
              </div>
              <span className="text-[#4B5563]">·</span>
              <span>IGI / SGL Certified Diamonds</span>
              <span className="text-[#4B5563]">·</span>
              <span>Zero Artificial Alloys</span>
              <span className="text-[#4B5563]">·</span>
              <span>Mumbai Flagship Boutique</span>
            </div>
          </div>

          {/* Right Column: Visual Campaign Focal Point */}
          <div className="lg:col-span-5 relative">
            <div className="relative aspect-[4/3] rounded-sm overflow-hidden border border-[#2B2D38] shadow-2xl group cursor-pointer" onClick={() => onNavigate('showroom')}>
              <img
                src="/src/assets/images/vj_gold_storefront_entrance_1791987077630.jpg"
                alt="VJ Gold Flagship Boutique Entrance"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-[#0B0C0E]/90 via-[#0B0C0E]/20 to-transparent flex flex-col justify-end p-6">
                <span className="text-[10px] uppercase tracking-widest text-[#E6C687] font-semibold">
                  Flagship Boutique
                </span>
                <div className="font-serif text-xl font-bold text-[#F3F4F6]">
                  Enter the Virtual Showroom
                </div>
                <div className="text-xs text-[#9CA3AF] mt-1 flex items-center gap-1.5">
                  <span>Interactive 3D navigation & consultant</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#E6C687] group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>

            {/* Floating Daily Rate Badge */}
            <div className="absolute -bottom-5 -left-4 bg-[#121316]/95 border border-[#D4AF37]/40 p-3.5 rounded-sm shadow-xl backdrop-blur-md flex items-center gap-3 hidden sm:flex">
              <div className="w-8 h-8 rounded-sm bg-[#D4AF37]/10 border border-[#D4AF37]/30 flex items-center justify-center text-[#E6C687]">
                <Gem className="w-4 h-4" />
              </div>
              <div>
                <span className="text-[10px] uppercase text-[#9CA3AF] tracking-wider block">
                  Today's 22K (916) Hallmark Rate
                </span>
                <span className="font-mono tabular-nums text-sm font-bold text-[#F3F4F6]">
                  ₹{rates.rate22kPerGram.toLocaleString('en-IN')} / gram
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Masterpieces Collection (Real reference pieces) */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[#212228] pb-6">
          <div className="space-y-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#E6C687]">
              Curated Showcase
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#F3F4F6]">
              Masterpieces in Gold & Emeralds
            </h2>
            <p className="text-xs text-[#9CA3AF]">
              Direct from the VJ Gold haute joaillerie atelier, featuring verified natural gemstones and fine hallmarks.
            </p>
          </div>

          <button
            onClick={() => onNavigate('shop')}
            className="flex items-center gap-2 text-xs font-semibold text-[#E6C687] hover:text-white transition-colors"
          >
            <span>View All Jewellery</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 3-Column / 4-Column Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onSelect={onSelectProduct}
              onInspect3D={onInspect3D}
              whatsappNumber={whatsappNumber}
            />
          ))}
        </div>
      </section>

      {/* 3D Showroom & Reception Consultant Feature Banner */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="bg-gradient-to-r from-[#121318] via-[#16171E] to-[#121318] border border-[#2B2D38] rounded-sm p-8 sm:p-12 relative overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
            <div className="lg:col-span-8 space-y-4">
              <span className="text-xs font-semibold uppercase tracking-widest text-[#E6C687]">
                Virtual Concierge Experience
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold text-[#F3F4F6]">
                Consult Our Master Jewellers from Anywhere
              </h2>
              <p className="text-xs sm:text-sm text-[#9CA3AF] leading-relaxed max-w-2xl">
                Have questions about gold purity, making charge breakdowns, stone certification, or bespoke customizations? Our interactive digital consultant is available 24/7, with instant transitions to our official WhatsApp store manager for personal video tours.
              </p>

              <div className="flex flex-wrap items-center gap-3 pt-3">
                <button
                  onClick={onOpenConsultant}
                  className="px-6 py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors flex items-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Start Consultant Consultation</span>
                </button>

                <button
                  onClick={onOpenAppointment}
                  className="px-6 py-2.5 text-xs font-semibold text-[#D1D5DB] hover:text-[#FFF8E7] bg-[#181920] border border-[#2B2D38] rounded-sm transition-colors flex items-center gap-2"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Reserve Flagship Showroom Suite</span>
                </button>
              </div>
            </div>

            <div className="lg:col-span-4 bg-[#0E0F13]/80 border border-[#2B2D38] p-5 rounded-sm space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#F3F4F6]">
                Boutique Consultation Highlights
              </h3>
              <ul className="space-y-2 text-xs text-[#9CA3AF]">
                <li className="flex items-start gap-2">
                  <span className="text-[#E6C687] font-bold">✓</span>
                  <span>Direct WhatsApp inquiry with prefilled SKU and specs</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#E6C687] font-bold">✓</span>
                  <span>Transparent weight calculation without hidden costs</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-[#E6C687] font-bold">✓</span>
                  <span>Private bridal suite with bespoke customization</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Craftsmanship Pillars */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-[#101115] border border-[#212228] p-6 rounded-sm space-y-3">
            <div className="w-10 h-10 rounded-sm bg-[#16171E] border border-[#2A2B33] flex items-center justify-center text-[#E6C687]">
              <Award className="w-5 h-5 text-[#D4AF37]" />
            </div>
            <h3 className="font-serif text-lg font-bold text-[#F3F4F6]">
              BIS 916 & 750 Hallmarked
            </h3>
            <p className="text-xs text-[#9CA3AF] leading-relaxed">
              Every milligram of gold is stamped with mandatory Bureau of Indian Standards (BIS) hallmarks and purity certificates. We uphold absolute honesty in precious metals.
            </p>
          </div>

          <div className="bg-[#101115] border border-[#212228] p-6 rounded-sm space-y-3">
            <div className="w-10 h-10 rounded-sm bg-[#16171E] border border-[#2A2B33] flex items-center justify-center text-[#E6C687]">
              <Gem className="w-5 h-5 text-[#D4AF37]" />
            </div>
            <h3 className="font-serif text-lg font-bold text-[#F3F4F6]">
              Natural Gemstones & Diamonds
            </h3>
            <p className="text-xs text-[#9CA3AF] leading-relaxed">
              From natural oval Colombian and Zambian emeralds to VVS-VS clarity diamonds, each stone is hand-selected and handset by seasoned Indian artisans.
            </p>
          </div>

          <div className="bg-[#101115] border border-[#212228] p-6 rounded-sm space-y-3">
            <div className="w-10 h-10 rounded-sm bg-[#16171E] border border-[#2A2B33] flex items-center justify-center text-[#E6C687]">
              <Layers className="w-5 h-5 text-[#D4AF37]" />
            </div>
            <h3 className="font-serif text-lg font-bold text-[#F3F4F6]">
              Lifetime Exchange & Buyback
            </h3>
            <p className="text-xs text-[#9CA3AF] leading-relaxed">
              All VJ Gold fine ornaments are backed by our guaranteed lifetime valuation policy, transparent melt assessment, and hassle-free exchange at prevailing rates.
            </p>
          </div>
        </div>
      </section>

      {/* WhatsApp Direct Banner */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center space-y-4 pt-6">
        <div className="max-w-2xl mx-auto space-y-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#25D366]">
            Live Showroom WhatsApp Desk
          </span>
          <h2 className="font-serif text-3xl font-bold text-[#F3F4F6]">
            Have a Specific Design in Mind?
          </h2>
          <p className="text-xs text-[#9CA3AF] leading-relaxed">
            Send us a photo from our catalogue or your personal bridal mood board. Our senior goldsmiths will provide an exact quotation and trial timeline within hours.
          </p>
          <div className="pt-2">
            <a
              href={buildWhatsAppLink(
                whatsappNumber,
                'Hello VJ Gold, I would like to enquire about custom bridal jewellery and showroom trials.'
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-8 py-3.5 text-xs font-bold uppercase tracking-wider text-[#0B0C0E] bg-[#25D366] hover:bg-[#20bd5a] rounded-sm transition-all shadow-lg"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Connect on WhatsApp (+91 98765 43210)</span>
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};
