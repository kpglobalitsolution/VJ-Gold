import React, { useState } from 'react';
import { StoreSettings } from '../types';
import { api, buildWhatsAppLink } from '../services/api';
import { MapPin, Phone, Mail, Clock, MessageCircle, Send, CheckCircle2 } from 'lucide-react';

interface ContactPageProps {
  settings: StoreSettings;
  whatsappNumber: string;
}

export const ContactPage: React.FC<ContactPageProps> = ({ settings, whatsappNumber }) => {
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [enquiryType, setEnquiryType] = useState('Product Price & Availability');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!customerName.trim() || !phone.trim() || !message.trim()) {
      setError('Please provide your name, phone number, and message.');
      return;
    }

    setLoading(true);
    try {
      await api.submitEnquiry({
        customerName: customerName.trim(),
        phone: phone.trim(),
        email: email.trim() || undefined,
        enquiryType,
        message: message.trim(),
      });
      setSubmitted(true);
    } catch (err: any) {
      setError(err?.message || 'Failed to submit enquiry. Please retry or contact us on WhatsApp.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      {/* Header */}
      <div className="space-y-2 border-b border-[#212228] pb-6">
        <span className="text-xs font-semibold uppercase tracking-wider text-[#E6C687]">
          Boutique Concierge
        </span>
        <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#F3F4F6]">
          Connect with VJ Gold
        </h1>
        <p className="text-xs text-[#9CA3AF] max-w-2xl leading-relaxed">
          Whether you require a personalized price estimate, desire to inspect our imperial emerald chokers in private, or wish to commission bespoke jewellery, our senior team is at your service.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Contact Information & WhatsApp (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-[#101115] border border-[#212228] p-6 rounded-sm space-y-5">
            <h3 className="font-serif text-xl font-bold text-[#F3F4F6]">
              Showroom Information
            </h3>

            <div className="space-y-4 text-xs">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] uppercase text-[#71717A] tracking-wider block">
                    Flagship Boutique
                  </span>
                  <div className="text-[#F3F4F6] font-medium leading-relaxed mt-0.5">
                    {settings.address}
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] uppercase text-[#71717A] tracking-wider block">
                    Direct Phone Line
                  </span>
                  <div className="text-[#F3F4F6] font-medium mt-0.5">{settings.phone}</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] uppercase text-[#71717A] tracking-wider block">
                    Electronic Mail
                  </span>
                  <div className="text-[#F3F4F6] font-medium mt-0.5">{settings.email}</div>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="w-4 h-4 text-[#D4AF37] shrink-0 mt-0.5" />
                <div>
                  <span className="text-[10px] uppercase text-[#71717A] tracking-wider block">
                    Visiting Hours
                  </span>
                  <div className="text-[#F3F4F6] font-medium mt-0.5">{settings.businessHours}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Quick WhatsApp Callout */}
          <div className="bg-[#12141A] border border-[#25D366]/40 p-6 rounded-sm space-y-3">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-[#25D366]">
              <MessageCircle className="w-4 h-4" />
              <span>Instant WhatsApp Concierge</span>
            </div>
            <p className="text-xs text-[#9CA3AF] leading-relaxed">
              Connect directly with our showroom manager on WhatsApp for immediate photo shares, gold rate checks, and quick appointments.
            </p>
            <a
              href={buildWhatsAppLink(
                whatsappNumber,
                'Hello VJ Gold, I would like to inquire about your jewellery collection and pricing.'
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 w-full py-3 text-xs font-bold uppercase tracking-wider text-[#0B0C0E] bg-[#25D366] hover:bg-[#20bd5a] rounded-sm transition-colors shadow-md"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Chat with Store Manager</span>
            </a>
          </div>
        </div>

        {/* Written Enquiry Form (7 cols) */}
        <div className="lg:col-span-7 bg-[#101115] border border-[#212228] p-6 sm:p-8 rounded-sm">
          {submitted ? (
            <div className="text-center py-12 space-y-4">
              <CheckCircle2 className="w-14 h-14 text-[#D4AF37] mx-auto" />
              <h3 className="font-serif text-2xl font-bold text-[#F3F4F6]">
                Message Received
              </h3>
              <p className="text-xs text-[#9CA3AF] leading-relaxed max-w-md mx-auto">
                Thank you, {customerName}. Your inquiry regarding{' '}
                <strong className="text-[#E6C687]">{enquiryType}</strong> has been forwarded to our showroom desk. A senior representative will contact you via WhatsApp or phone shortly.
              </p>
              <button
                onClick={() => {
                  setSubmitted(false);
                  setMessage('');
                }}
                className="mt-4 px-6 py-2 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] rounded-sm"
              >
                Send Another Inquiry
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1">
                <span className="text-[10px] font-semibold tracking-wider text-[#E6C687] uppercase">
                  Official Communication
                </span>
                <h3 className="font-serif text-2xl font-bold text-[#F3F4F6]">
                  Submit an Inquiry to Our Atelier
                </h3>
              </div>

              {error && (
                <div className="p-3 bg-red-950/40 border border-red-800 text-red-300 text-xs rounded-sm">
                  {error}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                    Your Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Radhika Kapoor"
                    className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                    Phone Number (WhatsApp) *
                  </label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98200 00000"
                    className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                    Email Address (Optional)
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="radhika@example.com"
                    className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                    Inquiry Type
                  </label>
                  <select
                    value={enquiryType}
                    onChange={(e) => setEnquiryType(e.target.value)}
                    className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm px-3 py-2 text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                  >
                    <option value="Product Price & Availability">Product Price & Availability</option>
                    <option value="Bridal Choker Set Customization">Bridal Choker Set Customization</option>
                    <option value="Gold Exchange & Valuation">Gold Exchange & Valuation</option>
                    <option value="Corporate / Bullion Booking">Corporate / Bullion Booking</option>
                    <option value="General Store Inquiry">General Store Inquiry</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-[#D1D5DB] mb-1">
                  Message / Specific Jewellery Piece of Interest *
                </label>
                <textarea
                  rows={4}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Please describe the pieces you would like to inquire about, your preferred purity, or any custom specifications..."
                  className="w-full bg-[#16171E] border border-[#2B2D38] rounded-sm p-3 text-xs text-[#F3F4F6] focus:border-[#D4AF37] focus:outline-none"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 text-xs font-bold uppercase tracking-widest text-[#0B0C0E] bg-gradient-to-r from-[#E6C687] to-[#D4AF37] hover:from-[#F0D8A8] hover:to-[#E5C158] disabled:opacity-50 rounded-sm transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{loading ? 'Submitting Inquiry...' : 'Submit Inquiry'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
