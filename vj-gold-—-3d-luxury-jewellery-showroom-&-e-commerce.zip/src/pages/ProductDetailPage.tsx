import React, { useState } from 'react';
import { Product, GoldRates } from '../types';
import {
  ArrowLeft,
  Sparkles,
  MessageCircle,
  Calendar,
  ShieldCheck,
  RotateCw,
  Scale,
  Award,
  Gem,
  Info,
  Camera,
  Zap,
} from 'lucide-react';
import { buildWhatsAppLink, formatINR } from '../services/api';

interface ProductDetailPageProps {
  product: Product;
  allProducts: Product[];
  rates: GoldRates;
  onBack: () => void;
  onInspect3D: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
  onOpenConsultant: (product: Product) => void;
  onOpenAppointment: () => void;
  onOpenVirtualTryOn: (product: Product) => void;
  whatsappNumber: string;
}

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({
  product,
  allProducts,
  rates,
  onBack,
  onInspect3D,
  onSelectProduct,
  onOpenConsultant,
  onOpenAppointment,
  onOpenVirtualTryOn,
  whatsappNumber,
}) => {
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [zoomPos, setZoomPos] = useState({ x: 50, y: 50 });

  const galleryImages = [
    product.primaryImage,
    ...(product.additionalImages || []),
  ];

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;
    setZoomPos({ x, y });
  };

  const relatedProducts = allProducts
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 3);

  // Metal value breakdown calculation
  const purityMultiplier = product.goldPurity.includes('18K') ? rates.rate18kPerGram : rates.rate22kPerGram;
  const estimatedMetalValue = product.netGoldWeight * purityMultiplier;
  // Floating Quick Order WhatsApp message:
  // Prepends specific product name and current price to pre-filled enquiry message
  const currentFormattedPrice = formatINR(product.price);
  const quickOrderMessage = `[Quick Order] ${product.name} - ${currentFormattedPrice} (SKU: ${product.sku})\n\nHello VJ Gold Atelier, I would like to place a quick order for this piece. Please confirm today's gold spot valuation, making charges, and arrange boutique dispatch / in-store trial.`;
  const quickOrderWhatsAppUrl = buildWhatsAppLink(whatsappNumber, quickOrderMessage);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      {/* Top Back Navigation */}
      <button
        onClick={onBack}
        className="flex items-center gap-2 text-xs font-medium text-[#E6C687] hover:text-white transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Catalogue</span>
      </button>

      {/* Main PDP Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Gallery Column (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Main Zoomable Image Stage */}
          <div
            onMouseEnter={() => setIsZoomed(true)}
            onMouseLeave={() => setIsZoomed(false)}
            onMouseMove={handleMouseMove}
            className="relative aspect-square w-full bg-[#0A0B0E] border border-[#262731] rounded-sm overflow-hidden cursor-crosshair group shadow-xl"
          >
            <img
              src={galleryImages[activeImageIndex] || product.primaryImage}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover transition-opacity duration-300"
              style={{
                transformOrigin: `${zoomPos.x}% ${zoomPos.y}%`,
                transform: isZoomed ? 'scale(1.8)' : 'scale(1)',
                transition: isZoomed ? 'transform 0.1s ease-out' : 'transform 0.3s ease',
              }}
            />

            {/* Inspect in 3D Action Floating Pill */}
            <div className="absolute bottom-4 right-4 z-20 flex items-center gap-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onOpenVirtualTryOn(product);
                }}
                className="flex items-center gap-1.5 px-3 py-2 bg-[#D4AF37] text-[#0B0C0E] text-xs font-bold rounded-sm backdrop-blur-md hover:bg-[#E5C158] transition-all shadow-lg"
                title="Try on with your camera"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>Virtual Try-On</span>
              </button>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onInspect3D(product);
                }}
                className="flex items-center gap-1.5 px-3 py-2 bg-[#0B0C0E]/90 text-[#E6C687] text-xs font-semibold border border-[#D4AF37]/50 rounded-sm backdrop-blur-md hover:bg-[#D4AF37] hover:text-[#0B0C0E] transition-all shadow-lg"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>3D Pedestal</span>
              </button>
            </div>

            {/* Magnifier indicator hint */}
            {!isZoomed && (
              <div className="absolute top-4 left-4 z-10 text-[10px] text-[#A1A1AA] uppercase tracking-wider bg-black/60 px-2 py-1 backdrop-blur-md">
                Hover to Zoom Details
              </div>
            )}
          </div>

          {/* Thumbnail Strip */}
          {galleryImages.length > 1 && (
            <div className="flex gap-3 overflow-x-auto pb-1">
              {galleryImages.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`w-20 h-20 rounded-sm overflow-hidden border-2 transition-all shrink-0 ${
                    activeImageIndex === idx ? 'border-[#D4AF37]' : 'border-[#262731] opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt={`${product.name} ${idx + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}

          {/* Hallmark Trust Banner */}
          <div className="bg-[#101115] border border-[#212228] p-4 rounded-sm flex items-center justify-between text-xs text-[#9CA3AF]">
            <div className="flex items-center gap-2 text-[#E6C687]">
              <ShieldCheck className="w-5 h-5 text-[#D4AF37] shrink-0" />
              <span className="font-semibold">BIS 916 / 750 Hallmark Guaranteed</span>
            </div>
            <span className="text-[11px] text-[#71717A]">Govt. of India Certified</span>
          </div>
        </div>

        {/* Purchase & Inquiry Module (5 cols) */}
        <div className="lg:col-span-5 bg-[#121316] border border-[#282931] rounded-sm p-6 sm:p-8 space-y-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#E6C687]">
                {product.category}
              </span>
              <span className="font-mono text-xs text-[#71717A]">SKU: {product.sku}</span>
            </div>

            <h1 className="font-serif text-2xl sm:text-3xl font-bold text-[#F3F4F6]">
              {product.name}
            </h1>

            <p className="text-xs text-[#9CA3AF] leading-relaxed">
              {product.description}
            </p>
          </div>

          {/* Price Box */}
          <div className="p-4 bg-[#16171E] border border-[#262731] rounded-sm space-y-1">
            <span className="text-[10px] uppercase text-[#71717A] tracking-wider block">
              Indicative Showroom Price
            </span>
            <div className="font-mono tabular-nums text-2xl sm:text-3xl font-bold text-[#E6C687]">
              {formatINR(product.price)}
            </div>
            <p className="text-[11px] text-[#9CA3AF] pt-1">
              * Final invoice is subject to real-time daily gold spot rates and exact measured making charges.
            </p>
          </div>

          {/* Itemized Specification Sheet */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#F3F4F6] flex items-center gap-1.5">
              <Scale className="w-4 h-4 text-[#D4AF37]" />
              <span>Verified Atelier Specifications</span>
            </h3>

            <div className="divide-y divide-[#212229] border-y border-[#212229] text-xs">
              <div className="py-2.5 flex justify-between">
                <span className="text-[#9CA3AF]">Gold Purity</span>
                <span className="font-medium text-[#F3F4F6]">{product.goldPurity}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-[#9CA3AF]">Gross Weight</span>
                <span className="font-mono tabular-nums font-semibold text-[#F3F4F6]">
                  {product.grossWeight} grams
                </span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-[#9CA3AF]">Net Gold Weight</span>
                <span className="font-mono tabular-nums font-semibold text-[#E6C687]">
                  {product.netGoldWeight} grams
                </span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-[#9CA3AF]">Precious Stones</span>
                <span className="font-medium text-[#F3F4F6] text-right max-w-xs">{product.stoneDetails}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-[#9CA3AF]">Making Charges (Indicative)</span>
                <span className="font-mono tabular-nums text-[#D1D5DB]">
                  ₹{product.makingChargesPerGram} / gram
                </span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-[#9CA3AF]">Showroom Availability</span>
                <span className="font-medium text-[#10B981]">{product.availability}</span>
              </div>
            </div>
          </div>

          {/* Action CTAs */}
          <div className="space-y-3 pt-2">
            <button
              onClick={() => onOpenVirtualTryOn(product)}
              className="w-full py-3.5 text-xs font-bold uppercase tracking-wider text-[#0B0C0E] bg-gradient-to-r from-[#E6C687] via-[#D4AF37] to-[#E6C687] hover:brightness-110 rounded-sm transition-all flex items-center justify-center gap-2 shadow-lg"
            >
              <Camera className="w-4 h-4" />
              <span>Virtual Try-On (Live Camera Mirror)</span>
            </button>

            <a
              href={buildWhatsAppLink(
                whatsappNumber,
                `Hello VJ Gold, I am interested in ${product.name} (SKU: ${product.sku}). Please share the latest verified quotation, daily gold rate breakdown, and availability for boutique trial.`
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3 text-xs font-bold uppercase tracking-wider text-[#0B0C0E] bg-[#25D366] hover:bg-[#20bd5a] rounded-sm transition-all flex items-center justify-center gap-2 shadow-md"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Enquire on WhatsApp with SKU</span>
            </a>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={onOpenAppointment}
                className="py-2.5 px-3 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors flex items-center justify-center gap-1.5"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Book Store Trial</span>
              </button>

              <button
                onClick={() => onOpenConsultant(product)}
                className="py-2.5 px-3 text-xs font-medium text-[#D1D5DB] hover:text-[#FFF8E7] bg-[#181920] border border-[#2B2D38] rounded-sm transition-colors flex items-center justify-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#E6C687]" />
                <span>Ask Consultant</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Related Jewellery Section */}
      {relatedProducts.length > 0 && (
        <div className="pt-12 border-t border-[#212228] space-y-6">
          <div className="space-y-1">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#E6C687]">
              Harmonious Creations
            </span>
            <h2 className="font-serif text-2xl font-bold text-[#F3F4F6]">
              Matching Pieces in {product.category}
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {relatedProducts.map((rel) => (
              <div
                key={rel.id}
                onClick={() => onSelectProduct(rel)}
                className="bg-[#101114] border border-[#212228] hover:border-[#D4AF37] p-4 rounded-sm cursor-pointer transition-all space-y-3"
              >
                <div className="aspect-square w-full rounded-sm overflow-hidden bg-[#08090C]">
                  <img src={rel.primaryImage} alt={rel.name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-sm text-[#F3F4F6] line-clamp-1">{rel.name}</h4>
                  <div className="text-xs text-[#E6C687] font-mono tabular-nums mt-1">{formatINR(rel.price)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Floating Quick Order via WhatsApp Button */}
      <aside aria-label="Quick Order via WhatsApp" className="fixed bottom-6 right-6 z-40">
        <a
          href={quickOrderWhatsAppUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="group flex items-center gap-3 px-4 py-3 bg-[#111319]/95 hover:bg-[#151821] border border-[#25D366]/80 hover:border-[#25D366] rounded-full shadow-[0_8px_30px_rgba(0,0,0,0.6)] backdrop-blur-md transition-all duration-300 hover:scale-[1.03] hover:shadow-[0_10px_35px_rgba(37,211,102,0.35)]"
          title={`Quick Order via WhatsApp: ${product.name} (${currentFormattedPrice})`}
        >
          {/* Pulsing WhatsApp Icon Badge */}
          <div className="relative shrink-0">
            <div className="w-10 h-10 rounded-full bg-[#25D366] text-[#0B0C0E] flex items-center justify-center font-bold shadow-md group-hover:scale-105 transition-transform">
              <MessageCircle className="w-5 h-5 fill-current" />
            </div>
            <span className="absolute -top-0.5 -right-0.5 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#25D366] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-[#10B981]"></span>
            </span>
          </div>

          <div className="flex flex-col text-left pr-1">
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold uppercase tracking-wider text-[#F3F4F6] group-hover:text-[#25D366] transition-colors whitespace-nowrap">
                Quick Order via WhatsApp
              </span>
              <span className="text-[10px] bg-[#D4AF37]/20 text-[#E6C687] font-semibold px-1.5 py-0.5 rounded-sm border border-[#D4AF37]/30 flex items-center gap-0.5 shrink-0">
                <Zap className="w-2.5 h-2.5" />
                <span>Instant</span>
              </span>
            </div>
            <span className="text-[11px] font-mono tabular-nums text-[#E6C687] line-clamp-1 max-w-[220px]">
              {product.name} · {currentFormattedPrice}
            </span>
          </div>
        </a>
      </aside>
    </div>
  );
};
