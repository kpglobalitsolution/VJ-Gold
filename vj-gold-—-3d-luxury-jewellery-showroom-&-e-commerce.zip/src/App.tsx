import React, { useState, useEffect } from 'react';
import { Product, GoldRates, StoreSettings } from './types';
import { api } from './services/api';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { GoldRateTicker } from './components/GoldRateTicker';
import { Showroom3D } from './components/Showroom3D';
import { ShowroomInspector } from './components/ShowroomInspector';
import { ConsultantModal } from './components/ConsultantModal';
import { AppointmentModal } from './components/AppointmentModal';
import { GoldEstimatorModal } from './components/GoldEstimatorModal';
import { EnquiryBasketModal } from './components/EnquiryBasketModal';
import { LoyaltyRewardsModal } from './components/LoyaltyRewardsModal';
import { VirtualTryOnModal } from './components/VirtualTryOnModal';
import { GoldTrendChart } from './components/GoldTrendChart';
import { DigitalGiftVoucherModal } from './components/DigitalGiftVoucherModal';
import { HomePage } from './pages/HomePage';
import { ShopPage } from './pages/ShopPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { AdminPage } from './pages/AdminPage';

export default function App() {
  // Set default view to 'showroom' so the 3D walk-in experience is the primary flagship experience
  const [currentTab, setCurrentTab] = useState<string>('showroom');

  const [products, setProducts] = useState<Product[]>([]);
  const [rates, setRates] = useState<GoldRates>({
    rate24kPerGram: 7480,
    rate22kPerGram: 6855,
    rate18kPerGram: 5610,
    silverRatePerGram: 94,
    currency: 'INR',
    symbol: '₹',
    updatedAt: new Date().toISOString(),
    rateSource: 'VJ Gold Bullion Desk',
    isManual: true,
  });
  const [settings, setSettings] = useState<StoreSettings>({
    storeName: 'VJ Gold',
    tagline: 'Fine Jewellery & Bespoke Bullion',
    phone: '+91 98765 43210',
    whatsappNumber: '919876543210',
    email: 'enquiry@vjgold.in',
    address: 'VJ Gold Luxury Flagship Boutique, Gold Souk Arcade, MG Road, Mumbai 400001',
    businessHours: 'Mon – Sat: 10:30 AM – 8:30 PM | Sun: 11:00 AM – 7:00 PM',
    instagram: 'https://www.instagram.com/vj._.gold/',
    website: 'https://www.vjgold.in/',
    gstPercentage: 3,
    hallmarkNotice: '100% BIS Hallmarked 916 & 750 Gold Guaranteed',
  });

  const [loading, setLoading] = useState(true);

  // Enquiry Basket / Wishlist
  const [basket, setBasket] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('vjg_basket');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [basketModalOpen, setBasketModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [inspecting3DProduct, setInspecting3DProduct] = useState<Product | null>(null);
  const [consultantModalOpen, setConsultantModalOpen] = useState(false);
  const [consultantTargetProduct, setConsultantTargetProduct] = useState<Product | null>(null);
  const [appointmentModalOpen, setAppointmentModalOpen] = useState(false);
  const [estimatorModalOpen, setEstimatorModalOpen] = useState(false);
  const [loyaltyModalOpen, setLoyaltyModalOpen] = useState(false);
  const [giftVoucherModalOpen, setGiftVoucherModalOpen] = useState(false);
  const [tryOnModalOpen, setTryOnModalOpen] = useState(false);
  const [tryOnProduct, setTryOnProduct] = useState<Product | null>(null);

  const loadData = async () => {
    try {
      const [prods, rts, stt] = await Promise.all([
        api.getProducts(),
        api.getGoldRates(),
        api.getSettings(),
      ]);
      setProducts(prods);
      setRates(rts);
      setSettings(stt);
    } catch (err) {
      console.warn('Error loading VJ Gold data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleToggleWishlist = (product: Product) => {
    setBasket((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      let updated: Product[];
      if (exists) {
        updated = prev.filter((p) => p.id !== product.id);
      } else {
        updated = [...prev, product];
      }
      localStorage.setItem('vjg_basket', JSON.stringify(updated));
      return updated;
    });
  };

  const handleRemoveFromBasket = (id: string) => {
    setBasket((prev) => {
      const updated = prev.filter((p) => p.id !== id);
      localStorage.setItem('vjg_basket', JSON.stringify(updated));
      return updated;
    });
  };

  const handleClearBasket = () => {
    setBasket([]);
    localStorage.removeItem('vjg_basket');
  };

  const handleOpenConsultant = (product?: Product) => {
    setConsultantTargetProduct(product || null);
    setConsultantModalOpen(true);
  };

  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
    setInspecting3DProduct(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleInspect3D = (product: Product) => {
    setInspecting3DProduct(product);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const categories = Array.from(new Set(products.map((p) => p.category)));
  const wishlistIds = basket.map((p) => p.id);

  return (
    <div className="min-h-screen bg-[#0B0C0E] text-[#F3F4F6] flex flex-col font-sans selection:bg-[#D4AF37]/30 selection:text-[#FFF8E7]">
      {/* Top Bar Contract Navigation */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          setCurrentTab(tab);
          setSelectedProduct(null);
          setInspecting3DProduct(null);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenAppointment={() => setAppointmentModalOpen(true)}
        onOpenEnquiryBasket={() => setBasketModalOpen(true)}
        onOpenLoyaltyRewards={() => setLoyaltyModalOpen(true)}
        onOpenGiftVoucher={() => setGiftVoucherModalOpen(true)}
        basketCount={basket.length}
        whatsappNumber={settings.whatsappNumber}
      />

      {/* Gold Rates Live Strip */}
      <GoldRateTicker
        rates={rates}
        onOpenEstimator={() => setEstimatorModalOpen(true)}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {/* If a product is open in 3D Orbit Pedestal Inspector */}
        {inspecting3DProduct ? (
          <ShowroomInspector
            product={inspecting3DProduct}
            onBack={() => setInspecting3DProduct(null)}
            whatsappNumber={settings.whatsappNumber}
            onOpenConsultant={handleOpenConsultant}
          />
        ) : selectedProduct ? (
          /* If a product detail page is open */
          <ProductDetailPage
            product={selectedProduct}
            allProducts={products}
            rates={rates}
            onBack={() => setSelectedProduct(null)}
            onInspect3D={handleInspect3D}
            onSelectProduct={handleSelectProduct}
            onOpenConsultant={handleOpenConsultant}
            onOpenAppointment={() => setAppointmentModalOpen(true)}
            onOpenVirtualTryOn={(prod) => {
              setTryOnProduct(prod);
              setTryOnModalOpen(true);
            }}
            whatsappNumber={settings.whatsappNumber}
          />
        ) : currentTab === 'showroom' ? (
          /* Default Flagship 3D Walk-In Experience */
          <div>
            <Showroom3D
              products={products}
              rates={rates}
              onBrowseOnline={() => {
                setCurrentTab('shop');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onOpenAppointment={() => setAppointmentModalOpen(true)}
              onOpenEnquiryBasket={() => setBasketModalOpen(true)}
              basketCount={basket.length}
              onInspect3DOrbit={handleInspect3D}
              onToggleWishlist={handleToggleWishlist}
              onOpenVirtualTryOn={(prod) => {
                setTryOnProduct(prod);
                setTryOnModalOpen(true);
              }}
              wishlistIds={wishlistIds}
              whatsappNumber={settings.whatsappNumber}
            />

            {/* Quick Browse Strip below 3D viewport */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-4">
              <div className="flex items-center justify-between border-b border-[#212228] pb-4">
                <div>
                  <span className="text-[10px] uppercase font-semibold text-[#E6C687] tracking-wider block">
                    Showroom Highlights
                  </span>
                  <h3 className="font-serif text-2xl font-bold text-[#F3F4F6]">
                    Actual Atelier Pieces on Display
                  </h3>
                </div>
                <button
                  onClick={() => {
                    setCurrentTab('shop');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-xs font-semibold text-[#E6C687] hover:underline"
                >
                  View Full Catalogue Grid →
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {products.slice(0, 4).map((p) => (
                  <div
                    key={p.id}
                    onClick={() => handleSelectProduct(p)}
                    className="bg-[#101115] border border-[#212228] hover:border-[#D4AF37] p-3.5 rounded-sm cursor-pointer transition-all space-y-2 group"
                  >
                    <div className="aspect-square rounded-sm overflow-hidden bg-[#08090C]">
                      <img
                        src={p.primaryImage}
                        alt={p.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                    </div>
                    <div className="text-[10px] text-[#A1A1AA] uppercase tracking-wider">{p.category}</div>
                    <div className="font-serif font-bold text-sm text-[#F3F4F6] line-clamp-1">{p.name}</div>
                    <div className="flex items-baseline justify-between text-xs">
                      <span className="font-mono text-[#E6C687] font-semibold">
                        {p.isPriceVerified && p.price ? `₹${p.price.toLocaleString('en-IN')}` : 'On Request'}
                      </span>
                      <span className="text-[10px] text-[#71717A]">{p.grossWeight}g</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : currentTab === 'shop' ? (
          /* Catalogue Shop View */
          <ShopPage
            products={products}
            onSelectProduct={handleSelectProduct}
            onInspect3D={handleInspect3D}
            whatsappNumber={settings.whatsappNumber}
          />
        ) : currentTab === 'rates' ? (
          /* Dedicated Gold Rates Page */
          <div className="max-w-4xl mx-auto px-4 sm:px-6 py-12 space-y-8">
            <div className="text-center space-y-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-[#E6C687]">
                Official Bullion Desk
              </span>
              <h1 className="font-serif text-3xl sm:text-4xl font-bold text-[#F3F4F6]">
                Today's Gold & Precious Metal Rates
              </h1>
              <p className="text-xs text-[#9CA3AF]">
                Rates updated daily from Mumbai Bullion Exchange. 100% BIS Hallmarked 916 and 750 Gold.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-[#121316] border border-[#2B2D38] p-5 rounded-sm text-center space-y-1">
                <span className="text-xs text-[#9CA3AF] uppercase">24K Pure Gold (999)</span>
                <div className="font-mono text-2xl font-bold text-[#F3F4F6]">
                  ₹{rates.rate24kPerGram.toLocaleString('en-IN')}
                </div>
                <span className="text-[11px] text-[#71717A]">per gram</span>
              </div>

              <div className="bg-[#16171E] border border-[#D4AF37]/50 p-5 rounded-sm text-center space-y-1">
                <span className="text-xs text-[#E6C687] uppercase font-semibold">22K Standard (916)</span>
                <div className="font-mono text-2xl font-bold text-[#E6C687]">
                  ₹{rates.rate22kPerGram.toLocaleString('en-IN')}
                </div>
                <span className="text-[11px] text-[#A1A1AA]">per gram (Hallmark)</span>
              </div>

              <div className="bg-[#121316] border border-[#2B2D38] p-5 rounded-sm text-center space-y-1">
                <span className="text-xs text-[#9CA3AF] uppercase">18K Diamond Jewellery (750)</span>
                <div className="font-mono text-2xl font-bold text-[#F3F4F6]">
                  ₹{rates.rate18kPerGram.toLocaleString('en-IN')}
                </div>
                <span className="text-[11px] text-[#71717A]">per gram</span>
              </div>

              <div className="bg-[#121316] border border-[#2B2D38] p-5 rounded-sm text-center space-y-1">
                <span className="text-xs text-[#9CA3AF] uppercase">Fine Silver</span>
                <div className="font-mono text-2xl font-bold text-[#9CA3AF]">
                  ₹{rates.silverRatePerGram.toLocaleString('en-IN')}
                </div>
                <span className="text-[11px] text-[#71717A]">per gram</span>
              </div>
            </div>

            {/* 30-Day Historical Trend Line using Recharts */}
            <GoldTrendChart rates={rates} />

            {/* Actions & Digital Gift Voucher Promotion */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="bg-[#121317] border border-[#2B2D38] p-5 rounded-sm flex flex-col justify-between space-y-3">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-wider text-[#E6C687] font-semibold">
                    Live Calculation
                  </span>
                  <h4 className="font-serif text-lg font-bold text-[#F3F4F6]">
                    Transparent Price Estimator
                  </h4>
                  <p className="text-xs text-[#9CA3AF]">
                    Calculate exact jewellery costs with live gold rate, weight, making charges, and 3% GST.
                  </p>
                </div>
                <button
                  onClick={() => setEstimatorModalOpen(true)}
                  className="w-full py-2.5 text-xs font-semibold text-[#0B0C0E] bg-[#D4AF37] hover:bg-[#E5C158] rounded-sm transition-colors text-center"
                >
                  Open Price Breakdown Calculator
                </button>
              </div>

              <div className="bg-gradient-to-br from-[#161720] via-[#1B1D28] to-[#14151C] border border-[#D4AF37]/50 p-5 rounded-sm flex flex-col justify-between space-y-3">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-wider text-[#E6C687] font-semibold">
                    Bespoke Gifting
                  </span>
                  <h4 className="font-serif text-lg font-bold text-[#F3F4F6]">
                    Digital Gift Voucher (QR)
                  </h4>
                  <p className="text-xs text-[#9CA3AF]">
                    Generate an official boutique gift voucher with a unique QR code to send to friends and family.
                  </p>
                </div>
                <button
                  onClick={() => setGiftVoucherModalOpen(true)}
                  className="w-full py-2.5 text-xs font-bold uppercase tracking-wider text-[#0B0C0E] bg-gradient-to-r from-[#E6C687] to-[#D4AF37] hover:from-[#F0D8A8] hover:to-[#E5C158] rounded-sm transition-all shadow-md text-center"
                >
                  Generate Digital Gift Voucher
                </button>
              </div>
            </div>
          </div>
        ) : currentTab === 'about' ? (
          /* Heritage & Craftsmanship View */
          <AboutPage
            settings={settings}
            onOpenAppointment={() => setAppointmentModalOpen(true)}
          />
        ) : currentTab === 'contact' ? (
          /* Contact & Visit Booking View */
          <ContactPage
            settings={settings}
            whatsappNumber={settings.whatsappNumber}
          />
        ) : currentTab === 'admin' ? (
          /* Store Admin Console */
          <AdminPage
            products={products}
            rates={rates}
            settings={settings}
            onRefreshData={loadData}
          />
        ) : (
          /* Home page view */
          <HomePage
            products={products}
            rates={rates}
            settings={settings}
            onNavigate={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onSelectProduct={handleSelectProduct}
            onInspect3D={handleInspect3D}
            onOpenAppointment={() => setAppointmentModalOpen(true)}
            onOpenConsultant={() => handleOpenConsultant()}
            whatsappNumber={settings.whatsappNumber}
          />
        )}
      </main>

      {/* Luxury Footer */}
      <Footer
        settings={settings}
        onNavigate={(tab) => {
          setCurrentTab(tab);
          setSelectedProduct(null);
          setInspecting3DProduct(null);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
      />

      {/* Global Interactive Modals */}
      <ConsultantModal
        isOpen={consultantModalOpen}
        onClose={() => setConsultantModalOpen(false)}
        product={consultantTargetProduct}
        whatsappNumber={settings.whatsappNumber}
      />

      <AppointmentModal
        isOpen={appointmentModalOpen}
        onClose={() => setAppointmentModalOpen(false)}
        categories={categories}
      />

      <GoldEstimatorModal
        isOpen={estimatorModalOpen}
        onClose={() => setEstimatorModalOpen(false)}
        rates={rates}
        onOpenConsultant={() => handleOpenConsultant()}
      />

      <EnquiryBasketModal
        isOpen={basketModalOpen}
        onClose={() => setBasketModalOpen(false)}
        basket={basket}
        onRemove={handleRemoveFromBasket}
        onClear={handleClearBasket}
        onSelectProduct={handleSelectProduct}
        onOpenAppointment={() => {
          setBasketModalOpen(false);
          setAppointmentModalOpen(true);
        }}
        onOpenLoyaltyRewards={() => {
          setBasketModalOpen(false);
          setLoyaltyModalOpen(true);
        }}
        whatsappNumber={settings.whatsappNumber}
      />

      {/* Loyalty Rewards Modal */}
      <LoyaltyRewardsModal
        isOpen={loyaltyModalOpen}
        onClose={() => setLoyaltyModalOpen(false)}
        basketTotal={basket.reduce((acc, p) => acc + (p.price || 0), 0)}
        whatsappNumber={settings.whatsappNumber}
      />

      {/* Virtual Try-On Camera Overlay Modal */}
      {tryOnProduct && (
        <VirtualTryOnModal
          isOpen={tryOnModalOpen}
          onClose={() => {
            setTryOnModalOpen(false);
            setTryOnProduct(null);
          }}
          product={tryOnProduct}
          whatsappNumber={settings.whatsappNumber}
        />
      )}

      {/* Digital Gift Voucher with QR Code Generator */}
      <DigitalGiftVoucherModal
        isOpen={giftVoucherModalOpen}
        onClose={() => setGiftVoucherModalOpen(false)}
        whatsappNumber={settings.whatsappNumber}
      />
    </div>
  );
}
